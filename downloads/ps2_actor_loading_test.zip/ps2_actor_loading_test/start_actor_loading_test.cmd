@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_actor_loading_test.py" --mode start
pause

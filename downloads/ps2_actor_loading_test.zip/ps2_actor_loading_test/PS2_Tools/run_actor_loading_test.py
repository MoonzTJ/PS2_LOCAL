"""Reproduce the known inventory baseline, then observe idle and W-held actors."""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT/'PS2_Server'
if not SERVER.is_dir():
    SERVER = ROOT
sys.path.insert(0, str(SERVER))
try:
    from scripts import run_owned_inventory_test as baseline
except ModuleNotFoundError:
    import run_owned_inventory_test as baseline
import actor_loading_capture as observe
import capture_local_state as capture
from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready
from native_image_capture import discover_pid
import win_reader as win

SESSION = ROOT/'.actor-loading-test-session.json'
FORMAT = 'ps2-actor-loading-test-v1'


def verify_bundle(root=ROOT):
    manifest = json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format') == FORMAT, 'Extract the complete actor loading test ZIP again.')
    for name, row in manifest['files'].items():
        path = root/name
        win.require(not path.is_symlink() and path.is_file()
                    and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == row['bytes'] and win.file_sha(path) == row['sha256'],
                    'Actor loading test files differ; extract the ZIP again.')


def start(game):
    baseline.launch.require_closed_server()
    reports = ROOT/'reports'; reports.mkdir(exist_ok=True)
    process = subprocess.Popen([sys.executable, str(SERVER/'local_server.py'),
        '--push-lists', '--class-delivery-probe', '--vs-test-character', '--starter-loadout-references',
        '--owned-inventory-probe', '--character-state-dir', str(SERVER/'state'),
        '--no-availability-observation', '--log-dir', str(reports)],
        cwd=str(SERVER), creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready = baseline.verify_ready(wait_ready(CONTROL_PORT, LOGIN_PORT, 30))
    except BaseException:
        if process.poll() is None:
            process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game), instance_id=ready['instance_id'])))
    for mode in ('client', 'controls'):
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--mode', mode],
                         cwd=str(ROOT), creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Select LocalVSTest, press Play, and keep the game/server open.')
    print('At the world HUD, run capture_actor_loading_test.cmd once. Read README first.')


def signal(count):
    import winsound
    for _ in range(count):
        winsound.Beep(880, 180)
        time.sleep(0.15)


def require_input(snapshot, held):
    win.require(all(snapshot.get(key, {}).get('game_is_foreground') is True
                    and snapshot[key].get('w_held') is held for key in ('input_before', 'input_after')),
                'Game focus/W state did not match this phase; upload the report and describe what happened.')


def collect_test(game, instance, *, output=None, collector=capture.collect, control=control_request,
                 pause=time.sleep, beep=signal, locate_pid=discover_pid, snapshotter=observe.capture_selected):
    output = Path(output or ROOT/'reports'); output.mkdir(exist_ok=True, parents=True)
    expected = capture.read_input(Path(__file__).resolve().parent)
    files = {}; stage = 'server_health'; pid = None
    result = dict(kind='local_actor_loading_test', format_version=1, ok=False,
                  server_instance_id=instance, delivery_attempted=False,
                  gameplay_fix_applied=False, playable_character_verified=False)

    def health(expected, instance=instance):
        ready = baseline.verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        baseline_health = capture.server_health(expected, instance=instance)
        return dict(baseline_health, starter_loadout=ready['starter_loadout'],
                    vs_test_character=ready['vs_test_character'], owned_inventory_probe=ready['owned_inventory_probe'])

    def collect(label):
        path, ok = collector(game, output, expected, health=health,
            locate_pid=lambda: pid, capture=snapshotter)
        files[label+'.zip'] = path.read_bytes()
        win.require(ok, 'Native capture stopped; upload this report.')
        with zipfile.ZipFile(path) as archive:
            row = json.loads(archive.read('local-state.json'))
        win.require(row['server_instance_id'] == instance, 'Server instance changed')
        return row['native_snapshot']

    try:
        ready = baseline.verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        win.require(not ready['owned_inventory_probe']['attempted'], 'Already attempted; restart the test server for a new run.')
        pid = locate_pid()
        stage = 'before_capture'
        before = collect('before')
        win.require(before.get('format_version') == 10, 'Wrong actor loading capture version')
        # Existing baseline guard is unchanged; the new observer only extends its report.
        baseline.require_before(dict(before, format_version=9))
        stage = 'baseline_delivery'
        baseline.verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        result['delivery_attempted'] = True  # Never retry an uncertain application send.
        result['control_reply'] = control(CONTROL_PORT, LOGIN_PORT, 'apply_owned_probe', instance=instance, timeout=2)
        print('Switch back to the GAME now. Close menus/chat. Do not press movement keys yet.')
        print('After TWO beeps, hold W until THREE beeps. Keep the game focused.')
        pause(8)
        stage = 'idle_capture'
        idle = collect('idle')
        require_input(idle, False)
        stage = 'w_held_capture'
        beep(2)
        pause(2)
        held = collect('w-held')
        require_input(held, True)
        result['health_after'] = baseline.verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        win.require(result['health_after']['owned_inventory_probe']['packets_sent'] == 1,
                    'Expected one known baseline delivery')
        owned = idle.get('native_gateway_state', {}).get('player_world_record', {}).get('owned_equipment_state', {})
        win.require(owned.get('both_owned_instances_match') is True and owned.get('equipment_references_match') is True,
                    'Known two-item baseline was not observed; upload this report.')
        result.update(ok=True, baseline_owned_instances_observed=True,
                      idle_actor_state_available=idle.get('actor_loading', {}).get('available') is True,
                      held_actor_state_available=held.get('actor_loading', {}).get('available') is True,
                      comparison='Compare per-component availability and values; no automatic declaration of actor readiness or movement.')
    except (OSError, ValueError, subprocess.SubprocessError, zipfile.BadZipFile, KeyError) as error:
        result.update(stage=stage, error_type=type(error).__name__, windows_error=getattr(error, 'winerror', None),
                      reason=str(error) if isinstance(error, ValueError) else 'Capture stopped; upload the saved report.')
    finally:
        # Always release the user from the timed hold, including failed captures.
        try:
            beep(3)
        except OSError:
            pass
    files['actor-loading-test.json'] = (json.dumps(result, indent=2, allow_nan=False)+'\n').encode()
    win.require(sum(map(len, files.values())) <= 2*1024*1024, 'Actor report exceeds export limit')
    manifest = dict(format='ps2-actor-loading-report-v1', files={name:
        dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name,raw in files.items()})
    path = output/('local-actor-loading-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in files.items():
            archive.writestr(name, raw)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
    with zipfile.ZipFile(path) as archive:
        win.require(archive.testzip() is None, 'Actor report ZIP integrity check failed')
    print('Release W. Upload this ZIP:', path)
    if not result['ok']:
        print('Test stopped:', result['reason'])
    return path, result['ok']


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('start', 'client', 'controls', 'capture'), default='start')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode == 'start':
            game = baseline.launch.choose_game()
            if game:
                start(baseline.launch.verify_game(game))
            return 0
        state = json.loads(SESSION.read_text())
        baseline.verify_ready(control_request(CONTROL_PORT, LOGIN_PORT), state['instance_id'])
        game = baseline.launch.verify_game(state['game_dir'])
        if args.mode == 'client':
            import local_client
            return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT/'reports')])
        if args.mode == 'controls':
            import test_controls
            return test_controls.main(heading='LocalVSTest actor loading',
                instructions='Use LocalVSTest. At HUD run capture_actor_loading_test.cmd once. Switch to game; hold W after TWO beeps; release after THREE. Save report ZIP here if game closes.')
        path, ok = collect_test(game, state['instance_id'])
        try:
            subprocess.Popen(['explorer.exe', str(path.parent)])
        except OSError:
            pass
        return 0 if ok else 1
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('Actor loading test stopped:', str(error))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

"""Opt-in actor loading capture, sharing one 16 KiB budget with existing state."""
import ctypes
from datetime import datetime, timezone
import os
from pathlib import Path

import actor_loading_observer as actor
import native_rows as nr
from presets import character_presets
import win_reader as win


def snapshot(read_function, base):
    budget = nr.LimitedReader(read_function)
    result = nr.snapshot(budget.exact, base, include_scene=True, include_actor=True,
                         include_character=True, include_owned=True, characters=character_presets(True))
    try:
        engine = nr.locate(budget, base)[1]
        database = budget.u64(engine+0xA2E0)
        player = budget.u64(database+0xD68)
        guid = budget.u64(player+0x18)
        known = next((row for row in character_presets(True) if row['character_id'] == guid), None)
        old = result.get('native_gateway_state', {}).get('player_world_record', {})
        win.require(known is not None and old.get('synthetic_identity_observed') is True
                    and old.get('matching_gateway_character') is True
                    and old.get('local_character_name') == known['name']
                    and old.get('local_faction_id') == known['faction_id'],
                    'Actor loading identity differs from the preceding authenticated local snapshot')
        result['actor_loading'] = actor.actor_loading_state(budget, base, engine, database, player, guid)
    except ValueError as error:
        result['actor_loading'] = dict(available=False, reason=str(error), version=actor.VERSION)
    result.update(format_version=10, read_bytes=budget.bytes, read_limit_bytes=16384)
    return result


def input_state(pid):
    """Only current W high-bit state and foreground PID equality; no key history."""
    user = ctypes.WinDLL('user32', use_last_error=True)
    user.GetForegroundWindow.argtypes = []
    user.GetForegroundWindow.restype = ctypes.c_void_p
    user.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
    user.GetWindowThreadProcessId.restype = ctypes.c_uint32
    user.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user.GetAsyncKeyState.restype = ctypes.c_short
    window = user.GetForegroundWindow()
    foreground = ctypes.c_uint32()
    win.require(bool(window) and bool(user.GetWindowThreadProcessId(window, ctypes.byref(foreground))),
                'Could not sample foreground process')
    return dict(game_is_foreground=foreground.value == pid,
                w_held=bool(user.GetAsyncKeyState(0x57) & 0x8000),
                sampled_utc=datetime.now(timezone.utc).isoformat(), client_consumption_verified=False)


def capture_selected(pid, game, *, sample_input=input_state):
    reader = None
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python on Windows')
        win.require(type(pid) is int and 0 < pid <= 0xFFFFFFFF, 'Invalid PID')
        game = Path(game).resolve(strict=True)
        exe = game/'PlanetSide2_x64.exe'
        win.require(win.file_sha(exe) == win.EXPECTED_SHA256, 'Copied executable differs from the captured build')
        config = game/win.CONFIG
        win.require(config.stat().st_size <= 128*1024, 'Unexpected config size')
        win.check_local_config(config.read_bytes())
        argv = win.process_arguments(pid)
        win.check_arguments(argv)
        win.require(Path(argv[0]).samefile(exe), 'Command-line executable differs from the copied game')
        reader = win.WindowsReader(pid, exe)
        before = sample_input(pid)
        result = snapshot(reader.read, reader.base)
        after = sample_input(pid)
        result.update(dummy_launch_verified=True, captured_utc=datetime.now(timezone.utc).isoformat(),
                      input_before=before, input_after=after)
        return result
    finally:
        if reader is not None:
            reader.close()

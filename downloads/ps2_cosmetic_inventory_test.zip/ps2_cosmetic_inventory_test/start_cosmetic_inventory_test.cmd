@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_cosmetic_inventory_test.py" --mode start
pause

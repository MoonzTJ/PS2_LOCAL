"""Local character records with the captured build's inner payload layout.
Scalar fields and empty containers are checked against the native decoder.
Outer login/session compatibility and usable menu behavior still need a live test.
V29.1 restores V28's zero appearance fields after V29's preview regression.
Definition-table candidates are disabled. Heads and profile IDs remain unresolved.
"""
import struct

SERVER_ID = 101
SERVER_NAME = "MoonSol"
ACCOUNT_CHARACTER_SLOTS = 14
TARGET_WORLD = "Indar"  # Requested target only; shipped alias is zone 2, current-client handoff is unimplemented.
PREVIEW_APPEARANCE_MODE = "v28_zero_fields_restored"
PRESETS = tuple(dict(character_id=0x1000000000000000 + faction,
                    faction_id=faction, home_faction_id=faction,
                    name="Local" + name, server_id=SERVER_ID,
                    battle_rank=1, head_id=0, model_id=0, gender=0)
                for faction, name in ((1, "VS"), (2, "NC"), (3, "TR"), (4, "NSO")))

# Separate opt-in test identity; preserve the original four and their wire bytes.
VS_TEST_PRESET = dict(PRESETS[0], character_id=0x1000000000000101, name='LocalVSTest')


def character_presets(include_vs_test=False):
    return tuple(dict(row) for row in PRESETS + ((VS_TEST_PRESET,) if include_vs_test else ()))


def string(value):
    encoded = value.encode("utf-8")
    return struct.pack("<I", len(encoded)) + encoded


def character_payload(row):
    """Captured decoder RVA F1BE90: string, BB4IB2I, loadout, IIQII?.

    Faction/home faction are separate signed bytes; rank is the next uint32.
    The last nine bytes are a counted empty array, prestige rank and freelance.
    The loadout contains no slots/items; it is not a default inventory.
    """
    payload = string(row["name"]) + struct.pack("<BB4IB2I",
        row["faction_id"], row["home_faction_id"], row["battle_rank"],
        0, 0, 0, 0, 0, 1)
    # Restore the exact V28 appearance and empty loadout bytes. V29's definition
    # IDs decoded correctly but did not produce a usable Windows preview. This
    # nested
    # empty loadout is parsed by native RVAs 993590, 993730 and 9B1D50.
    payload += struct.pack("<IIBII", 0, 0, 1, 0, 0) + string("")
    payload += struct.pack("<4I", 0, 0, 0, 0)  # Three scalars, empty slot map.
    # Two empty maps; last-use date; empty trailing array;
    # prestige rank; freelance flag. The old record omitted the last three.
    payload += struct.pack("<IIQII?", 0, 0, 0, 0, 0, False)
    return payload


def candidate_character_list(enabled=False, record_status=0, *, characters=None):
    """Opcode 0x0c, status=1, no lock bypass, counted historical records."""
    if record_status not in (0, 1):
        raise ValueError("Character record status candidate must be 0 or 1")
    records = []
    if enabled:
        for row in PRESETS if characters is None else characters:
            payload = character_payload(row)
            records.append(struct.pack("<Q6I", row["character_id"], row["server_id"],
                record_status, 0, 0, 1, len(payload)) + payload)
    return b"\x0c" + struct.pack("<IBI", 1, 0, len(records)) + b"".join(records)

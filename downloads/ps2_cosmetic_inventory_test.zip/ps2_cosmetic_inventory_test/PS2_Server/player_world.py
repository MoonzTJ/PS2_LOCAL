"""Minimal current-build SendSelfToClient experiment for known local presets.

The complete empty-collection layout is checked against captured decoder
988940. It is a synthetic player record, not a playable character inventory.
See PLAYER_WORLD_TRACE.md for native validation and unverified gameplay fields.
"""
from __future__ import annotations

import struct

from presets import PRESETS, SERVER_ID, string
import starter_loadout

EMPTY_BODY_BYTES = 796
NAME_LENGTH_OFFSET = 121
EMPTY_LOADOUT_OFFSET_BEFORE_NAME = 554
SEND_SELF_OPCODE = 3


def player_body(selection: dict, *, characters=PRESETS, starter_state=None, owned_probe=False,
                cosmetic_probe=False) -> bytes:
    row = next((row for row in characters
                if row['character_id'] == selection.get('character_guid')), None)
    if (row is None or selection.get('server_id') != SERVER_ID
            or selection.get('character_name') != row['name']):
        raise ValueError('Player record requires a matching local preset handoff')
    # Empty collection counts and zero scalar candidates throughout the
    # current decoder's complete layout. These bytes are generated locally;
    # no captured account, inventory or historical player packet is reused.
    body = bytearray(EMPTY_BODY_BYTES)
    struct.pack_into('<QQ', body, 0, row['character_id'], row['character_id'])
    # Native 966990: low two bits encode additional-byte count, value >> 2.
    body[16] = row['faction_id'] << 2
    # Two finite four-float vectors. Position is a placeholder, not a proven
    # Indar spawn; the second is an identity quaternion candidate.
    struct.pack_into('<4f', body, 77, 0.0, 0.0, 0.0, 1.0)
    struct.pack_into('<4f', body, 93, 0.0, 0.0, 0.0, 1.0)
    body[NAME_LENGTH_OFFSET:NAME_LENGTH_OFFSET + 4] = string(row['name'])
    if starter_state is not None:
        if starter_state['identity'] != row:
            raise ValueError('Starter loadout identity must match the authenticated player')
        section = starter_loadout.encode(starter_state)
        # This offset applies only to this generated body: every preceding
        # variable collection is empty. Native oracle verifies the real cursor.
        offset = EMPTY_LOADOUT_OFFSET_BEFORE_NAME + len(row['name'].encode('utf-8'))
        if body[offset:offset + starter_loadout.EMPTY_SECTION_BYTES] != bytes(starter_loadout.EMPTY_SECTION_BYTES):
            raise ValueError('Expected empty generated loadout section')
        body[offset:offset + starter_loadout.EMPTY_SECTION_BYTES] = section
    if cosmetic_probe and not owned_probe:
        raise ValueError('Cosmetic equipment requires the isolated ownership probe')
    if owned_probe:
        from presets import VS_TEST_PRESET
        import starter_inventory
        if cosmetic_probe:
            import cosmetic_inventory
            starter_inventory = cosmetic_inventory
        if row != VS_TEST_PRESET or starter_state is None:
            raise ValueError('Ownership probe requires the isolated starter character')
        offset = 456 + len(row['name'].encode('utf-8'))
        if body[offset:offset+4] != bytes(4):
            raise ValueError('Expected empty generated equipment section')
        body[offset:offset+4] = starter_inventory.equipment_section()
    return bytes(body)


def send_self_to_client(selection: dict, *, characters=PRESETS, starter_state=None, owned_probe=False,
                        cosmetic_probe=False) -> bytes:
    body = player_body(selection, characters=characters, starter_state=starter_state,
                       owned_probe=owned_probe, cosmetic_probe=cosmetic_probe)
    # Native 9BAF50 validates opcode + counted body and exact outer length.
    return bytes([SEND_SELF_OPCODE]) + struct.pack('<I', len(body)) + body


def profile_fixture() -> bytes:
    return b'V26:synthetic-empty-inventory-player:' + b''.join(
        send_self_to_client(dict(character_guid=row['character_id'],
                                 character_name=row['name'], server_id=SERVER_ID))
        for row in PRESETS)

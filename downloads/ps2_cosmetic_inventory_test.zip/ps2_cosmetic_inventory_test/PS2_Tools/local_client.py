"""Launch the copied native client only after the separate V31 server is ready."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

from console_common import (CONFIG_NAME, CONTROL_PORT, DEFAULT_GAME_DIR, EventLog,
                            LOGIN_PORT, control_request, timestamp, wait_ready)
from local_test import client_status, local_config
from ui_diagnostics import overlay_config, prepare_overlay, OVERLAY_NAME, PATCHED_ABC_SHA256
from diagnostics import NativeDiagnostics
from watermark import Watermark


def prepare_client(game_dir, port, use_overlay=True):
    for name in ("PlanetSide2_x64.exe", "ClientConfig.ini"):
        if not (game_dir / name).is_file():
            raise ValueError(f"Missing {name} in the copied game folder: {game_dir}")
    wanted = local_config((game_dir / "ClientConfig.ini").read_bytes(), port, diagnostic_logging=True)
    if use_overlay:
        wanted = overlay_config(wanted)
    target = game_dir / CONFIG_NAME
    if target.exists():
        if target.read_bytes() != wanted:
            raise ValueError(f"{CONFIG_NAME} differs from this test. Rename that generated file before retrying.")
    if use_overlay:
        prepare_overlay(game_dir, current_config=CONFIG_NAME)
    if not target.exists():
        with target.open("xb") as stream:
            stream.write(wanted)
    return target


def launch_client(game_dir):
    if os.name != "nt":
        raise ValueError("The native game launcher requires Windows")
    return subprocess.Popen([str(game_dir / "PlanetSide2_x64.exe"),
                             f"inifile={CONFIG_NAME}", "sessionid=0",
                             "Internationalization:Locale=en_US"], cwd=str(game_dir))


def run_client(game_dir, control_port, login_port, log_dir, wait_seconds=15, use_overlay=True,
               use_watermark=True, use_native_diagnostics=True):
    print("Checking the separate local server before preparing the copied client...")
    ready = wait_ready(control_port, login_port, wait_seconds)
    instance = ready["instance_id"]
    log = EventLog(log_dir / f"client-{timestamp()}-{instance}.jsonl")
    game = panel = diagnostics = None
    try:
        log.event("server_readiness_verified", server_instance=instance,
                  server_pid=ready.get("server_pid"), login_port=login_port,
                  list_delivery=ready.get("list_delivery", "unverified"),
                  profile_sha256=ready["profile_sha256"], world_loading_implemented=False,
                  backend_zone_data_ready=ready.get("backend_zone_data_ready", False),
                  backend_zone_name=ready.get("backend_zone_name"),
                  backend_zone_id=ready.get("backend_zone_id"))
        target = prepare_client(game_dir, login_port, use_overlay)
        log.event("client_config_prepared", config_name=target.name, display_overlay=use_overlay,
                  ui_overlay_name=OVERLAY_NAME if use_overlay else None,
                  ui_abc_sha256=PATCHED_ABC_SHA256 if use_overlay else None,
                  server_label_fallback="MoonSol" if use_overlay else None,
                  server_label_visible="unverified")
        # Overlay preparation can take time. Recheck the same instance immediately before launching.
        before_launch = control_request(control_port, login_port, "status", instance=instance)
        login_count_at_launch = before_launch.get("status", {}).get("login_request_count", 0)
        handoffs_at_launch = before_launch.get("status", {}).get("gateway", {}).get("handoffs_issued", 0)
        started = time.time()
        game = launch_client(game_dir)
        log.event("client_started", pid=game.pid, session_is_dummy_zero=True)
        if use_watermark:
            try:
                panel = Watermark(game.pid, ready)
                log.event("watermark_created", name="Moon_local", target_pid=game.pid,
                          zone_loaded=False, native_login_complete="unverified")
            except (OSError, ValueError) as exc:
                log.event("watermark_unavailable", error_type=type(exc).__name__, reason=str(exc))
        if use_native_diagnostics:
            diagnostics = NativeDiagnostics(game.pid, game_dir, instance, log_dir, log.event)
            diagnostics.creator_requests_seen = before_launch.get('status', {}).get('creator_capture_requests', 0)
            diagnostics.profile_requests_seen = before_launch.get('status', {}).get('profile_capture_requests', 0)
            diagnostics.creation_requests_seen = before_launch.get('status', {}).get('character_creation_requests', 0)
        try:
            control_request(control_port, login_port, "client_started", instance=instance, pid=game.pid)
        except (OSError, ValueError):
            log.event("server_unreachable_after_launch")
        print("Client launched. Keep the server console open. Close the game when finished.")
        print('V31 TEST: open_test_controls.cmd provides the class/loading capture button.')
        print('Capture once with LocalVS selected, then press Play and wait 70 seconds.')
        print('Capture the loading state once more, then save the report ZIP.')
        print("Check whether the loading title changes to INDAR after the gateway selects zone 2.")
        print("Wait 70 seconds after Play for the three native handoff snapshots.")
        print("Send a screenshot of the resulting screen and the server report ZIP.")
        confirmation = before_launch.get("status", {}).get("gateway", {}).get("world_confirmation_enabled", False)
        print("World confirmation messages: " + ("enabled" if confirmation else "disabled for comparison") + ".")
        print("Playable Indar and new-character saving remain pending.")
        if ready.get("list_delivery") == "requested_only":
            print("V31: wait 90 seconds after reaching the menu. An empty menu can be expected until the client requests lists.")
        server_ok = True
        last_status = None
        next_health = 0
        next_watermark_check = 0
        latest_reply = ready
        login_seen = False
        while game.poll() is None:
            now = time.monotonic()
            if now >= next_health:
                next_health = now + 2
                try:
                    latest_reply = control_request(control_port, login_port, "status", instance=instance)
                    login_seen = (latest_reply.get("status", {}).get("login_request_count", 0)
                                  > login_count_at_launch)
                    ok = True
                except (OSError, ValueError):
                    ok = False
                    latest_reply = None
                if ok != server_ok:
                    server_ok = ok
                    log.event("server_reachable" if ok else "server_connection_lost")
                    if not ok:
                        print("The original server is no longer reachable. Close the game and restart the test.")
                try:
                    status = client_status(game_dir, started)
                except OSError:
                    status = dict(available=False, reason="status marker temporarily unavailable")
                if status != last_status:
                    last_status = status
                    log.event("client_status_snapshot", **status)
            if panel is not None:
                try:
                    was_visible = panel.visible
                    panel.update(latest_reply)
                    if was_visible != panel.visible:
                        log.event("watermark_visibility", visible=panel.visible)
                    if now >= next_watermark_check:
                        next_watermark_check = now + 10
                        log.event("watermark_display_check", **panel.diagnostic_state())
                except (OSError, ValueError) as exc:
                    log.event("watermark_failed", error_type=type(exc).__name__, reason=str(exc))
                    panel.close()
                    panel = None
            if diagnostics is not None:
                latest_status = latest_reply.get('status', {}) if latest_reply else {}
                diagnostics.tick(login_seen=login_seen, handoff_seen=bool(latest_reply and
                    latest_reply.get("status", {}).get("gateway", {}).get("handoffs_issued", 0) > handoffs_at_launch),
                    creator_requests=latest_status.get('creator_capture_requests', 0),
                    profile_requests=latest_status.get('profile_capture_requests', 0),
                    creation_requests=latest_status.get('character_creation_requests', 0))
            time.sleep(0.1)
        log.event("client_exited", pid=game.pid, returncode=game.returncode)
        try:
            control_request(control_port, login_port, "client_exited", instance=instance, pid=game.pid)
        except (OSError, ValueError):
            log.event("server_unreachable_at_client_exit")
        print("Game closed. In the server console, type status, then report or quit. Send its report ZIP.")
    except (OSError, ValueError) as exc:
        log.event("client_test_failed", error_type=type(exc).__name__, reason=str(exc))
        raise
    finally:
        if panel is not None:
            panel.close()
        if diagnostics is not None:
            diagnostics.close()
        log.close()
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-dir", type=Path, default=Path(os.environ.get("PS2_LOCAL_GAME_DIR", DEFAULT_GAME_DIR)))
    parser.add_argument("--port", type=int, default=LOGIN_PORT)
    parser.add_argument("--control-port", type=int, default=CONTROL_PORT)
    parser.add_argument("--wait-seconds", type=float, default=15)
    parser.add_argument("--log-dir", type=Path, default=Path(__file__).resolve().parent / "logs")
    parser.add_argument("--no-ui-diagnostics", action="store_true")
    parser.add_argument("--no-watermark", action="store_true")
    parser.add_argument("--no-native-diagnostics", action="store_true")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535 or not 1 <= args.control_port <= 65535 or args.port == args.control_port:
        parser.error("Use distinct login and control ports in 1..65535")
    if not 0 <= args.wait_seconds <= 60:
        parser.error("Readiness wait must be 0..60 seconds")
    try:
        if os.name != "nt":
            raise ValueError("Run start_local_client.cmd on Windows")
        return run_client(args.game_dir.expanduser().resolve(), args.control_port, args.port,
                          args.log_dir.resolve(), args.wait_seconds, not args.no_ui_diagnostics,
                          not args.no_watermark, not args.no_native_diagnostics)
    except KeyboardInterrupt:
        print("Client monitoring stopped. The server and game remain running; close them when finished.")
        return 130
    except (OSError, ValueError) as exc:
        print(f"Client test could not start/continue: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

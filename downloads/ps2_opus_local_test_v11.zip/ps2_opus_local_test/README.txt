# Opus Local Test v11 — arms-gate timeline (read-only)

v10.2 places LocalVSTest at the warpgate first and activates the VS LA body
8 seconds later. The client's `Logs/FirstPersonArms.log` then reported the arms
"ready for attachments!" with no detach, but Capture Camera two minutes later
still read the arms ready bit clear (flags 0x20) and the camera frozen at the
placement point. v11 keeps the v10.2 server behaviour exactly and adds
**Watch Arms.cmd**, which records how those arms fields change from just after
loading in until 90 seconds later. It only reads; it writes nothing to the game
and calls no game functions.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Run **Watch Arms.cmd**. Leave its window open; it waits for the game.
4. Select **LocalVSTest** and press **Play**. One beep means recording started.
   You are placed at the warpgate after about 5 seconds and the body is
   activated about 8 seconds later. Look around and walk until three beeps.
5. Upload the new `reports/local-arms-watch-….json` and the copied game's
   `Logs/FirstPersonArms.log`. If it crashes, include the newest Logs files.

No bootstrap button is needed; do not use Advanced → Existing bootstrap
diagnostic in this version. Capture Camera.cmd still works as before.
The timeline shows field changes, not proof that arms rendered or the camera
attached; that needs the Windows capture and log together.

"""Read-only timeline of the local actor's first-person arms gate.

v10.2 logged "First person arms actor (...) ready for attachments!" after the
placement, yet camera capture 182750 read actor+30E8 = 0x20 (0x80 clear) two
minutes later. This samples the gate fields densely from before the placement
until well after the activation and keeps only the samples where a field
changed, so a short-lived 0x80 can be told apart from one that never appears.
Nothing is written to the game and no native function is called.
"""
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import secrets

import actor_loading_observer
import native_rows as nr
from presets import VS_TEST_PRESET
import win_reader as win

VERSION = 'arms-gate-timeline-v1'
INTERVAL = 0.25
DURATION = 90.0
WAIT_LIMIT = 600.0
FIELDS = ('flags', 'resource', 'resource_arms_id', 'watcher', 'watcher_owner_matches', 'watcher_pending_raw',
          'camera_vtable_rva', 'camera_target_is_actor', 'camera_cached_arms_id')


def arms_state(read, base):
    """One bounded read of the selected actor's arms fields and the active camera."""
    budget = nr.LimitedReader(read)
    win.require(budget.exact(base+nr.CHAR_ACCESSOR_RVA, len(nr.ACCESSOR_SIGNATURE)) == nr.ACCESSOR_SIGNATURE,
                'Arms watch engine accessor differs')
    engine = nr.locate(budget, base)[1]
    manager = budget.u64(engine+0xB010)
    win.require(manager != 0, 'No actor manager yet')
    actor = budget.u64(manager+0x2450)
    win.require(actor != 0 and budget.u64(manager+0x2458) == VS_TEST_PRESET['character_id'],
                'LocalVSTest is not the selected actor yet')
    win.require(budget.u64(actor) == base+actor_loading_observer.PRIMARY
                and budget.u64(actor+0x200) == VS_TEST_PRESET['character_id'], 'Selected actor is not LocalVSTest')
    row = dict(flags=budget.exact(actor+0x30E8, 1)[0], resource=budget.u64(actor+0x30F8),
               watcher=budget.u64(actor+0x30E0))
    row['resource_arms_id'] = None
    if row['resource']:
        try: row['resource_arms_id'] = budget.u32(row['resource']+0x540)
        except ValueError: row['resource_arms_id'] = 'unreadable'
    row['watcher_owner_matches'] = row['watcher_pending_raw'] = None
    if row['watcher']:
        try:
            row['watcher_owner_matches'] = budget.u64(row['watcher']+0x18) == actor
            row['watcher_pending_raw'] = budget.exact(row['watcher']+0x38, 8).hex()
        except ValueError: row['watcher_owner_matches'] = 'unreadable'
    camera = budget.u64(engine+0xB040)
    row['camera_vtable_rva'] = hex(budget.u64(camera)-base) if camera else None
    row['camera_target_is_actor'] = row['camera_cached_arms_id'] = None
    if row['camera_vtable_rva'] == '0x3436cd8':  # type 19 first person; fields from E7F100
        row['camera_target_is_actor'] = budget.u64(camera+0x258) == actor
        row['camera_cached_arms_id'] = budget.u32(camera+0x3A0)
    win.require(budget.u64(manager+0x2450) == actor and budget.u64(engine+0xB040) == camera,
                'Actor or camera changed during the sample')
    return row


def summarize(changes):
    flags = [c['flags'] for c in changes]
    return dict(change_count=len(changes), flag_values_seen=sorted(set(flags)),
                ready_bit_ever_set=any(f & 0x80 for f in flags),
                camera_cached_arms_id_ever_nonzero=any(c.get('camera_cached_arms_id') for c in changes),
                interpretation='Rows are the first sample and each sample where a field changed. '
                               'Sampling every 0.25 s can miss a state shorter than that.')


def collect(game, output, *, locate_pid=None, sleep=None, clock=None, open_reader=None, beep=None):
    import time
    sleep, clock = sleep or time.sleep, clock or time.monotonic
    if locate_pid is None:
        from native_image_capture import discover_pid as locate_pid
    if beep is None:
        def beep(count):
            import winsound
            for _ in range(count): winsound.Beep(660, 150)
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    result = dict(kind='local-arms-watch', version=VERSION, ok=False, interval_seconds=INTERVAL,
                  duration_seconds=DURATION, changes=[], sample_count=0, read_errors=0,
                  native_calls_performed=False, gameplay_state_changed=False)
    reader = None
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8 or open_reader is not None,
                    'Use 64-bit Python on Windows')
        print('Waiting for the game and LocalVSTest. Press Play now; keep this window open.')
        started = clock(); first = None
        while first is None:
            win.require(clock()-started < WAIT_LIMIT, 'LocalVSTest did not load within ten minutes')
            try:
                if reader is None:
                    pid = locate_pid()
                    if open_reader is None:
                        game = Path(game).resolve(strict=True); exe = game/'PlanetSide2_x64.exe'
                        win.require(win.file_sha(exe) == win.EXPECTED_SHA256, 'Copied executable differs from captured build')
                        config = game/win.CONFIG; win.require(config.stat().st_size <= 128*1024, 'Unexpected config size')
                        win.check_local_config(config.read_bytes()); argv = win.process_arguments(pid); win.check_arguments(argv)
                        win.require(Path(argv[0]).samefile(exe), 'Command-line executable differs from copied game')
                        reader = win.WindowsReader(pid, exe)
                    else: reader = open_reader(pid)
                first = arms_state(reader.read, reader.base)
            except (OSError, ValueError):
                sleep(1.0)
        beep(1); print(f'LocalVSTest found. Recording for {DURATION:.0f} seconds; play normally.')
        result['first_sample_utc'] = datetime.now(timezone.utc).isoformat()
        begin, previous, pointers, raw = clock(), None, {}, first
        while True:
            row = dict(raw, seconds=round(clock()-begin, 3), captured_utc=datetime.now(timezone.utc).isoformat())
            for key in ('resource', 'watcher'):  # Absolute addresses stay local: 0 or a per-run index.
                if row[key]:
                    numbers = pointers.setdefault(key, {})
                    row[key] = numbers.setdefault(row[key], len(numbers)+1)
            result['sample_count'] += 1
            if previous is None or any(row[k] != previous[k] for k in FIELDS):
                result['changes'].append(row); print(row['seconds'], 'flags', hex(row['flags']), 'arms', row['resource_arms_id'])
            previous = row
            if clock()-begin >= DURATION: break
            sleep(INTERVAL)
            try: raw = arms_state(reader.read, reader.base)
            except ValueError as error:
                result['read_errors'] += 1; result.setdefault('first_read_error', str(error))
        result.update(ok=True, summary=summarize(result['changes']))
    except (OSError, ValueError) as error:
        result.update(reason=str(error))
    finally:
        if reader is not None: reader.close()
        try: beep(3)
        except (OSError, ImportError): pass
    target = output/('local-arms-watch-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.json')
    target.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print('Upload this file:', target)
    print('Result:', result['summary'] if result['ok'] else 'stopped: '+str(result.get('reason')))
    return target, result

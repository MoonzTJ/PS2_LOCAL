"""Two menu snapshots and three after handoff, without blocking the panel."""
import json
from pathlib import Path
import subprocess
import sys
import time
from console_common import timestamp


class NativeDiagnostics:
    def __init__(self, pid, game_dir, instance, log_dir, event):
        self.pid, self.game_dir, self.instance = pid, game_dir, instance
        self.log_dir, self.event = log_dir, event
        self.started = time.monotonic()
        self.login_at = None
        self.handoff_at = None
        self.handoff_attempts = 0
        self.normal_attempts = 0
        self.attempts = 0
        self.worker = None
        self.output = None
        self.creator_requests_seen = 0
        self.creation_requests_seen = 0
        self.creator_attempts = 0
        self.profile_requests_seen = 0
        self.profile_attempts = 0
        self.pending_creator_capture = False
        self.pending_profile_capture = False
        self.capture_context = {}

    def _failure(self, reason):
        try:
            with self.output.open('x', encoding='utf-8') as stream:
                json.dump(dict(kind='native_snapshot_failed', reason=reason,
                               server_instance_id=self.instance), stream, indent=2)
        except FileExistsError:
            pass

    def tick(self, login_seen=False, handoff_seen=False, creator_requests=0, creation_requests=0,
             profile_requests=0):
        now = time.monotonic()
        for field, value in (('creator_requests_seen', creator_requests),
                             ('creation_requests_seen', creation_requests)):
            if type(value) is int and 0 <= value <= 65536 and value > getattr(self, field):
                self.pending_creator_capture = True
                setattr(self, field, value)
        if type(profile_requests) is int and 0 <= profile_requests <= 65536 and profile_requests > self.profile_requests_seen:
            self.pending_profile_capture = True
            self.profile_requests_seen = profile_requests
        if login_seen and self.login_at is None:
            self.login_at = now
        if handoff_seen and self.handoff_at is None:
            self.handoff_at = now
        if self.worker is not None:
            code = self.worker.poll()
            if code is None and now - self.worker_started >= 45:
                self.worker.terminate()
                self.worker.wait(timeout=5)
                code = self.worker.returncode
                self._failure('Read-only inspector exceeded its 45-second deadline')
            if code is None:
                return
            if not self.output.exists():
                self._failure('Read-only inspector ended without a snapshot')
            self.event('native_snapshot_worker_finished', returncode=code, file=self.output.name)
            if self.capture_context.get('phase') == 'creator_selection':
                try:
                    if self.output.stat().st_size > 65536:
                        raise ValueError('Oversized native snapshot')
                    result = json.loads(self.output.read_text(encoding='utf-8'))
                    selection = result.get('native_character_creator', {})
                    keys = ('faction_id', 'head_type_id', 'profile_type_id', 'gender', 'selected_server_id')
                    if (result.get('server_instance_id') == self.instance
                            and selection.get('available') is True
                            and all(type(selection.get(key)) is int for key in keys)):
                        self.event('creator_selection_captured', file=self.output.name,
                                   **{key:selection[key] for key in keys}, **self.capture_context)
                    else:
                        self.event('creator_selection_unavailable', file=self.output.name)
                except (OSError, ValueError, AttributeError):
                    self.event('creator_selection_unavailable', file=self.output.name)
            self.worker = None
        is_creator = self.pending_creator_capture and self.creator_attempts < 32
        is_profile = not is_creator and self.pending_profile_capture and self.profile_attempts < 32
        is_handoff = (not is_creator and not is_profile and self.handoff_at is not None and self.handoff_attempts < 3
                      and now >= self.handoff_at + (5, 25, 65)[self.handoff_attempts])
        if is_creator:
            self.pending_creator_capture = False
            self.creator_attempts += 1
        elif is_profile:
            self.pending_profile_capture = False
            self.profile_attempts += 1
        elif not is_handoff:
            if self.normal_attempts >= 2:
                return
            due = ((self.login_at + (5, 25)[self.normal_attempts]) if self.login_at is not None
                   else self.started + (45, 75)[self.normal_attempts])
            if now < due:
                return
            self.normal_attempts += 1
        else:
            self.handoff_attempts += 1
        self.output = self.log_dir / f'native-{timestamp()}-{self.instance}.json'
        self.attempts += 1
        self.worker_started = now
        self.capture_context = dict(phase='creator_selection' if is_creator else 'profile_loading' if is_profile else 'after_character_handoff' if is_handoff else 'scheduled',
                                    creator_capture_request=self.creator_requests_seen,
                                    profile_capture_request=self.profile_requests_seen,
                                    character_creation_request=self.creation_requests_seen)
        try:
            self.worker = subprocess.Popen([
                sys.executable, str(Path(__file__).with_name('native_rows.py')),
                '--pid', str(self.pid), '--game-dir', str(self.game_dir),
                '--instance-id', self.instance, '--output', str(self.output),
                '--capture-phase', self.capture_context['phase'],
                '--creator-request', str(self.creator_requests_seen),
                '--profile-request', str(self.profile_requests_seen),
                '--creation-request', str(self.creation_requests_seen)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.event('native_snapshot_worker_started', attempt=self.attempts, target_pid=self.pid,
                       **self.capture_context)
        except OSError as exc:
            self._failure(f'Inspector could not start: {type(exc).__name__}')
            self.event('native_snapshot_worker_failed', error_type=type(exc).__name__)

    def close(self):
        if self.worker is not None:
            if self.worker.poll() is None:
                self.worker.terminate()
            self.worker.wait(timeout=5)
            if not self.output.exists():
                self._failure('Client monitoring stopped before the inspector completed')
            self.worker = None

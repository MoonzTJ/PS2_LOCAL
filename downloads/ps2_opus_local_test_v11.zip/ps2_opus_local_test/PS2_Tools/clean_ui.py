"""Local UI variant retaining labels/loading fixes without creator diagnostics.

Always rebuild from the original assets into a separate directory. The old
diagnostic overlay and its manifest remain available for historical test builds.
"""
import json
import os
from pathlib import Path
import shutil
import struct
import zlib

import ui_diagnostics as ui
from console_common import CONFIG_NAME
from local_test import local_config

OVERLAY_NAME = 'Assets.local-moonsol-clean-v1'
MANIFEST_NAME = 'local-ui-clean-v1-manifest.json'
VERSION = 'local-ui-clean-v1'


def patch_abc(data):
    ui.require(ui.digest(data) == ui.ABC_SHA256, 'Unsupported original creator ABC')
    start, entries, end, strings = ui.string_pool(data)
    ui.require(len(strings) == 6046, 'Unexpected creator string pool')
    # Preserve the original faction draw and character-row draw, byte for byte.
    pool = ui.u30(len(strings) + 1) + data[entries:end] + ui.u30(7) + b'MoonSol'
    splices = sorted([(start, end, pool)] + ui.server_label_splices(data, len(strings)))
    result = bytearray(); previous = 0
    for left, right, replacement in splices:
        ui.require(previous <= left < right, 'Overlapping creator edits')
        result += data[previous:left] + replacement; previous = right
    result += data[previous:]
    result = bytes(result)
    ui.require(ui.string_pool(result)[3] == strings + ['MoonSol'], 'Creator pool readback differs')
    return result, dict(patched_abc_sha256=ui.digest(result), creator_debug_ui=False,
                        server_label='MoonSol', server_label_id=101,
                        changed_creator_methods=[row[0] for row in ui.SERVER_LABEL_METHODS])


def patch_gfx(data):
    ui.require(ui.digest(data) == ui.GFX_SHA256, 'Unsupported original creator asset')
    declared, payload, (start, end, prefix, abc) = ui.gfx_abc(data)
    changed, details = patch_abc(abc)
    tag = prefix + changed
    replacement = struct.pack('<HI', (82 << 6) | 63, len(tag)) + tag
    delta = len(replacement) - (end - start)
    new_payload = payload[:start] + replacement + payload[end:]
    result = data[:4] + struct.pack('<I', declared + delta) + zlib.compress(new_payload, 9)
    ui.require(new_payload[declared + delta - 8:] == payload[declared - 8:], 'Creator trailer changed')
    ui.require(ui.gfx_abc(result)[2][3] == changed, 'Creator GFX readback differs')
    details.update(original_gfx_sha256=ui.GFX_SHA256, patched_gfx_sha256=ui.digest(result))
    return result, details


def patch_pack(source, target):
    ui.require(not target.exists(), 'Clean archive already exists')
    pack = ui.inspect_pack(source); gfx, details = patch_gfx(pack['gfx'])
    table = bytearray(pack['table'])
    offset = (source.stat().st_size + 255) & ~255
    index = (offset + len(gfx) + 255) & ~255
    struct.pack_into('<QQQII', table, pack['row'] * 32, ui.ASSET_HASH, offset,
                     len(gfx), 16, ui.asset_crc(gfx))
    header = bytearray(pack['header']); struct.pack_into('<QQ', header, 8, index + len(table), index)
    with source.open('rb') as original, target.open('xb') as output:
        shutil.copyfileobj(original, output, 1024 * 1024)
        output.seek(offset); output.write(gfx); output.seek(index); output.write(table)
        output.seek(0); output.write(header)
    from loading_ui import patch_independent_archive
    loading = patch_independent_archive(target)
    checked = ui.inspect_pack(target)
    ui.require(checked['gfx'] == gfx, 'Clean creator archive readback differs')
    old, new = bytearray(pack['table']), bytearray(checked['table'])
    for value in (old, new):
        for row in (pack['row'], loading['loading_asset_row']): value[row*32:(row+1)*32] = bytes(32)
    ui.require(old == new, 'Unrelated UI assets changed')
    details.update(loading, original_pack_sha256=ui.file_digest(source),
                   patched_pack_sha256=ui.file_digest(target))
    return details


def overlay_config(data):
    return ui.overlay_config(data).replace(ui.OVERLAY_NAME.encode(), OVERLAY_NAME.encode())


def prepare_overlay(game):
    resources = game / 'Resources'; source = resources / 'Assets'; target = resources / OVERLAY_NAME
    ui.require(resources.is_dir() and source.is_dir() and not ui.linked(resources) and not ui.linked(source),
               'Expected original Resources/Assets directories in the copied game')
    ui.require_local_checkpoint(game, CONFIG_NAME)
    files = sorted(source.iterdir(), key=lambda p: p.name.casefold())
    ui.require(files and all(p.is_file() and not ui.linked(p) for p in files), 'Unsupported original assets')
    ui.require(any(p.name == ui.PACK_NAME for p in files), 'Original UI archive is missing')
    ui.require(not target.is_symlink() and (not target.exists() or not ui.linked(target)), 'Clean overlay is linked')
    if target.exists():
        manifest = target / MANIFEST_NAME
        ui.require(manifest.is_file() and not ui.linked(manifest) and manifest.stat().st_size < 1024*1024,
                   'Unrecognized clean overlay; preserve it and extract a fresh game copy')
        details = json.loads(manifest.read_text())
        ui.require(details.get('version') == VERSION and details.get('creator_debug_ui') is False
                   and details.get('changed_creator_methods') == [643, 695]
                   and details.get('server_label') == 'MoonSol' and details.get('server_label_id') == 101
                   and details.get('loading_title_fallback') == 'Indar'
                   and details.get('loading_title_requires_native_zone_id') == 2
                   and details.get('source_files') == [p.name for p in files], 'Clean overlay manifest differs')
        ui.require({p.name for p in target.iterdir()} == {p.name for p in files} | {MANIFEST_NAME},
                   'Clean overlay file set differs')
        for path in files:
            destination = target / path.name
            ui.require(destination.is_file() and not ui.linked(destination), 'Clean overlay file is linked/missing')
            if path.name != ui.PACK_NAME: ui.require(os.path.samefile(path, destination), 'Asset identity differs')
        ui.require(not os.path.samefile(source/ui.PACK_NAME, target/ui.PACK_NAME)
                   and (target/ui.PACK_NAME).stat().st_nlink == 1, 'Clean UI archive must be independent')
        ui.require(ui.file_digest(source/ui.PACK_NAME) == details.get('original_pack_sha256')
                   and ui.file_digest(target/ui.PACK_NAME) == details.get('patched_pack_sha256'), 'Clean archive changed')
        return target, details
    ui.require(ui.digest(ui.inspect_pack(source/ui.PACK_NAME)['gfx']) == ui.GFX_SHA256,
               'Unsupported original UI build')
    target.mkdir(); made = []
    try:
        # Track this path before patching so partial archive writes are cleaned up.
        made.append(target/ui.PACK_NAME)
        details = patch_pack(source/ui.PACK_NAME, target/ui.PACK_NAME)
        for path in files:
            if path.name != ui.PACK_NAME:
                destination = target/path.name; os.link(path, destination); made.append(destination)
        details.update(version=VERSION, source_files=[p.name for p in files], windows_rendering='pending')
        manifest = target/MANIFEST_NAME; made.append(manifest)
        with manifest.open('x', encoding='utf-8') as stream: stream.write(json.dumps(details, indent=2)+'\n')
        return target, details
    except BaseException:
        for path in reversed(made):
            if path.exists(): path.unlink()
        target.rmdir()
        raise


def prepare_client(game, port):
    ui.require(game.is_dir() and not ui.linked(game), 'Use an ordinary copied game directory')
    for name in ('PlanetSide2_x64.exe', 'ClientConfig.ini'):
        ui.require((game/name).is_file() and not ui.linked(game/name), 'Missing/linked copied client file: '+name)
    original = (game/'ClientConfig.ini').read_bytes()
    basic = local_config(original, port, diagnostic_logging=True)
    wanted = overlay_config(basic); old_debug = ui.overlay_config(basic)
    target = game/CONFIG_NAME; previous = None
    if target.exists() or target.is_symlink():
        ui.require(target.is_file() and not ui.linked(target) and target.stat().st_nlink == 1,
                   'Generated client configuration must be an independent file')
        previous = target.read_bytes()
        ui.require(previous in (wanted, old_debug, basic), 'Generated configuration has custom changes; preserved')
    prepare_overlay(game)
    if previous == wanted: return target
    if previous is not None:
        backup = game/(CONFIG_NAME+'.before-clean-ui.bak')
        if backup.exists() or backup.is_symlink():
            ui.require(backup.is_file() and not ui.linked(backup) and backup.read_bytes() == previous,
                       'Existing UI configuration backup differs; preserved')
        else:
            with backup.open('xb') as stream: stream.write(previous)
        ui.require(target.read_bytes() == previous, 'Configuration changed during UI preparation')
    temporary = game/(CONFIG_NAME+'.clean-ui.tmp')
    with temporary.open('xb') as stream: stream.write(wanted)
    try:
        ui.require((target.read_bytes() if target.exists() else None) == previous,
                   'Configuration changed during UI preparation')
        os.replace(temporary, target)
    finally:
        if temporary.exists(): temporary.unlink()
    return target

"""Launch local admin accounts and verify the native permission after login."""
import argparse,ctypes
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import secrets,subprocess,sys,time,zipfile
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[1];SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_profile_placement_test as prior
except ModuleNotFoundError:
    import run_profile_placement_test as prior
import local_admin,local_admin_capture as observe,local_admin_observer as observer
from player_world import send_self_to_client
from presets import character_presets,VS_TEST_PRESET
from starter_character import initialize_vs_starter
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from native_image_capture import discover_pid
import win_reader as win
FORMAT='ps2-local-admin-test-v1';SESSION=ROOT/'.local-admin-test-session.json'


@lru_cache(maxsize=1)
def _description_bytes():
    backend=prior.baseline.description()['backend']
    row=VS_TEST_PRESET;packet=send_self_to_client(dict(character_guid=row['character_id'],
        character_name=row['name'],server_id=row['server_id']),characters=character_presets(True),
        starter_state=initialize_vs_starter(row),owned_probe=True,cosmetic_probe=True,admin=True)
    digest=hashlib.sha256(packet).hexdigest()
    for key in ('starter_loadout','vs_test_character'):backend[key]['send_self_sha256']=digest
    return json.dumps(dict(version=FORMAT,backend=backend,local_admin=local_admin.description(character_presets(True)),
        activation=prior.baseline.activation.description(),placement=prior.placement.description(),observer=observer.VERSION),sort_keys=True).encode()


def description():
    return json.loads(_description_bytes())


def verify_bundle(root=ROOT):
    m=json.loads((root/'helper-manifest.json').read_text())
    win.require(m.get('format')==FORMAT and m.get('test_description')==description(),'Extract the complete local admin ZIP again.')
    for name,pin in m['files'].items():
        p=root/name
        win.require(not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(root.resolve())
            and p.stat().st_size==pin['bytes'] and win.file_sha(p)==pin['sha256'],'Admin helper files differ; extract again.')


def verify_ready(ready,instance=None,*,fresh=False):
    prior.baseline.launch.verify_ready(ready,instance);expected=description()
    win.require(ready.get('local_admin')==expected['local_admin']
        and all(ready.get(k)==expected['backend'][k] for k in ('starter_loadout','vs_test_character')),
        'Use the separate local admin server and matching starter record.')
    for key,label in [('owned_inventory_probe',None),('profile_activation_probe','activation'),('profile_placement_probe','placement')]:
        wanted=expected['backend'][key] if label is None else expected[label]
        actual=ready.get(key,{})
        win.require(all(actual.get(k)==v for k,v in wanted.items()),'Admin server probe mode differs')
        if fresh or label is None:
            win.require(actual.get('attempted') is False and actual.get('packets_sent')==0,
                        'Use a fresh admin server; do not repeat uncertain applications.')
    win.require(not ready.get('location_probe',{}).get('enabled'),'Use the isolated admin placement mode')
    return ready


def require_permission(snapshot):
    row=snapshot.get('local_admin_state',{})
    win.require(snapshot.get('format_version')==14 and row.get('available') is True
        and row.get('version')==observer.VERSION and row.get('stable_reread') is True
        and row.get('is_admin_account') is True,'The native admin account permission was not observed; upload this report.')
    # Format14 adds one component; all inherited field contracts stay format13.
    return dict(snapshot,format_version=13)


def collect_test(game,instance,*,output=None,control=control_request,pause=time.sleep,
                 signal=prior.baseline.baseline.signal,locate_pid=discover_pid,
                 snapshotter=observe.capture_selected):
    output=Path(output or ROOT/'reports');output.mkdir(parents=True,exist_ok=True)
    expected=prior.baseline.capture.read_input(Path(__file__).resolve().parent)
    result=dict(kind='local_admin_access_test',format_version=1,ok=False,server_instance_id=instance,
        activation_attempted=False,placement_attempted=False,gameplay_command_execution_verified=False,
        camera_control_verified=False,playable_character_verified=False)
    files={};stage='server_health';pid=None
    def health(expected,instance=instance):
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        old=prior.baseline.capture.server_health(expected,instance=instance)
        return dict(old,**{k:ready[k] for k in ('local_admin','starter_loadout','vs_test_character',
            'owned_inventory_probe','profile_activation_probe','profile_placement_probe')})
    def capture(label):
        path,ok=prior.baseline.capture.collect(game,output,expected,health=health,
            locate_pid=lambda:pid,capture=snapshotter)
        files[label+'.zip']=path.read_bytes();win.require(ok,'Admin capture stopped; upload this report.')
        with zipfile.ZipFile(path) as z:row=json.loads(z.read('local-state.json'))
        win.require(row['server_instance_id']==instance,'Server instance changed')
        return row['native_snapshot']
    try:
        verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance,fresh=True);pid=locate_pid()
        stage='before_capture';before=capture('before');prior.baseline.require_before(require_permission(before))
        prior.baseline.baseline.require_input(before,False)
        stage='activate_profile';result['activation_attempted']=True
        result['activation_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_activation',instance=instance,timeout=2)
        print('Return to the game within eight seconds and stay idle until THREE beeps. No W phase.')
        pause(8);stage='activated_origin_capture';origin=capture('activated-origin');prior.require_origin(require_permission(origin))
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(ready['profile_activation_probe']['packets_sent']==1 and ready['profile_placement_probe']['packets_sent']==0,
                    'Expected one activation and no previous placement')
        stage='apply_profile_placement';result['placement_attempted']=True
        result['placement_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_placement',instance=instance,timeout=2)
        pause(15);stage='placed_capture';placed=capture('placed');prior.require_actor(require_permission(placed),False)
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(ready['profile_activation_probe']['packets_sent']==ready['profile_placement_probe']['packets_sent']==1,
                    'Expected exactly one activation and one placement')
        result.update(ok=True,native_admin_account_permission_observed=True,health_after=ready,
            admin_states={k:s['local_admin_state'] for k,s in [('before',before),('activated-origin',origin),('placed',placed)]})
    except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile,KeyError) as error:
        result.update(stage=stage,error_type=type(error).__name__,windows_error=getattr(error,'winerror',None),
            reason=str(error) if isinstance(error,ValueError) else 'Test stopped; upload the saved report.')
    finally:
        try:signal(3)
        except OSError:pass
    files['admin-access-test.json']=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
    win.require(sum(map(len,files.values()))<=2*1024*1024,'Admin report exceeds size limit')
    manifest=dict(format='ps2-local-admin-report-v1',files={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()})
    path=output/('local-admin-access-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items():z.writestr(n,b)
        z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(path) as z:win.require(z.testzip() is None,'Admin report CRC failed')
    print('Upload this ZIP:',path)
    if not result['ok']:print('Test stopped:',result['reason'])
    return path,result['ok']


def start(game):
    prior.baseline.launch.require_closed_server();reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),'--push-lists','--class-delivery-probe',
        '--vs-test-character','--starter-loadout-references','--cosmetic-inventory-probe','--profile-activation-probe',
        '--profile-placement-probe','--local-admin','--character-state-dir',str(SERVER/'state'),
        '--no-availability-observation','--log-dir',str(reports)],cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30),fresh=True)
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('LocalVSTest -> Play. At3D view run activate_and_capture_admin.cmd once.')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=('start','client','controls','capture'),default='start');args=p.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use64-bit Python on Windows');verify_bundle()
        if args.mode=='start':
            game=prior.baseline.launch.choose_game()
            if game:start(prior.baseline.launch.verify_game(game))
            return 0
        state=json.loads(SESSION.read_text());verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=prior.baseline.launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='Local admin account',instructions='At3D view run activate_and_capture_admin.cmd once. Stay idle until THREE beeps.')
        target,ok=collect_test(game,state['instance_id'])
        try:subprocess.Popen(['explorer.exe',str(target.parent)])
        except OSError:pass
        return 0 if ok else 1
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('Local admin test stopped:',str(error));return 1


if __name__=='__main__':raise SystemExit(main())

"""Launch the isolated Windows identity-only class delivery experiment."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'PS2_Server'
if not SERVER.is_dir():
    SERVER = ROOT
sys.path.insert(0, str(SERVER))

from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready
from profile_probe import PROBE_VERSION, probe_description
import win_reader as win

SESSION = ROOT / '.class-probe-session.json'


def verify_bundle(root=ROOT):
    manifest = json.loads((root / 'helper-manifest.json').read_text(encoding='utf-8'))
    if manifest.get('format') != 'ps2-class-delivery-probe-v1':
        raise ValueError('Extract the complete class delivery probe ZIP again.')
    for name, row in manifest['files'].items():
        path = root / name
        if (path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve())
                or path.stat().st_size != row['bytes']
                or win.file_sha(path) != row['sha256']):
            raise ValueError('Probe files differ from the packaged build. Extract the ZIP again.')
    if manifest['probe'] != probe_description():
        raise ValueError('The packaged probe identity does not match its source/data.')


def require_closed_server():
    listeners = []
    try:
        for port in (20042, 20043, 20044):
            listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            listeners.append(listener)
            if os.name == 'nt':
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            try:
                listener.bind(('127.0.0.1', port))
            except OSError:
                raise ValueError('Close the old local server consoles before starting this probe.') from None
    finally:
        for listener in listeners:
            listener.close()


def verify_ready(ready, instance=None):
    observed = ready.get('class_delivery_probe', {})
    expected = probe_description()
    if (observed.get('enabled') is not True or observed.get('version') != PROBE_VERSION
            or any(observed.get(key) != value for key, value in expected.items())
            or (instance is not None and ready.get('instance_id') != instance)):
        raise ValueError('A different local server answered. Restart using start_class_probe.cmd.')
    return ready


def choose_game():
    try:
        import tkinter as tk
        from tkinter import filedialog
        window = tk.Tk()
        window.withdraw()
        window.attributes('-topmost', True)
        try:
            return filedialog.askdirectory(parent=window,
                title='Choose the copied PlanetSide 2 Local game folder (contains PlanetSide2_x64.exe)')
        finally:
            window.destroy()
    except (ImportError, RuntimeError):
        return input('Copied PlanetSide 2 Local game folder: ').strip().strip('"')


def verify_game(game):
    game = Path(game).expanduser().resolve(strict=True)
    if ROOT.resolve().is_relative_to(game):
        raise ValueError('Extract this helper outside the copied game folder, then retry.')
    if (not (game / 'ClientConfig.ini').is_file()
            or win.file_sha(game / 'PlanetSide2_x64.exe') != win.EXPECTED_SHA256):
        raise ValueError('Choose the matching V31.2 local game copy, not the normal online installation.')
    return game


def start(game):
    require_closed_server()
    reports = ROOT / 'reports'
    reports.mkdir(exist_ok=True)
    command = [sys.executable, str(SERVER / 'local_server.py'), '--push-lists',
               '--class-delivery-probe', '--no-availability-observation', '--log-dir', str(reports)]
    server = subprocess.Popen(command, cwd=str(SERVER), creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready = verify_ready(wait_ready(CONTROL_PORT, LOGIN_PORT, 30))
    except BaseException:
        if server.poll() is None:
            server.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game), instance_id=ready['instance_id'])), encoding='utf-8')
    for mode in ('client', 'controls'):
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--mode', mode],
                         cwd=str(ROOT), creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('CLASS DELIVERY PROBE READY. Use LocalVS and keep its server/client consoles open.')
    print('At the character menu, capture class/loading state, then run capture_probe_timeline.cmd.')
    print('This tests class receipt and loader creation. Complete class data and Indar entry remain pending.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('start', 'client', 'controls', 'timeline'), default='start')
    parser.add_argument('--game-dir', type=Path)
    args = parser.parse_args(argv)
    try:
        if os.name != 'nt' or ctypes.sizeof(ctypes.c_void_p) != 8:
            raise ValueError('Run this helper on Windows with 64-bit Python 3.10 or newer.')
        verify_bundle()
        if args.mode == 'start':
            selected = args.game_dir or choose_game()
            if not selected:
                print('No folder selected. Probe not started.')
                return 0
            start(verify_game(selected))
            return 0
        state = json.loads(SESSION.read_text(encoding='utf-8'))
        verify_ready(control_request(CONTROL_PORT, LOGIN_PORT), state['instance_id'])
        game = verify_game(state['game_dir'])
        if args.mode == 'client':
            import local_client
            return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT / 'reports')])
        if args.mode == 'controls':
            import test_controls
            return test_controls.main()
        import loading_capture
        return loading_capture.main(['--game-dir', str(game), '--output-dir', str(ROOT / 'reports')])
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('Class delivery probe stopped:', error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

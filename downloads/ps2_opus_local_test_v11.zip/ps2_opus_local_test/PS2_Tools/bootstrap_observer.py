"""Read current continent/redeploy prerequisites, without native calls or writes."""
import struct
from character_observer import StableFields
from scene_observer import require_player,require_signatures
import actor_loading_observer as actor
import win_reader as win

VERSION='local-bootstrap-prerequisites-v1'
MAX_RECORDS=16
SIGNATURES={
    0xE06170:bytes.fromhex('488d057942620248890133f648897118'),
    0xE072A0:bytes.fromhex('488b41084885c074180f1f8000000000488b08395110740c488b40084885c075'),
    0x148C4C6:bytes.fromhex('8b05a03cbb02488d153d19ce02f7d08d48f183e13f488b0cca48330cc2'),
    0x12CE6FD:bytes.fromhex('f680f7090000027546'),
    0x12CE71C:bytes.fromhex('488b99082700004885db7424'),
    0x114B1A4:bytes.fromhex('f680f7090000047405'),
}


def singleton(fields,base,counter,table):
    index=(~fields.u32(base+counter)) & 0xffffffff
    win.require(index<64,'Bootstrap singleton index differs from the matching build')
    pointer=fields.u64(base+table+index*8)^fields.u64(base+table+((index-15)&63)*8)
    win.require(pointer==0 or 0x10000<=pointer<0x7fffffffffff,'Bootstrap singleton pointer differs')
    return pointer


def continent_state(read,base,zone_id):
    require_signatures(read,base,{k:v for k,v in SIGNATURES.items() if k in (0xE06170,0xE072A0)})
    f=StableFields(read,4096);manager=f.u64(base+0x41DD050)
    result=dict(available=True,manager_present=bool(manager),zone_id=zone_id,
                current_zone_record_present=None,search_complete=False)
    if manager:
        win.require(f.u64(manager)==base+0x342A3F0,'Continent manager type differs')
        head,tail,count=struct.unpack('<3Q',f.exact(manager+8,24))
        win.require(count<=1024 and ((count==0 and not head and not tail) or (count and head and tail)),
                    'Continent list layout exceeds diagnostic bounds')
        node=head;seen=set();last=0;rows=[];found=None
        for _ in range(min(count,MAX_RECORDS)):
            win.require(node and node not in seen,'Continent list is incomplete or cyclic');seen.add(node)
            record,next_node,previous=struct.unpack('<3Q',f.exact(node,24))
            win.require(record and previous==last,'Continent list linkage differs')
            win.require(f.u64(record)==base+0x342A3D8,'Continent record type differs')
            values=struct.unpack('<7I',f.exact(record+0x10,28))
            row=dict(zone_id=values[0],name_id=values[4],description_id=values[5])
            if values[0]==zone_id:
                win.require(found is None,'Continent zone key is duplicated')
                found=dict(row,flags_raw=f.exact(record+0x100,1)[0],
                           raw_boolean_130=f.exact(record+0x130,1)[0],
                           raw_boolean_131=f.exact(record+0x131,1)[0])
                win.require(found['raw_boolean_130'] in (0,1) and found['raw_boolean_131'] in (0,1),
                            'Continent record booleans differ')
            rows.append(row);last,node=node,next_node
        complete=count<=MAX_RECORDS
        if complete:win.require(not node and last==tail,'Continent list count or tail differs')
        else:win.require(node and node not in seen,'Continent list continuation differs')
        result.update(record_count=count,records=rows,records_inspected=len(rows),search_complete=complete,
                      current_zone_record_present=True if found else False if complete else None,
                      current_zone_record=found)
    else:
        result.update(search_complete=True,current_zone_record_present=False)
    f.verify();result.update(stable_reread=True,native_lookup_called=False,
        game_mode_initialization_verified=False,territory_or_spawn_eligibility_verified=False)
    return result


def redeploy_state(read,base,engine,database,player,guid):
    require_signatures(read,base,{k:v for k,v in SIGNATURES.items() if k not in (0xE06170,0xE072A0)})
    f=StableFields(read,1024)
    win.require(f.u64(engine+0xA2E0)==database and f.u64(database+0xD68)==player
                and f.u64(player+0x18)==guid,'Redeploy player identity differs')
    service=singleton(f,base,0x404016C,0x416DE10)
    system=singleton(f,base,0x4040280,0x4178640)
    win.require(system and system==f.u64(engine+0xB010),'Redeploy system differs from the selected actor manager')
    selected=f.u64(system+0x2450);context=f.u64(system+0x2708)
    win.require(context==0 or 0x10000<=context<0x7fffffffffff,'Redeploy context pointer differs')
    blocked=['settings_service_absent'] if not service else []
    result=dict(available=True,settings_service_present=bool(service),
        settings_lookup_key_hex='359f5227',settings_lookup_result=None,
        selected_actor_present=bool(selected),state_context_present=bool(context),
        context_predicate_a=None,context_predicate_b=None,observer_state=None)
    if not selected:blocked.append('selected_actor_absent')
    else:
        win.require(f.u64(selected)==base+actor.PRIMARY and f.u64(selected+0x17C0)==base+actor.IDENTITY
            and f.u64(selected+0x410)==base+actor.CALLBACKS and f.u64(selected+0x200)==guid
            and f.u64(system+0x2458)==guid,'Redeploy actor type or identity differs')
        raw=f.exact(selected+0x9F7,1)[0]
        result.update(actor_flags_9f7_raw=raw,actor_redeploy_block_bit_02=bool(raw&2),observer_state=bool(raw&4))
        if raw&2:blocked.append('actor_9f7_bit_02_set')
    if not context:blocked.append('state_context_absent')
    f.verify();require_player(read,engine,database,player,guid)
    result.update(stable_reread=True,known_blockers=blocked,
        can_redeploy_predicate=False if blocked else None,actual_ui_button_enabled=None,
        native_predicates_called=False,unknown_checks=['settings_lookup_result','context_predicate_a','context_predicate_b'],
        interpretation='Known prerequisites only. No blocker is not proof of eligibility; the actual UI may have other conditions.')
    return result

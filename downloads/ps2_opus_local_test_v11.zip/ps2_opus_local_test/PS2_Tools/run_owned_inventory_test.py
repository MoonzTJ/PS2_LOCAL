"""Launch the isolated loadout-reference test and export bounded character state."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_class_probe as launch
except ModuleNotFoundError:
    import run_class_probe as launch
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from owned_inventory_test import description
import starter_inventory
from datetime import datetime, timezone
import hashlib
import secrets
import time
from presets import character_presets
import capture_local_state as capture
import native_rows
import win_reader as win

SESSION=ROOT/'.owned-inventory-test-v2-session.json'


def verify_bundle(root=ROOT):
    manifest=json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format')=='ps2-owned-inventory-test-v2'
                and manifest.get('test_description')==description(),
                'Extract the complete owned inventory test ZIP again.')
    for name,entry in manifest['files'].items():
        path=root/name
        win.require(not path.is_symlink() and path.is_file()
                    and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size==entry['bytes'] and win.file_sha(path)==entry['sha256'],
                    'Owned inventory test files differ; extract the ZIP again.')


def verify_ready(ready,instance=None):
    launch.verify_ready(ready,instance)
    expected=description()
    win.require(ready.get('starter_loadout')==expected['starter_loadout']
                and ready.get('vs_test_character')==expected['vs_test_character']
                and all(ready.get('owned_inventory_probe',{}).get(k)==v for k,v in expected['owned_inventory_probe'].items())
                and not ready.get('location_probe',{}).get('enabled'),
                'Use start_owned_inventory_test.cmd with its separate server.')
    return ready


def start(game):
    launch.require_closed_server()
    reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),
        '--push-lists','--class-delivery-probe','--vs-test-character','--starter-loadout-references',
        '--owned-inventory-probe','--character-state-dir',str(SERVER/'state'),'--no-availability-observation','--log-dir',str(reports)],
        cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30))
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],
                         cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Select LocalVSTest, press Play, and keep the game/server open.')
    print('After the world HUD appears, run apply_and_capture_owned_inventory.cmd.')
    print('If loading stays on screen, wait 30 seconds and capture there instead.')
    print('This checks two owned equipment instances; appearance, weapons and movement remain incomplete.')


def require_before(snapshot):
    win.require(snapshot.get('format_version')==9 and snapshot.get('dummy_launch_verified') is True,
                'Use the new ownership capture from this ZIP.')
    world=snapshot.get('native_world_initialization',{})
    gateway=snapshot.get('native_gateway_state',{})
    player=gateway.get('player_world_record',{})
    state=player.get('character_state',{})
    owned=player.get('owned_equipment_state',{})
    mode=owned.get('lookup_mode_raw')
    win.require(type(mode) is int and mode in (0,1),
                'Equipment lookup mode is not yet validated. No items sent; upload this report.')
    win.require(world.get('client_run_state')==27 and world.get('initial_zone_data_complete') is True
        and world.get('received_preload_done_packet') is True and world.get('wait_for_zone_ready_packet') is False
        and gateway.get('native_gateway_authenticated') is True
        and gateway.get('zone_selection',{}).get('received_zone_id')==2
        and player.get('local_character_name')=='LocalVSTest' and player.get('local_faction_id')==1
        and player.get('matching_gateway_character') is True
        and state.get('available') is True and state.get('current_matches_vs_starter') is True
        and state.get('saved_matches_vs_starter') is True
        and state.get('owned_definition_count')==state.get('owned_guid_count')==0
        and owned.get('available') is True and owned.get('stable_reread') is True
        and owned.get('equipment_references_match') is True
        and owned.get('selected_key_raw')==owned.get('owned_guid_count')==0,
        'Ownership prerequisites did not pass. No items sent; upload this report.')
    expected_slots=[dict(slot_id=slot,owned_guid=guid) for slot,_,guid in starter_inventory.ITEMS]
    win.require(owned.get('equipment_rows')==[dict(key=0,slots=expected_slots)],
                'Expected the single test equipment row and exact GUID links. No items sent; upload this report.')
    metadata=owned.get('required_metadata',[])
    win.require(len(metadata)==2 and {row.get('item_definition_id') for row in metadata}=={804621,25}
        and all(row.get('record_present') is True and row.get('native_type')==36
                and row.get('matches_generic_prerequisite') is True for row in metadata),
        'Required generic item metadata was not verified. No items sent; upload this report.')


def collect_test(game,instance,*,collector=capture.collect,control=control_request,pause=time.sleep):
    output=ROOT/'reports';output.mkdir(exist_ok=True)
    expected=capture.read_input(Path(__file__).resolve().parent)
    files={};stage='before_capture'
    result=dict(kind='local_owned_inventory_probe',format_version=2,ok=False,
                server_instance_id=instance,delivery_attempted=False,target=description())
    def health(expected,instance=instance):
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        baseline=capture.server_health(expected,instance=instance)
        return dict(baseline,starter_loadout=ready['starter_loadout'],vs_test_character=ready['vs_test_character'],
                    owned_inventory_probe=ready['owned_inventory_probe'])
    def snapshot(pid,folder):
        return native_rows.capture_selected(pid,folder,include_scene=True,include_actor=True,
            include_character=True,include_owned=True,characters=character_presets(True))
    def collect(label):
        path,ok=collector(game,output,expected,health=health,capture=snapshot)
        files[label+'.zip']=path.read_bytes()
        win.require(ok,'Capture failed; upload this report.')
        with zipfile.ZipFile(path) as archive:return json.loads(archive.read('local-state.json'))
    try:
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(not ready['owned_inventory_probe']['attempted'],'Already attempted; start a fresh run.')
        before=collect('before')
        win.require(before['server_instance_id']==instance,'Server instance changed')
        require_before(before['native_snapshot'])
        stage='apply_owned_items'
        verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        result['delivery_attempted']=True  # A timeout must never trigger an automatic second send.
        result['control_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_owned_probe',instance=instance,timeout=2)
        print('Two-item delivery queued. Waiting five seconds for the after capture.')
        pause(5)
        stage='after_capture'
        after=collect('after')
        win.require(after['server_instance_id']==instance,'Server instance changed')
        result['health_after']=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(result['health_after']['owned_inventory_probe']['packets_sent']==1,
                    'Expected one two-item delivery; upload the report.')
        observed=after['native_snapshot'].get('native_gateway_state',{}).get('player_world_record',{}).get('owned_equipment_state',{})
        result.update(ok=True,both_owned_instances_observed=observed.get('both_owned_instances_match') is True,
                      equipment_references_observed=observed.get('equipment_references_match') is True)
    except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile,KeyError) as exc:
        result.update(stage=stage,error_type=type(exc).__name__,reason=str(exc))
    result.update(playable_character_verified=False,appearance_changed=False,location_sent=False)
    files['owned-inventory-probe.json']=(json.dumps(result,indent=2)+'\n').encode()
    manifest=dict(format='ps2-owned-inventory-probe-report-v1',files={name:
        dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in files.items()})
    path=output/('local-owned-inventory-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,raw in files.items():archive.writestr(name,raw)
        archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    print('Upload this ZIP:',path)
    if not result['ok']:print('Test stopped:',result['reason'])
    else:print('Owned instances observed:',result['both_owned_instances_observed'])
    try:subprocess.Popen(['explorer.exe',str(path.parent)])
    except OSError:pass
    return path,result['ok']


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('start','client','controls','capture'),default='start')
    args=parser.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode=='start':
            selected=launch.choose_game()
            if selected:start(launch.verify_game(selected))
            return 0
        state=json.loads(SESSION.read_text())
        verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='LocalVSTest owned inventory',
                instructions='Use LocalVSTest. After the world HUD appears, run apply_and_capture_owned_inventory.cmd once. Save report ZIP here if the game closes.')
        return 0 if collect_test(game,state['instance_id'])[1] else 1
    except (OSError,ValueError,subprocess.SubprocessError) as exc:
        print('Owned inventory test stopped:',str(exc))
        return 1


if __name__=='__main__':raise SystemExit(main())

"""Apply one native profile19 activation and observe the actual actor state."""
import argparse
import ctypes
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import secrets,subprocess,sys,time,zipfile

ROOT=Path(__file__).resolve().parents[1]
SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_cosmetic_inventory_test as baseline
    from scripts import run_class_probe as launch
except ModuleNotFoundError:
    import run_cosmetic_inventory_test as baseline
    import run_class_probe as launch
import profile_activation as activation
import profile_activation_capture as observe
import active_profile_observer as active
import actor_initialization as initialize
import capture_local_state as capture
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from native_image_capture import discover_pid
import win_reader as win

FORMAT='ps2-profile-activation-test-v1'
SESSION=ROOT/'.profile-activation-session.json'


def description():
    return dict(version=FORMAT,backend=baseline.description(),activation=activation.description(),
                active_profile_observer=active.VERSION,actor_initialization_observer=initialize.VERSION)


def verify_bundle(root=ROOT):
    manifest=json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format')==FORMAT and manifest.get('test_description')==description(),
                'Extract the complete profile activation test ZIP again.')
    for name,row in manifest['files'].items():
        path=root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size==row['bytes'] and win.file_sha(path)==row['sha256'],
                    'Profile activation helper files differ; extract the ZIP again.')


def verify_ready(ready,instance=None,*,fresh=False):
    baseline.verify_ready(ready,instance)
    probe=ready.get('profile_activation_probe',{})
    win.require(all(probe.get(k)==v for k,v in activation.description().items())
                and ready['owned_inventory_probe'].get('attempted') is False
                and ready['owned_inventory_probe'].get('packets_sent')==0,
                'Use the new isolated profile activation server without item delivery.')
    if fresh:
        win.require(probe.get('attempted') is False and probe.get('packets_sent')==0,
                    'Activation was already attempted; upload the report instead of applying again.')
    return ready


def require_before(snapshot):
    win.require(snapshot.get('format_version')==13,'Use the new profile activation capture.')
    baseline.require_before(dict(snapshot,format_version=11))
    player=snapshot['native_gateway_state']['player_world_record']
    win.require(player['owned_equipment_state']['lookup_mode_raw']==1,
                'This activation test requires the observed first-row equipment mode. No activation sent.')
    actor=snapshot.get('actor_initialization',{})
    profile=snapshot.get('active_profile_state',{})
    definitions={r.get('profile_id'):r for r in actor.get('class_records',[])}
    win.require(actor.get('available') is True and actor.get('version')==initialize.VERSION
        and actor.get('identity_stable_reread') is True and actor.get('actor_profile_id')==0
        and actor.get('actor_model_id')==0 and definitions.get(19,{}).get('record_present') is True
        and definitions[19].get('model_ref_28')==definitions[19].get('model_ref_2c')==0
        and profile.get('available') is True and profile.get('version')==active.VERSION
        and profile.get('stable_reread') is True and profile.get('selected_profile_key_raw')==0
        and profile.get('profile19',{}).get('record_present') is False
        and profile['profile19'].get('search_complete') is True,
        'Expected pre-activation actor/cache state did not pass. No activation sent; upload this report.')


def require_after(snapshot,held):
    baseline.require_input(snapshot,held)
    gateway=snapshot.get('native_gateway_state',{});player=gateway.get('player_world_record',{})
    actor=snapshot.get('actor_initialization',{});profile=snapshot.get('active_profile_state',{})
    win.require(snapshot.get('format_version')==13 and snapshot.get('dummy_launch_verified') is True
        and gateway.get('native_gateway_authenticated') is True and player.get('local_character_name')=='LocalVSTest'
        and player.get('matching_gateway_character') is True
        and actor.get('available') is True and actor.get('identity_stable_reread') is True
        and actor.get('version')==initialize.VERSION and actor.get('actor_profile_id')==19
        and profile.get('available') is True and profile.get('version')==active.VERSION
        and profile.get('stable_reread') is True and profile.get('selected_profile_key_raw')==19
        and profile.get('profile19',{}).get('record_present') is True
        and profile['profile19'].get('search_complete') is True,
        'Actor profile19 activation was not observed; upload this report.')


def collect_test(game,instance,*,output=None,collector=capture.collect,control=control_request,
                 pause=time.sleep,beep=baseline.signal,locate_pid=discover_pid,snapshotter=observe.capture_selected):
    output=Path(output or ROOT/'reports');output.mkdir(parents=True,exist_ok=True)
    expected=capture.read_input(Path(__file__).resolve().parent);files={};stage='server_health'
    result=dict(kind='local_profile_activation_test',format_version=1,ok=False,server_instance_id=instance,
                activation_attempted=False,actor_class_activation_observed=False,
                model_mapping_assigned=False,incremental_items_sent=False,playable_character_verified=False)
    def health(expected,instance=instance):
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        row=capture.server_health(expected,instance=instance)
        return dict(row,starter_loadout=ready['starter_loadout'],vs_test_character=ready['vs_test_character'],
                    owned_inventory_probe=ready['owned_inventory_probe'],profile_activation_probe=ready['profile_activation_probe'])
    pid=None
    def collect(label):
        path,ok=collector(game,output,expected,health=health,locate_pid=lambda:pid,capture=snapshotter)
        files[label+'.zip']=path.read_bytes();win.require(ok,'Native capture stopped; upload this report.')
        with zipfile.ZipFile(path) as z:row=json.loads(z.read('local-state.json'))
        win.require(row['server_instance_id']==instance,'Server instance changed')
        return row['native_snapshot']
    try:
        verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance,fresh=True)
        pid=locate_pid();stage='before_capture';before=collect('before');require_before(before)
        stage='apply_profile_activation'
        verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance,fresh=True)
        result['activation_attempted']=True  # Never retry an uncertain application send.
        result['control_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_activation',instance=instance,timeout=2)
        print('One profile activation queued. Return to the GAME now and remain idle.')
        print('At TWO beeps hold W; release only after THREE beeps.')
        pause(8);stage='idle_capture';idle=collect('idle');require_after(idle,False)
        result['actor_class_activation_observed']=True
        beep(2);pause(2);stage='w_held_capture';held=collect('w-held');require_after(held,True)
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(ready['profile_activation_probe']['attempted'] is True
                    and ready['profile_activation_probe']['packets_sent']==1,'Expected exactly one profile activation')
        result.update(ok=True,health_after=ready,
            actor_model_id_after=idle['actor_initialization']['actor_model_id'],
            comparison='Compare actor class/cache and sampled position/resource fields; class activation alone does not verify rendering, grounding or movement.')
    except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile,KeyError) as error:
        result.update(stage=stage,error_type=type(error).__name__,windows_error=getattr(error,'winerror',None),
                      reason=str(error) if isinstance(error,ValueError) else 'Test stopped; upload the saved report.')
    finally:
        try:beep(3)
        except OSError:pass
    files['profile-activation-test.json']=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
    win.require(sum(map(len,files.values()))<=2*1024*1024,'Profile activation report exceeds export limit')
    manifest=dict(format='ps2-profile-activation-report-v1',files={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()})
    target=output/('local-profile-activation-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,raw in files.items():z.writestr(name,raw)
        z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:win.require(z.testzip() is None,'Profile activation report ZIP check failed')
    print('Upload this ZIP:',target)
    if not result['ok']:print('Test stopped:',result['reason'])
    return target,result['ok']


def start(game):
    launch.require_closed_server();reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),'--push-lists','--class-delivery-probe',
        '--vs-test-character','--starter-loadout-references','--cosmetic-inventory-probe','--profile-activation-probe',
        '--character-state-dir',str(SERVER/'state'),'--no-availability-observation','--log-dir',str(reports)],
        cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30),fresh=True)
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('LocalVSTest -> Play. At the 3D view run apply_and_capture_profile.cmd once. Read README first.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--mode',choices=('start','client','controls','capture'),default='start')
    args=parser.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode=='start':
            game=launch.choose_game()
            if game:start(launch.verify_game(game))
            return 0
        state=json.loads(SESSION.read_text());verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='LocalVSTest actor profile activation',instructions='At the 3D view run apply_and_capture_profile.cmd once. Return idle; at TWO beeps hold W until THREE beeps.')
        target,ok=collect_test(game,state['instance_id'])
        try:subprocess.Popen(['explorer.exe',str(target.parent)])
        except OSError:pass
        return 0 if ok else 1
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('Profile activation test stopped:',str(error));return 1


if __name__=='__main__':raise SystemExit(main())

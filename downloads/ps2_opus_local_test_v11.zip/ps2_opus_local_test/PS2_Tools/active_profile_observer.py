"""Read the local player's profile19 record used by ActivateProfile, not loadouts."""
from character_observer import StableFields
from scene_observer import require_player, require_signatures
import win_reader as win

VERSION = 'local-active-profile19-v1'
SIGNATURES = {
    # DAB730 queries this profile cache using player+218; node key+C8/link+E0.
    0xDAB730: bytes.fromhex('4c8b81c8010000448b89180200004d85c0'),
    0xDAB760: bytes.fromhex('443988c80000007416488b80e0000000'),
}


def observe(read,base,engine,database,player,guid):
    try:
        require_signatures(read,base,SIGNATURES)
        f = StableFields(read,2048)
        win.require(f.u64(engine+0xA2E0)==database and f.u64(database+0xD68)==player
                    and f.u64(player+0x18)==guid,'Active-profile player identity differs')
        selected=f.u32(player+0x218)
        buckets,capacity=f.u64(player+0x1C0),f.u64(player+0x1C8)
        win.require(capacity<=8192 and (not capacity or (buckets and not capacity & (capacity-1))),
                    'Active-profile cache layout differs')
        node=f.u64(buckets+(19 & (capacity-1))*8) if capacity else 0
        record=dict(profile_id=19,record_present=False,search_complete=False)
        seen=set()
        while node and len(seen)<8:
            win.require(node not in seen,'Active-profile cache chain is cyclic')
            seen.add(node)
            if f.u32(node+0xC8)==19:
                win.require(f.u32(node+4)==19,'Active-profile cache key and profile differ')
                record.update(record_present=True,search_complete=True,
                              raw_field_10=f.u32(node+0x10),raw_field_38=f.u32(node+0x38),
                              raw_flag_byte=f.exact(node,1)[0])
                break
            node=f.u64(node+0xE0)
        if not record['record_present']:
            record['search_complete']=not node
        f.verify();require_player(read,engine,database,player,guid)
        return dict(available=True,version=VERSION,stable_reread=True,
                    selected_profile_key_raw=selected,profile19=record,native_lookup_called=False,
                    playable_character_verified=False)
    except ValueError as error:
        return dict(available=False,version=VERSION,reason=str(error),playable_character_verified=False)

"""Bounded observations of the selected actor's class and native model lookups.

Model references are observed, never assigned. No calls into the game, resource
requests, memory writes or readiness overrides are performed.
"""
import struct

import actor_loading_observer as actor
from character_observer import StableFields
from scene_observer import require_player, require_signatures
import win_reader as win

VERSION = 'selected-actor-class-model-links-v1'
SIGNATURES = {
    # B94380 copies creation descriptor+60 to the actor's class/profile field.
    0xB943EB: bytes.fromhex('8b47608986d8070000'),
    # F79C70: model service +48 -> F79B00, a uint32-keyed robin-hood table.
    0xF79C70: bytes.fromhex('895424104883ec284883c148488d542438e82bab15ff4883c428c3'),
    0xF79B00: bytes.fromhex('4883ec084883790800488bc1750733c04883c408c34c8b51104533c0448b0a49ffca4c8b18498bca4923c948891c24486bc17048bbffffffffffffff7f4903c3488b5068483bd374380f1f8000000000493bd175054439087432488bc1482bc24923c24c3bc0771949ffc048ffc14923ca486bc1704903c3488b5068483bd375cf33c0488b1c244883c408c34883c008488b1c244883c408c3'),
    # FIRST_PERSON_ARMS lookup: chained uint32 map, string value at node+8.
    0xEDF4F0: bytes.fromhex('4533c94c8bc14c3949507426488b497048ffc98bc24823c8498b4068488b04c84885c0740d3910740c488b40204885c075f3498bc14885c0488d4808490f44c9488bc1c3'),
    # Matching actor wrapper calls arms creation with descriptor's model ID.
    0x111DBAA: bytes.fromhex('8b9744050000488bce0fb6d8e8d126fcfe'),
    0x110CB1D: bytes.fromhex('80a7e83000007f488d4c2460e8ade7f8fe908b155b37f302f7d28d4af183e13f'),
}
EMPTY_HASH = 0x7FFFFFFFFFFFFFFF
PROBE_LIMIT = 8


def class_record(fields, manager, identifier):
    result = dict(profile_id=identifier, record_present=False, search_complete=False)
    if not manager:
        return dict(result, manager_present=False)
    count, _, _, buckets, capacity = struct.unpack('<5Q', fields.exact(manager+8, 40))
    win.require(count <= capacity <= 8192 and (not count or
                (buckets and capacity and not capacity & (capacity-1))), 'Class map layout differs')
    node = fields.u64(buckets+(identifier & (capacity-1))*8) if count else 0
    seen = set()
    while node and len(seen) < PROBE_LIMIT:
        win.require(node not in seen, 'Class map chain is cyclic')
        seen.add(node)
        key = fields.u32(node)
        if key == identifier:
            identity = fields.u32(node+8)
            win.require(identity == identifier, 'Class key and record identity differ')
            refs = struct.unpack('<2I', fields.exact(node+8+0x28, 8))
            return dict(result, manager_present=True, record_present=True, search_complete=True,
                        model_ref_28=refs[0], model_ref_2c=refs[1])
        node = fields.u64(node+0xC8)
    return dict(result, manager_present=True, search_complete=not node)


def model_record(fields, manager, identifier):
    result = dict(model_id=identifier, record_present=False, search_complete=False)
    if not manager:
        return dict(result, manager_present=False)
    table, count, capacity = struct.unpack('<3Q', fields.exact(manager+0x48, 24))
    win.require(count <= capacity <= 131072 and (not count or
                (table and capacity and not capacity & (capacity-1))), 'Model map layout differs')
    if not count:
        return dict(result, manager_present=True, search_complete=True)
    mask = capacity-1
    index = identifier & mask
    for distance in range(min(PROBE_LIMIT, capacity)):
        entry = table+index*0x70
        hashed = fields.u64(entry+0x68)
        if hashed == EMPTY_HASH:
            return dict(result, manager_present=True, search_complete=True)
        if hashed == identifier and fields.u32(entry) == identifier:
            record = entry+8
            return dict(result, manager_present=True, record_present=True, search_complete=True,
                        gender_definition_id=fields.u32(record+0x10),
                        actor_definition=actor.definition(fields, record+0x18))
        if distance > ((index-hashed) & mask):
            return dict(result, manager_present=True, search_complete=True)
        index = (index+1) & mask
    return dict(result, manager_present=True)


def arms_record(fields, base, identifier):
    result = dict(model_id=identifier, record_present=False, search_complete=False)
    # Exact pointer encoding used at 110CAC0. Counter is a complemented index.
    index = (~fields.u32(base+0x4040248)) & 0xFFFFFFFF
    win.require(index < 64, 'Arms mapping service index differs')
    table = base+0x4176420
    manager = fields.u64(table+index*8) ^ fields.u64(table+((index-15) & 63)*8)
    if not manager:
        return dict(result, manager_present=False)
    count = fields.u64(manager+0x50)
    buckets, capacity = struct.unpack('<2Q', fields.exact(manager+0x68, 16))
    win.require(count <= capacity <= 131072 and (not count or
                (buckets and capacity and not capacity & (capacity-1))), 'Arms map layout differs')
    node = fields.u64(buckets+(identifier & (capacity-1))*8) if count else 0
    seen = set()
    while node and len(seen) < PROBE_LIMIT:
        win.require(node not in seen, 'Arms map chain is cyclic')
        seen.add(node)
        if fields.u32(node) == identifier:
            return dict(result, manager_present=True, record_present=True, search_complete=True,
                        arms_definition=actor.definition(fields, node+8))
        node = fields.u64(node+0x20)
    return dict(result, manager_present=True, search_complete=not node)


def observe(read, base, engine, database, player, guid):
    result = dict(available=False, version=VERSION, native_lookup_called=False,
                  class_assignment_verified=False, resource_request_observed=False,
                  playable_character_verified=False)
    try:
        require_signatures(read, base, SIGNATURES)
        roots = StableFields(read, 2048)
        win.require(roots.u64(engine+0xA2E0) == database and roots.u64(database+0xD68) == player
                    and roots.u64(player+0x18) == guid, 'Initialization player identity differs')
        manager = roots.u64(engine+0xB010)
        selected = roots.u64(manager+0x2450)
        win.require(selected and roots.u64(selected) == base+actor.PRIMARY
                    and roots.u64(selected+0x17C0) == base+actor.IDENTITY
                    and roots.u64(selected+0x410) == base+actor.CALLBACKS
                    and roots.u64(selected+0x200) == guid and roots.u64(manager+0x2458) == guid,
                    'Initialization actor type or identity differs')
        profile_id = roots.u32(selected+0x7D8)
        model_id = roots.u32(selected+0x17AC)
        class_manager = roots.u64(engine+0xB190)
        model_manager = roots.u64(engine+0xB098)
        result.update(actor_profile_id=profile_id, actor_model_id=model_id,
                      actor_profile_matches_vs_starter=profile_id == 19,
                      expected_vs_starter_profile_id=19)
        queries = set([model_id])
        fields = StableFields(read, 4096)
        classes = [class_record(fields, class_manager, key) for key in sorted({profile_id, 19})]
        for row in classes:
            if row['record_present']:
                queries.update((row['model_ref_28'], row['model_ref_2c']))
        models = [model_record(fields, model_manager, key) for key in sorted(queries)]
        fields.verify()
        result.update(class_records=classes, model_records=models, class_model_links_stable=True)
        try:
            arms = StableFields(read, 2048)
            mapping = arms_record(arms, base, model_id)
            arms.verify()
            result['first_person_arms_mapping'] = dict(available=True, stable_reread=True, **mapping)
        except ValueError as error:
            result['first_person_arms_mapping'] = dict(available=False, reason=str(error))
        roots.verify()
        require_player(read, engine, database, player, guid)
        result.update(available=True, identity_stable_reread=True,
            interpretation='Actor profile is separate from saved/current loadout references. '
            'Model references and mapping strings do not establish applied appearance or resource creation.')
    except ValueError as error:
        result = dict(available=False, version=VERSION, reason=str(error), native_lookup_called=False,
                      playable_character_verified=False)
    return result

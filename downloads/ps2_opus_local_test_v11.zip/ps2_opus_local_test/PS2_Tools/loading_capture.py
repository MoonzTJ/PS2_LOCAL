"""Record bounded packet-router and loading observations from the local client."""
import argparse
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import struct
import subprocess
import time
import zipfile

import win_reader as win
from native_image_capture import discover_pid

BASE = 0x140000000
COUNTER = 0x4040238
TABLE = 0x4175A60
REGISTRY = 0x41AC510
SIGNATURES = {
    0x1755A26: bytes.fromhex('8b050ca88e02f7d08d48f183e13f'),
    0xDE2D90: bytes.fromhex('4d85c00f848e01000048895c2410'),
    0xDE2E3C: bytes.fromhex('488b898000000048896c2450'),
    0xA4D856: bytes.fromhex('c686afaf000001'),
    0xAE07E3: bytes.fromhex('c683afaf000000'),
    0xAE7240: bytes.fromhex('4038aeaeaf0000743a4038aeafaf00007431'),
    0xAE7267: bytes.fromhex('4038aeb0af000075134038ae38a30000740a'),
}
CALLBACK_VTABLES = {0x33D7F08, 0x33D7F30}
HANDLERS = {0x11: 0x2A329, 0x17: 0x1BAC2}


class BoundedReader:
    def __init__(self, read):
        self.read = read
        self.bytes = 0

    def exact(self, address, size):
        win.require(0 < size <= 4096 and 0x10000 <= address <= 0x7FFFFFFFFFFF-size,
                    'Invalid bounded observation address')
        win.require(self.bytes+size <= 32768, 'Loading observation read limit reached')
        self.bytes += size
        data = self.read(address, size)
        win.require(data is not None and len(data) == size, 'A loading observation is unreadable')
        return data

    def u32(self, address):
        return struct.unpack('<I', self.exact(address, 4))[0]

    def u64(self, address):
        return struct.unpack('<Q', self.exact(address, 8))[0]


def listener_state(read, address, base, engine, expected_handler):
    """Native DE22D0 supports three inline slots or a tagged pointer/count array."""
    descriptor = read.exact(address, 32)
    first, count, _, active = struct.unpack('<4Q', descriptor)
    if active:
        return dict(available=False, reason='Listener is being dispatched')
    if first & 1:
        win.require(count <= 64, 'Packet listener count exceeds observation bounds')
        data = read.exact(first & ~1, count*8) if count else b''
        callbacks = struct.unpack('<'+'Q'*count, data) if count else ()
    else:
        data = None
        callbacks = (first, count, struct.unpack_from('<Q', descriptor, 16)[0]) if first else ()
    matches, known, checked = 0, 0, []
    for callback in callbacks:
        if not callback:
            continue
        vtable = read.u64(callback)
        if vtable-base not in CALLBACK_VTABLES:
            checked.append((callback, vtable, None))
            continue
        fields = read.exact(callback+0x10, 20)
        context, function, offset = struct.unpack('<QQi', fields)
        known += 1
        matches += int(context+offset == engine and function == base+expected_handler)
        checked.append((callback, vtable, fields))
    win.require(read.exact(address, 32) == descriptor
                and (data is None or not data or read.exact(first & ~1, count*8) == data)
                and all(read.u64(callback) == vtable
                        and (fields is None or read.exact(callback+0x10, 20) == fields)
                        for callback, vtable, fields in checked),
                'Packet listeners changed during observation')
    return dict(available=True, callback_count=sum(bool(p) for p in callbacks),
                recognized_engine_wrapper_count=known, matching_engine_handler_count=matches)


def packet_handler_state(read, base, engine, opcode):
    registry = base+REGISTRY
    descriptor = read.exact(registry+0x78, 16)
    buckets, capacity = struct.unpack('<2Q', descriptor)
    win.require(capacity <= 8192 and (not capacity or capacity & (capacity-1) == 0),
                'Packet registry capacity exceeds observation bounds')
    node, bucket, visited = 0, None, []
    if capacity:
        bucket = buckets+(opcode & (capacity-1))*8
        node = read.u64(bucket)
    original_node = node
    found = False
    result = dict(available=True, opcode=opcode, registry_entry_present=False)
    for _ in range(16):
        if not node:
            break
        win.require(node not in [row[0] for row in visited], 'Packet registry collision chain is cyclic')
        key, link = read.u32(node), read.u64(node+0x40)
        visited.append((node, key, link))
        if key == opcode:
            found = True
            result.update(registry_entry_present=True, listener=listener_state(read, node+8, base, engine, HANDLERS[opcode]))
            break
        node = link
    win.require(read.exact(registry+0x78, 16) == descriptor
                and (bucket is None or read.u64(bucket) == original_node)
                and all(read.u32(p) == key and read.u64(p+0x40) == link for p, key, link in visited),
                'Packet registry changed during observation')
    result['search_complete'] = found or not node
    return result


def snapshot(read_function, base):
    read = BoundedReader(read_function)
    raw_index = read.u32(base+COUNTER)
    index = (~raw_index) & 0xFFFFFFFF
    win.require(index < 64, 'Engine singleton index differs from the matching build')
    slot1, slot2 = base+TABLE+((index-15) & 63)*8, base+TABLE+index*8
    pointer1, pointer2 = read.u64(slot1), read.u64(slot2)
    engine = pointer1 ^ pointer2
    win.require(engine != 0, 'Local client engine is not initialized')
    state = read.u32(engine+0xA2E8)
    flags = read.exact(engine+0xAFAE, 3)
    profile = read.exact(engine+0xA338, 1)[0]
    profile_gate = read.exact(engine+0xB198, 1)[0]
    win.require(state <= 255 and all(v in (0, 1) for v in (*flags, profile, profile_gate)),
                'Loading fields differ from the matching build')
    manager, loader = read.u64(engine+0xB190), read.u64(engine+0xB1A0)
    class_count = read.u64(manager+8) if manager else None
    win.require(class_count is None or class_count <= 4096, 'Class count exceeds observation bounds')
    registry = base+REGISTRY
    initialized = read.u32(base+0x41AC508) == 0xFFFFFFFF
    routes = dict(initialized=initialized)
    if initialized:
        win.require(read.u64(registry) == base+0x33DB2B0, 'Packet registry type differs from the matching build')
        predispatch = read.u64(registry+8)
        routes.update(predispatch_callback_present=bool(predispatch & ~1),
                      predispatch_callback_busy=bool(predispatch & 1),
                      fallback=listener_state(read, registry+0x10, base, engine, 0x2E843),
                      client_update=packet_handler_state(read, base, engine, 0x11),
                      reference_data=packet_handler_state(read, base, engine, 0x17))
        win.require(read.u64(registry+8) == predispatch, 'Predispatch callback changed during observation')
    win.require(read.u32(base+COUNTER) == raw_index and read.u64(slot1) == pointer1
                and read.u64(slot2) == pointer2 and read.u32(engine+0xA2E8) == state
                and read.exact(engine+0xAFAE, 3) == flags
                and read.exact(engine+0xA338, 1)[0] == profile
                and read.exact(engine+0xB198, 1)[0] == profile_gate
                and read.u64(engine+0xB190) == manager and read.u64(engine+0xB1A0) == loader
                and (manager == 0 or read.u64(manager+8) == class_count),
                'Loading state changed during observation')
    return dict(available=True, client_run_state=state,
                initial_zone_data_complete=bool(flags[0]), received_preload_done_packet=bool(flags[1]),
                wait_for_zone_ready_packet=bool(flags[2]), profile_preload_finished=bool(profile),
                raw_profile_loader_gate=profile_gate, class_definition_count=class_count,
                profile_loader_present=bool(loader), packet_router=routes)


def capture(game, output_root, duration=90):
    win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8,
                'Run this helper with 64-bit Python on the Windows test PC')
    game = game.resolve(strict=True)
    exe = game/'PlanetSide2_x64.exe'
    win.require(win.file_sha(exe) == win.EXPECTED_SHA256, 'Executable differs from the matching V31 build')
    config = game/win.CONFIG
    win.require(config.stat().st_size <= 128*1024, 'Unexpected local config size')
    win.check_local_config(config.read_bytes())
    pid = discover_pid()
    arguments = win.process_arguments(pid)
    win.check_arguments(arguments)
    win.require(Path(arguments[0]).samefile(exe), 'Running game is not from the copied local folder')
    reader = win.WindowsReader(pid, exe)
    try:
        win.require(reader.base == BASE, 'Loaded base differs from the matching build')
        for rva, signature in SIGNATURES.items():
            win.require(reader.read(reader.base+rva, len(signature)) == signature,
                        'Loaded packet/loading code differs from the verified image')
        input('Select LocalVS in the character menu, then press Enter here. ')
        print('Recording now. Switch to the game and click Play once. Leave it open for 90 seconds.', flush=True)
        started_utc = datetime.now(timezone.utc).isoformat()
        started = time.monotonic()
        observations = []
        while True:
            elapsed = time.monotonic()-started
            if elapsed > duration:
                break
            try:
                state = snapshot(reader.read, reader.base)
            except (OSError, ValueError) as error:
                state = dict(available=False, reason=str(error))
            observations.append(dict(elapsed_seconds=round(elapsed, 4),
                                     captured_utc=datetime.now(timezone.utc).isoformat(), **state))
            time.sleep(0.05 if elapsed < 15 else 0.25)
        win.check_arguments(win.process_arguments(pid))
    finally:
        reader.close()
    report = dict(format_version=1, kind='bounded_loading_timeline', source_exe_sha256=win.EXPECTED_SHA256,
                  started_utc=started_utc, duration_seconds=duration, dummy_launch_verified=True,
                  local_config_verified=True, process_access='QUERY_INFORMATION | VM_READ',
                  process_suspended=False, nominal_interval_seconds=[0.05, 0.25], observations=observations,
                  limitation='Polling can miss shorter flag transitions; handler presence does not prove invocation.')
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    archive = output_root/f'local-loading-timeline-{stamp}.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
        zipped.writestr('loading-timeline.json', json.dumps(report, indent=2)+'\n')
    print('\nUpload this ZIP:', archive, sep='\n')
    return output_root


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path, default=Path(win.DEFAULT_GAME))
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent/'captures')
    args = parser.parse_args(argv)
    try:
        output = capture(args.game_dir, args.output_dir)
        try:
            subprocess.Popen(['explorer.exe', str(output)])
        except OSError:
            pass
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(f'Observation stopped: {error}')
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

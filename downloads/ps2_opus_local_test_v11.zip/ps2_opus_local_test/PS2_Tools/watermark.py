"""External, click-through Moon_local status panel for the focused game window."""
import ctypes
import os


def status_lines(reply):
    ready = bool(reply and reply.get('listener_ready') is True)
    port = reply.get('login_port') if ready else None
    gateway = (reply or {}).get('status', {}).get('gateway', {})
    return ('Moon_local',
            f'Local server: ready (UDP {port})' if ready else 'Local server: unreachable',
            'Gateway: login reply sent' if gateway.get('local_login_replies_sent', 0) else 'Native login: unverified',
            'Zone: Indar requested' if gateway.get('zone_details_sent', 0) else 'Zone: not loaded')


def placement(width, height, scale=1):
    panel_w = min(round(360 * scale), max(1, width - 16))
    panel_h = min(round(128 * scale), max(1, height - 16))
    return (max(0, width - panel_w - round(24 * scale)),
            max(0, height - panel_h - round(90 * scale)), panel_w, panel_h)


class Watermark:
    def __init__(self, pid, reply):
        if os.name != 'nt':
            raise ValueError('Moon_local requires Windows')
        from ctypes import wintypes as w
        self.w = w
        self.pid = pid
        self.lines = status_lines(reply)
        self.visible = False
        self.paint_count = 0
        self.visibility_reason = 'waiting_for_game_focus'
        self.last_placement = None
        self.hwnd = None
        self.font = self.title_font = None
        self.brush = None
        self.scale = 1
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        def bind(dll, name, restype, *argtypes):
            fn = getattr(dll, name)
            fn.restype, fn.argtypes = restype, argtypes
            return fn
        self.bind = bind
        self.proc_type = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        class Class(ctypes.Structure):
            _fields_ = [('cbSize', w.UINT), ('style', w.UINT), ('lpfnWndProc', self.proc_type),
                        ('cbClsExtra', ctypes.c_int), ('cbWndExtra', ctypes.c_int),
                        ('hInstance', w.HINSTANCE), ('hIcon', w.HICON), ('hCursor', w.HANDLE),
                        ('hbrBackground', w.HBRUSH), ('lpszMenuName', w.LPCWSTR),
                        ('lpszClassName', w.LPCWSTR), ('hIconSm', w.HICON)]
        class Paint(ctypes.Structure):
            _fields_ = [('hdc', w.HDC), ('fErase', w.BOOL), ('rcPaint', w.RECT),
                        ('fRestore', w.BOOL), ('fIncUpdate', w.BOOL), ('reserved', ctypes.c_byte * 32)]
        self.Paint = Paint
        self.DefWindowProc = bind(self.user, 'DefWindowProcW', ctypes.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        self.BeginPaint = bind(self.user, 'BeginPaint', w.HDC, w.HWND, ctypes.POINTER(Paint))
        self.EndPaint = bind(self.user, 'EndPaint', w.BOOL, w.HWND, ctypes.POINTER(Paint))
        self.GetClientRect = bind(self.user, 'GetClientRect', w.BOOL, w.HWND, ctypes.POINTER(w.RECT))
        self.FillRect = bind(self.user, 'FillRect', ctypes.c_int, w.HDC, ctypes.POINTER(w.RECT), w.HBRUSH)
        self.DrawText = bind(self.user, 'DrawTextW', ctypes.c_int, w.HDC, w.LPCWSTR, ctypes.c_int, ctypes.POINTER(w.RECT), w.UINT)
        self.SelectObject = bind(self.gdi, 'SelectObject', w.HANDLE, w.HDC, w.HANDLE)
        self.SetTextColor = bind(self.gdi, 'SetTextColor', w.DWORD, w.HDC, w.DWORD)
        self.SetBkMode = bind(self.gdi, 'SetBkMode', ctypes.c_int, w.HDC, ctypes.c_int)
        self.DeleteObject = bind(self.gdi, 'DeleteObject', w.BOOL, w.HANDLE)
        self.CreateFont = bind(self.gdi, 'CreateFontW', w.HANDLE, *([ctypes.c_int] * 5), *([w.DWORD] * 8), w.LPCWSTR)
        self.CreateBrush = bind(self.gdi, 'CreateSolidBrush', w.HBRUSH, w.DWORD)
        self.Foreground = bind(self.user, 'GetForegroundWindow', w.HWND)
        self.WindowPid = bind(self.user, 'GetWindowThreadProcessId', w.DWORD, w.HWND, ctypes.POINTER(w.DWORD))
        self.IsIconic = bind(self.user, 'IsIconic', w.BOOL, w.HWND)
        self.ClientToScreen = bind(self.user, 'ClientToScreen', w.BOOL, w.HWND, ctypes.POINTER(w.POINT))
        self.Position = bind(self.user, 'SetWindowPos', w.BOOL, w.HWND, w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.UINT)
        self.Show = bind(self.user, 'ShowWindow', w.BOOL, w.HWND, ctypes.c_int)
        self.Invalidate = bind(self.user, 'InvalidateRect', w.BOOL, w.HWND, ctypes.c_void_p, w.BOOL)
        self.IsVisible = bind(self.user, 'IsWindowVisible', w.BOOL, w.HWND)
        self.Redraw = bind(self.user, 'RedrawWindow', w.BOOL, w.HWND, ctypes.c_void_p, w.HANDLE, w.UINT)
        self.Destroy = bind(self.user, 'DestroyWindow', w.BOOL, w.HWND)
        self.Unregister = bind(self.user, 'UnregisterClassW', w.BOOL, w.LPCWSTR, w.HINSTANCE)
        self.Peek = bind(self.user, 'PeekMessageW', w.BOOL, ctypes.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT)
        self.Translate = bind(self.user, 'TranslateMessage', w.BOOL, ctypes.POINTER(w.MSG))
        self.Dispatch = bind(self.user, 'DispatchMessageW', ctypes.c_ssize_t, ctypes.POINTER(w.MSG))
        self.instance = bind(kernel, 'GetModuleHandleW', w.HMODULE, w.LPCWSTR)(None)
        self.class_name = f'Moon_local_{os.getpid()}'
        # Coordinate conversion remains in this launcher's own process.
        if hasattr(self.user, 'SetProcessDpiAwarenessContext'):
            bind(self.user, 'SetProcessDpiAwarenessContext', w.BOOL, ctypes.c_void_p)(ctypes.c_void_p(-4))
        self.callback = self.proc_type(self._window_proc)
        self.registration = Class(ctypes.sizeof(Class), 0, self.callback, 0, 0, self.instance,
                                  None, None, None, None, self.class_name, None)
        register = bind(self.user, 'RegisterClassExW', w.WORD, ctypes.POINTER(Class))
        if not register(ctypes.byref(self.registration)):
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            self.brush = self.CreateBrush(0x211811)
            self._fonts(1)
            create = bind(self.user, 'CreateWindowExW', w.HWND, w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
                          ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                          w.HWND, w.HMENU, w.HINSTANCE, ctypes.c_void_p)
            # LAYERED | TRANSPARENT | TOOLWINDOW | NOACTIVATE; popup is initially hidden.
            self.hwnd = create(0x080800A0, self.class_name, 'Moon_local', 0x80000000,
                               0, 0, 360, 128, None, None, self.instance, None)
            if not self.hwnd or not self.brush:
                raise ctypes.WinError(ctypes.get_last_error())
            layer = bind(self.user, 'SetLayeredWindowAttributes', w.BOOL, w.HWND, w.DWORD, w.BYTE, w.DWORD)
            if not layer(self.hwnd, 0, 232, 2):
                raise ctypes.WinError(ctypes.get_last_error())
        except BaseException:
            self.close()
            raise

    def _fonts(self, scale):
        for font in (self.font, self.title_font):
            if font:
                self.DeleteObject(font)
        self.font = self.CreateFont(-round(17 * scale), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, 'Segoe UI')
        self.title_font = self.CreateFont(-round(24 * scale), 0, 0, 0, 600, 0, 0, 0, 1, 0, 0, 5, 0, 'Segoe UI')
        if not self.font or not self.title_font:
            raise ctypes.WinError(ctypes.get_last_error())
        self.scale = scale

    def _window_proc(self, hwnd, message, wp, lp):
        if message == 0x21:  # WM_MOUSEACTIVATE
            return 3  # MA_NOACTIVATE
        if message == 0x84:  # WM_NCHITTEST
            return -1  # HTTRANSPARENT
        if message == 0x14:  # WM_ERASEBKGND
            return 1
        if message == 0xF:  # WM_PAINT
            paint = self.Paint()
            dc = self.BeginPaint(hwnd, ctypes.byref(paint))
            try:
                rect = self.w.RECT()
                self.GetClientRect(hwnd, ctypes.byref(rect))
                self.FillRect(dc, ctypes.byref(rect), self.brush)
                self.SetBkMode(dc, 1)
                old = self.SelectObject(dc, self.font)
                y = round(10 * self.scale)
                for index, line in enumerate(self.lines):
                    self.SelectObject(dc, self.title_font if index == 0 else self.font)
                    self.SetTextColor(dc, 0xEFDDD0 if index == 0 else 0xE5E5E5)
                    height = round((32 if index == 0 else 24) * self.scale)
                    text_rect = self.w.RECT(round(14 * self.scale), y, rect.right - 8, y + height)
                    self.DrawText(dc, line, -1, ctypes.byref(text_rect), 0x820)  # single line, no prefix
                    y += height
                self.SelectObject(dc, old)
            finally:
                self.EndPaint(hwnd, ctypes.byref(paint))
            self.paint_count += 1
            return 0
        return self.DefWindowProc(hwnd, message, wp, lp)

    def update(self, reply):
        lines = status_lines(reply)
        changed = lines != self.lines
        self.lines = lines
        front = self.Foreground()
        pid = self.w.DWORD()
        self.WindowPid(front, ctypes.byref(pid))
        if pid.value != self.pid or not front or self.IsIconic(front):
            self.Show(self.hwnd, 0)
            self.visible = False
            self.visibility_reason = 'game_not_focused_or_minimized'
        else:
            rect, origin = self.w.RECT(), self.w.POINT(0, 0)
            if self.GetClientRect(front, ctypes.byref(rect)) and self.ClientToScreen(front, ctypes.byref(origin)):
                scale = 1
                if hasattr(self.user, 'GetDpiForWindow'):
                    dpi = self.bind(self.user, 'GetDpiForWindow', self.w.UINT, self.w.HWND)(front)
                    scale = (dpi or 96) / 96
                if scale != self.scale:
                    self._fonts(scale)
                    changed = True
                x, y, width, height = placement(rect.right, rect.bottom, scale)
                # TOPMOST; NOACTIVATE | SHOWWINDOW. No keyboard/mouse hooks.
                if not self.Position(self.hwnd, self.w.HWND(-1), origin.x + x, origin.y + y, width, height, 0x50):
                    raise ctypes.WinError(ctypes.get_last_error())
                was_visible = self.visible
                self.visible = bool(self.IsVisible(self.hwnd))
                self.visibility_reason = 'visible' if self.visible else 'windows_reports_hidden'
                self.last_placement = dict(x=origin.x+x, y=origin.y+y, width=width, height=height)
                if changed or (self.visible and not was_visible):
                    # INVALIDATE | UPDATENOW: force the first frame to paint.
                    if not self.Redraw(self.hwnd, None, None, 0x101):
                        raise ctypes.WinError(ctypes.get_last_error())
            else:
                self.Show(self.hwnd, 0)
                self.visible = False
                self.visibility_reason = 'game_client_rectangle_unavailable'
        message = self.w.MSG()
        while self.Peek(ctypes.byref(message), self.hwnd, 0, 0, 1):
            self.Translate(ctypes.byref(message))
            self.Dispatch(ctypes.byref(message))

    def diagnostic_state(self):
        return dict(windows_visible=self.visible, paint_count=self.paint_count,
                    reason=self.visibility_reason, placement=self.last_placement,
                    name='Moon_local', overlay_type='external_click_through_window')

    def close(self):
        if self.hwnd:
            self.Destroy(self.hwnd)
            self.hwnd = None
        for value in (self.font, self.title_font, self.brush):
            if value:
                self.DeleteObject(value)
        self.font = self.title_font = self.brush = None
        self.Unregister(self.class_name, self.instance)

"""Run the frozen server and capture new continent/redeploy prerequisites."""
import argparse,ctypes
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import secrets,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1];SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_local_admin_test as baseline
except ModuleNotFoundError:
    import run_local_admin_test as baseline
import bootstrap_capture as observe,bootstrap_observer as observer
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from native_image_capture import discover_pid
import win_reader as win
FORMAT='ps2-bootstrap-test-v1';SESSION=ROOT/'.bootstrap-test-session.json'
SERVER_PROFILE_SHA='3a546e6f7a844d46a9ac5d2052eda3888223abc206c51c50c98ae03c54d32f9b'


def description():
    return dict(version=FORMAT,frozen_backend=baseline.description(),observer=observer.VERSION,
                server_profile_sha256=SERVER_PROFILE_SHA,
                existing_activation_and_placement_unchanged=True,new_application_messages=False)


def verify_ready(ready,instance=None,*,fresh=False):
    baseline.verify_ready(ready,instance,fresh=fresh)
    win.require(ready.get('profile_sha256')==SERVER_PROFILE_SHA,'Bootstrap server profile fingerprint differs')
    return ready


def verify_bundle(root=ROOT):
    m=json.loads((root/'helper-manifest.json').read_text())
    win.require(m.get('format')==FORMAT and m.get('test_description')==description(),'Extract the complete bootstrap ZIP again')
    for name,pin in m['files'].items():
        p=root/name
        win.require(not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(root.resolve())
            and p.stat().st_size==pin['bytes'] and win.file_sha(p)==pin['sha256'],'Bootstrap helper files differ; extract again')


def require_phase(snapshot,phase):
    win.require(snapshot.get('format_version')==1 and snapshot.get('kind')=='local-bootstrap-native-state'
        and snapshot.get('dummy_launch_verified') is True and snapshot.get('identity_stable_reread') is True
        and snapshot.get('character_name')=='LocalVSTest' and snapshot.get('faction_id')==1
        and snapshot.get('zone_selection',{}).get('received_zone_id')==2,'Bootstrap capture identity differs')
    baseline.prior.baseline.baseline.require_input(snapshot,False)
    world=snapshot.get('world',{});actor=snapshot.get('actor_initialization',{})
    active=snapshot.get('active_profile',{});cached=active.get('profile19',{})
    definitions={r.get('profile_id'):r for r in actor.get('class_records',[])}
    definition=definitions.get(19,{})
    win.require(definition.get('record_present') is True and definition.get('model_ref_28')==0
        and definition.get('model_ref_2c')==0 and active.get('available') is True
        and active.get('stable_reread') is True and active.get('selected_profile_key_raw')==(0 if phase=='before' else 19)
        and cached.get('search_complete') is True and cached.get('record_present') is (phase!='before'),
        'Bootstrap class definition or active-profile cache differs')
    char=snapshot.get('character_state',{});owned=snapshot.get('owned_equipment_state',{})
    win.require(char.get('available') is True and char.get('stable_reread') is True
        and char.get('current_matches_vs_starter') is True and char.get('saved_matches_vs_starter') is True
        and char.get('owned_definition_count')==char.get('owned_guid_count')==0
        and owned.get('available') is True and owned.get('stable_reread') is True
        and owned.get('lookup_mode_raw')==1 and owned.get('effective_equipment_row_key')==0
        and owned.get('selected_key_raw')==(0 if phase=='before' else 19)
        and owned.get('owned_guid_count')==0 and owned.get('equipment_references_match') is True,
        'Bootstrap starter/equipment prerequisites differ')
    win.require(world.get('client_run_state')==27 and world.get('initial_zone_data_complete') is True
        and world.get('profile_preload_finished') is True and world.get('wait_for_zone_ready_packet') is False
        and actor.get('available') is True and actor.get('identity_stable_reread') is True
        and actor.get('actor_profile_id')==(0 if phase=='before' else 19), 'Bootstrap phase actor/loading identity differs')
    if phase!='placed':
        win.require(world.get('received_preload_done_packet') is True and actor.get('actor_model_id')==0,
                    'Initial preload/model baseline differs before bootstrap setup')
    if phase=='activated-origin':
        motion=snapshot.get('actor_loading',{}).get('motion',{})
        win.require(motion.get('available') is True and motion.get('transform_cache_clean') is True
            and motion.get('position_f32')==[0,0,0,1],'Expected class19 origin before placement')
    win.require(type(snapshot.get('read_bytes')) is int and 0<snapshot['read_bytes']<=16384
        and snapshot.get('read_limit_bytes')==16384,'Bootstrap snapshot budget differs')


def collect_test(game,instance,*,output=None,control=control_request,pause=time.sleep,
                 signal=baseline.prior.baseline.baseline.signal,locate_pid=discover_pid,
                 snapshotter=observe.capture_selected):
    output=Path(output or ROOT/'reports');output.mkdir(parents=True,exist_ok=True)
    result=dict(kind='local_bootstrap_test',format_version=1,ok=False,server_instance_id=instance,
        activation_attempted=False,placement_attempted=False,new_application_messages_sent=False,
        game_mode_fix_verified=False,playable_character_verified=False)
    files={};stage='server_health';pid=None
    def ready(*,fresh=False):
        return verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance,fresh=fresh)
    def health_state(h):
        return {k:h[k] for k in ('instance_id','profile_sha256','class_delivery_probe','local_admin',
            'starter_loadout','vs_test_character','owned_inventory_probe','profile_activation_probe','profile_placement_probe')}
    def capture(phase):
        before=ready();snapshot=snapshotter(pid,game);after=ready()
        win.require(health_state(before)==health_state(after),'Server state changed during bootstrap snapshot')
        for key,count in [('profile_activation_probe',int(phase!='before')),('profile_placement_probe',int(phase=='placed'))]:
            win.require(after[key]['attempted'] is bool(count) and after[key]['packets_sent']==count,'Unexpected bootstrap setup applications')
        files[phase+'.json']=(json.dumps(dict(server_instance_id=instance,server_health=health_state(after),native_snapshot=snapshot),indent=2,allow_nan=False)+'\n').encode()
        require_phase(snapshot,phase)
        return snapshot
    try:
        ready(fresh=True);pid=locate_pid();stage='before_capture'
        print('Return to the game within eight seconds. Stay idle with menus/map/chat closed until THREE beeps.')
        pause(8);capture('before')
        stage='activate_profile';result['activation_attempted']=True
        result['activation_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_activation',instance=instance,timeout=2)
        verify_ready(result['activation_reply'],instance)
        print('Return to the game within eight seconds. Keep menus/map/chat closed and stay idle until THREE beeps.')
        pause(8);stage='activated_origin_capture';capture('activated-origin')
        stage='place_profile';result['placement_attempted']=True
        result['placement_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_placement',instance=instance,timeout=2)
        verify_ready(result['placement_reply'],instance)
        pause(15);stage='placed_capture';capture('placed');result.update(ok=True,health_after=ready())
    except (OSError,ValueError,subprocess.SubprocessError,KeyError) as error:
        result.update(stage=stage,error_type=type(error).__name__,windows_error=getattr(error,'winerror',None),
            reason=str(error) if isinstance(error,ValueError) else 'Test stopped; upload this report')
    finally:
        try:signal(3)
        except OSError:pass
    files['bootstrap-test.json']=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
    win.require(sum(map(len,files.values()))<=2*1024*1024,'Bootstrap report exceeds size limit')
    manifest=dict(format='ps2-bootstrap-report-v1',files={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()})
    path=output/('local-bootstrap-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items():z.writestr(n,b)
        z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(path) as z:win.require(z.testzip() is None,'Bootstrap report CRC failed')
    print('Upload this ZIP:',path)
    if not result['ok']:print('Test stopped:',result['reason'])
    return path,result['ok']


def start(game):
    baseline.prior.baseline.launch.require_closed_server();reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),'--push-lists','--class-delivery-probe',
        '--vs-test-character','--starter-loadout-references','--cosmetic-inventory-probe','--profile-activation-probe',
        '--profile-placement-probe','--local-admin','--character-state-dir',str(SERVER/'state'),
        '--no-availability-observation','--log-dir',str(reports)],cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:health=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30),fresh=True)
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=health['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('LocalVSTest -> Play. At3D view run capture_bootstrap_test.cmd once.')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=('start','client','controls','capture'),default='start');args=p.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use64-bit Python on Windows');verify_bundle()
        launch=baseline.prior.baseline.launch
        if args.mode=='start':
            game=launch.choose_game()
            if game:start(launch.verify_game(game))
            return 0
        state=json.loads(SESSION.read_text());verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='Bootstrap prerequisites',instructions='At3D view close menus/map/chat. Run capture_bootstrap_test.cmd once; stay idle until THREE beeps.')
        target,ok=collect_test(game,state['instance_id'])
        try:subprocess.Popen(['explorer.exe',str(target.parent)])
        except OSError:pass
        return 0 if ok else 1
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('Bootstrap test stopped:',str(error));return 1


if __name__=='__main__':raise SystemExit(main())

"""Read the selected local actor's verified identity and clean transform cache.

No native getter is called. Dirty caches need the game's own update and remain
unavailable. The source and typed interface pairs are pinned to the local build.
"""
import math
import struct

import win_reader as win
from scene_observer import ACTOR_SIGNATURES, require_player, require_signatures


VTABLE_PAIRS = {
    0x33F8740: 0x33F96D0,
    0x3431E48: 0x3432DF8,
    0x343CA70: 0x343DA00,
    0x3491548: 0x3492500,
}
GETTER_SIGNATURES = {
    0x13895: bytes.fromhex('e9c6f4b700'),
    0x81728: bytes.fromhex('e9a3d58b00'),
    0x7B459: bytes.fromhex('e90281b400'),
    0xB92D60: bytes.fromhex('4883ec28488b8918090000e8b8e94eff4883c0304883c428c3'),
    0xBC3560: bytes.fromhex('488b8140eaffff488902488bc2c3'),
    0x1433450: bytes.fromhex('488d88c0170000488b01488d542438ff5020'),
    0x93ECD0: bytes.fromhex(
        '40534883ec60f6818001000001488bd974504881c150010000488d542420e89e1f7aff'
        '0f28000f2983900100000f2848100f298ba00100000f2840200f2983b0010000'
        '0f284830488d839001000083a380010000fe0f298bc00100004883c4605bc3'
        '488d81900100004883c4605bc3'),
}


def actor_transform_state(read, base, engine, database, player, guid):
    result = dict(available=False, actor_position_observed=False,
                  actor_matches_local_character='unverified',
                  actual_view_camera_association_verified=False,
                  valid_spawn_verified=False, collision_verified=False)
    try:
        require_signatures(read, base, ACTOR_SIGNATURES)
        require_signatures(read, base, GETTER_SIGNATURES)
        require_player(read, engine, database, player, guid)
        manager = read.u64(engine + 0xB010)
        win.require(manager != 0, 'Active-world-actor manager is not initialized')
        actor = read.u64(manager + 0x2450)

        def roots():
            win.require(read.u64(engine + 0xB010) == manager
                        and read.u64(manager + 0x2450) == actor,
                        'Selected actor changed during transform observation')
            require_player(read, engine, database, player, guid)

        result['active_world_actor_present'] = bool(actor)
        if not actor:
            roots()
            result['reason'] = 'No active world actor is selected'
            return result
        primary = read.u64(actor)
        # Export only an image-relative type marker, never an arbitrary pointer.
        if 0x32B8000 <= primary - base < 0x32B8000 + 14185472:
            result['primary_vtable_rva'] = hex(primary - base)
        interface_rva = VTABLE_PAIRS.get(primary - base)
        if interface_rva is None:
            win.require(read.u64(actor) == primary, 'Actor type changed during observation')
            roots()
            result.update(supported_actor_type=False, reason='Selected actor type is outside the verified interface pairs')
            return result
        interface = base + interface_rva

        def types():
            win.require(read.u64(actor) == primary
                        and read.u64(actor + 0x17C0) == interface
                        and read.u64(primary + 0x210) == base + 0x13895
                        and read.u64(interface + 0x20) == base + 0x7B459,
                        'Actor position or identity interface differs from the matching build')

        types()
        actor_guid = read.u64(actor + 0x200)
        cached_guid = read.u64(manager + 0x2458)

        def identity():
            win.require(read.u64(actor + 0x200) == actor_guid
                        and read.u64(manager + 0x2458) == cached_guid,
                        'Actor identity changed during transform observation')
            types()
            roots()

        matches = actor_guid == guid
        cache_matches = cached_guid == actor_guid
        result.update(supported_actor_type=True)
        if not matches or not cache_matches:
            identity()
            result.update(actor_matches_local_character=matches,
                          manager_cached_identity_matches_actor=cache_matches,
                          reason='Selected actor and cached identity do not both match the local character')
            return result
        transform = read.u64(actor + 0x918)
        win.require(transform != 0, 'Actor transform is not initialized')
        flags = read.u32(transform + 0x180)
        if flags & 1:
            win.require(read.u32(transform + 0x180) == flags
                        and read.u64(actor + 0x918) == transform,
                        'Actor transform changed during observation')
            identity()
            result.update(actor_matches_local_character=True,
                          manager_cached_identity_matches_actor=True,
                          transform_cache_clean=False,
                          reason='Actor matrix cache is dirty; current position requires the native updater')
            return result
        raw = read.exact(transform + 0x1C0, 16)
        values = struct.unpack('<4f', raw)
        win.require(all(math.isfinite(value) for value in values), 'Actor position cache is nonfinite')
        win.require(read.exact(transform + 0x1C0, 16) == raw
                    and read.u32(transform + 0x180) == flags
                    and read.u64(actor + 0x918) == transform,
                    'Actor position cache changed during observation')
        identity()
        result.update(available=True, actor_position_observed=True,
                      actor_matches_local_character=True,
                      manager_cached_identity_matches_actor=True,
                      transform_cache_clean=True, stable_reread=True,
                      position_f32=list(values),
                      position_raw_u32=list(struct.unpack('<4I', raw)),
                      source='Selected actor virtual+210 clean matrix position row',
                      interpretation='Stable sequential reads of the matching local actor; no atomic snapshot, camera attachment or safe ground is established.')
    except ValueError as error:
        result['reason'] = str(error)
    return result

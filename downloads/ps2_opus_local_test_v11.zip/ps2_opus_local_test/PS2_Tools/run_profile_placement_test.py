"""Compare class19 motion at the origin and after the verified warpgate placement."""
import argparse,ctypes
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import secrets,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1];SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_profile_activation_test as baseline
except ModuleNotFoundError:
    import run_profile_activation_test as baseline
import profile_placement as placement
import location_probe
import win_reader as win
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from native_image_capture import discover_pid

FORMAT='ps2-profile-placement-test-v1'
SESSION=ROOT/'.profile-placement-session.json'


def description():
    return dict(version=FORMAT,activation_backend=baseline.description(),placement=placement.description())


def verify_bundle(root=ROOT):
    manifest=json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format')==FORMAT and manifest.get('test_description')==description(),
                'Extract the complete profile placement test ZIP again.')
    for name,pin in manifest['files'].items():
        path=root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size==pin['bytes'] and win.file_sha(path)==pin['sha256'],
                    'Profile placement helper files differ; extract again.')


def verify_ready(ready,instance=None,*,fresh=False):
    baseline.verify_ready(ready,instance,fresh=fresh)
    probe=ready.get('profile_placement_probe',{})
    win.require(all(probe.get(k)==v for k,v in placement.description().items()),
                'Use the separate profile placement test server.')
    if fresh:
        win.require(probe.get('attempted') is False and probe.get('packets_sent')==0,
                    'Placement was already attempted; upload the saved report.')
    return ready


def require_actor(snapshot,held):
    # No preload flag is forced/re-required after a large location change.
    baseline.require_after(snapshot,held)
    player=snapshot['native_gateway_state']['player_world_record']
    actor=snapshot.get('actor_loading',{});motion=actor.get('motion',{})
    owned=player.get('owned_equipment_state',{});char=player.get('character_state',{})
    win.require(player.get('local_faction_id')==1 and snapshot['native_gateway_state']['zone_selection'].get('received_zone_id')==2
        and char.get('available') is True and char.get('stable_reread') is True
        and char.get('current_matches_vs_starter') is True and char.get('saved_matches_vs_starter') is True
        and char.get('owned_definition_count')==char.get('owned_guid_count')==0
        and owned.get('available') is True and owned.get('stable_reread') is True
        and owned.get('lookup_mode_raw')==1 and owned.get('selected_key_raw')==19
        and owned.get('effective_equipment_row_key')==0 and owned.get('equipment_references_match') is True
        and owned.get('owned_guid_count')==0 and actor.get('available') is True
        and actor.get('identity_stable_reread') is True and motion.get('available') is True
        and motion.get('stable_reread') is True and type(motion.get('transform_cache_clean')) is bool
        and (motion['transform_cache_clean'] is False or len(motion.get('position_f32',[]))==4),
        'Matched class19 actor/transform/starter state was unavailable; upload this report.')


def require_origin(snapshot):
    require_actor(snapshot,False)
    world=snapshot.get('native_world_initialization',{})
    win.require(snapshot['actor_initialization']['actor_model_id']==0
        and snapshot['actor_loading']['motion']['position_f32']==[0,0,0,1]
        and world.get('client_run_state')==27 and world.get('initial_zone_data_complete') is True
        and world.get('received_preload_done_packet') is True and world.get('profile_preload_finished') is True
        and world.get('wait_for_zone_ready_packet') is False,
        'Expected initialized class19 origin baseline did not pass. No placement sent.')


def collect_test(game,instance,*,output=None,collector=baseline.capture.collect,control=control_request,
                 pause=time.sleep,beep=baseline.baseline.signal,locate_pid=discover_pid,
                 snapshotter=baseline.observe.capture_selected):
    output=Path(output or ROOT/'reports');output.mkdir(parents=True,exist_ok=True)
    expected=baseline.capture.read_input(Path(__file__).resolve().parent)
    files={};snapshots={};pid=None;stage='server_health'
    result=dict(kind='local_profile_placement_test',format_version=1,ok=False,server_instance_id=instance,
        activation_attempted=False,placement_attempted=False,incremental_items_sent=False,
        sampled_position_change_is_not_causal_movement_proof=True,playable_character_verified=False)
    def health(expected,instance=instance):
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        old=baseline.capture.server_health(expected,instance=instance)
        return dict(old,**{key:ready[key] for key in ('starter_loadout','vs_test_character','owned_inventory_probe',
                                                   'profile_activation_probe','profile_placement_probe')})
    def capture(label):
        path,ok=collector(game,output,expected,health=health,locate_pid=lambda:pid,capture=snapshotter)
        files[label+'.zip']=path.read_bytes();win.require(ok,'Native capture stopped; upload the saved report.')
        with zipfile.ZipFile(path) as z:row=json.loads(z.read('local-state.json'))
        win.require(row['server_instance_id']==instance,'Server instance changed')
        snapshots[label]=row['native_snapshot'];return snapshots[label]
    try:
        verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance,fresh=True)
        pid=locate_pid();stage='before_capture';before=capture('before');baseline.require_before(before)
        stage='activate_profile';result['activation_attempted']=True
        result['activation_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_activation',instance=instance,timeout=2)
        print('Return to the GAME within eight seconds and remain idle with menus/chat closed.')
        print('At TWO beeps hold W. At ONE beep release W. THREE beeps means finished.')
        pause(8);stage='activated_origin_capture';origin=capture('activated-origin');require_origin(origin)
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(ready['profile_activation_probe']['attempted'] is True and ready['profile_activation_probe']['packets_sent']==1
            and ready['profile_placement_probe']['attempted'] is False and ready['profile_placement_probe']['packets_sent']==0,
            'Expected one activation and no earlier placement.')
        stage='apply_profile_placement';result['placement_attempted']=True
        result['placement_reply']=control(CONTROL_PORT,LOGIN_PORT,'apply_profile_placement',instance=instance,timeout=2)
        pause(15);stage='placed_idle_capture';idle=capture('placed-idle');require_actor(idle,False)
        beep(2);pause(2);stage='placed_held_capture';held=capture('placed-held');require_actor(held,True)
        beep(1);pause(3);stage='placed_released_capture';released=capture('placed-released');require_actor(released,False)
        ready=verify_ready(control(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        win.require(ready['profile_activation_probe']['packets_sent']==ready['profile_placement_probe']['packets_sent']==1
                    and ready['profile_placement_probe']['attempted'] is True,'Expected one activation and one placement')
        positions={name:s['actor_loading']['motion'].get('position_f32') for name,s in snapshots.items() if name!='before'}
        def changed(a,b):
            return positions[a]!=positions[b] if positions[a] is not None and positions[b] is not None else None
        result.update(ok=True,health_after=ready,sampled_positions=positions,
            clean_position_unavailable_phases=[name for name,value in positions.items() if value is None],
            position_changed_after_placement=changed('activated-origin','placed-idle'),
            position_changed_between_idle_and_held=changed('placed-idle','placed-held'),
            position_changed_between_held_and_released=changed('placed-held','placed-released'),
            placement_offset_from_asset_anchor=([positions['placed-idle'][i]-location_probe.POSITION[i] for i in range(4)]
                if positions['placed-idle'] is not None else None),
            comparison='Compare actual position, velocity, grounding and loading fields. No sampled displacement proves input causality, safe floor or camera attachment.')
    except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile,KeyError) as error:
        result.update(stage=stage,error_type=type(error).__name__,windows_error=getattr(error,'winerror',None),
            reason=str(error) if isinstance(error,ValueError) else 'Test stopped; upload the saved report.')
    finally:
        try:beep(3)
        except OSError:pass
    files['profile-placement-test.json']=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
    win.require(sum(map(len,files.values()))<=2*1024*1024,'Placement report exceeds export limit')
    manifest=dict(format='ps2-profile-placement-report-v1',files={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in files.items()})
    target=output/('local-profile-placement-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,raw in files.items():z.writestr(name,raw)
        z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:win.require(z.testzip() is None,'Placement report CRC failed')
    print('Upload this ZIP:',target)
    if not result['ok']:print('Test stopped:',result['reason'])
    return target,result['ok']


def start(game):
    baseline.launch.require_closed_server();reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),'--push-lists','--class-delivery-probe',
        '--vs-test-character','--starter-loadout-references','--cosmetic-inventory-probe','--profile-activation-probe',
        '--profile-placement-probe','--character-state-dir',str(SERVER/'state'),'--no-availability-observation',
        '--log-dir',str(reports)],cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30),fresh=True)
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('LocalVSTest -> Play. At the 3D view run place_and_capture_motion.cmd once.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--mode',choices=('start','client','controls','capture'),default='start')
    args=parser.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode=='start':
            game=baseline.launch.choose_game()
            if game:start(baseline.launch.verify_game(game))
            return 0
        state=json.loads(SESSION.read_text());verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=baseline.launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='Class19 placement and motion',instructions='At 3D view run place_and_capture_motion.cmd once. TWO beeps hold W; ONE beep release; THREE finished.')
        target,ok=collect_test(game,state['instance_id'])
        try:subprocess.Popen(['explorer.exe',str(target.parent)])
        except OSError:pass
        return 0 if ok else 1
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('Profile placement test stopped:',str(error));return 1


if __name__=='__main__':raise SystemExit(main())

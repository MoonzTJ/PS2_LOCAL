"""Observe actor class/model initialization using the frozen cosmetic backend."""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT/'PS2_Server'
if not SERVER.is_dir():
    SERVER = ROOT
sys.path.insert(0, str(SERVER))
try:
    from scripts import run_cosmetic_inventory_test as baseline
except ModuleNotFoundError:
    import run_cosmetic_inventory_test as baseline
import actor_initialization as initialize
import actor_initialization_capture as observe
from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready
import capture_local_state as capture
from native_image_capture import discover_pid
import win_reader as win

FORMAT = 'ps2-character-initialization-test-v1'
SESSION = ROOT/'.character-initialization-session.json'


def description():
    return dict(version=FORMAT, backend=baseline.description(), observer=initialize.VERSION,
                incremental_items_sent=False, gameplay_fix_applied=False)


def verify_bundle(root=ROOT):
    manifest = json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format') == FORMAT and manifest.get('test_description') == description(),
                'Extract the complete character initialization test ZIP again.')
    for name, row in manifest['files'].items():
        path = root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == row['bytes'] and win.file_sha(path) == row['sha256'],
                    'Character initialization helper files differ; extract the ZIP again.')


def verify_ready(ready, instance=None):
    baseline.verify_ready(ready, instance)
    probe = ready['owned_inventory_probe']
    win.require(probe.get('attempted') is False and probe.get('packets_sent') == 0,
                'Start a fresh initialization test server; this diagnostic does not grant items.')
    return ready


def require_capture(snapshot):
    # Reuse the released identity/world/equipment guard without relaxing it.
    win.require(snapshot.get('format_version') == 12, 'Use the new initialization capture.')
    baseline.require_before(dict(snapshot, format_version=11))
    baseline.require_input(snapshot, False)
    row = snapshot.get('actor_initialization', {})
    win.require(row.get('available') is True and row.get('version') == initialize.VERSION
                and row.get('identity_stable_reread') is True
                and row.get('class_model_links_stable') is True,
                'Initialization fields were unavailable; upload this report.')
    # Zero/mismatched class/model IDs and absent definitions are valid findings.
    win.require(type(row.get('actor_profile_id')) is int and type(row.get('actor_model_id')) is int,
                'Initialization ID fields were unavailable; upload this report.')


def signal(count):
    baseline.signal(count)


def collect_test(game, instance, *, output=None, collector=capture.collect, control=control_request,
                 pause=time.sleep, beep=signal, locate_pid=discover_pid, snapshotter=observe.capture_selected):
    output = Path(output or ROOT/'reports')
    output.mkdir(parents=True, exist_ok=True)
    expected = capture.read_input(Path(__file__).resolve().parent)
    files = {}
    result = dict(kind='local_character_initialization_test', format_version=1, ok=False,
                  server_instance_id=instance, incremental_items_sent=False,
                  gameplay_fix_applied=False, playable_character_verified=False)
    stage = 'server_health'

    def health(expected, instance=instance):
        ready = verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        row = capture.server_health(expected, instance=instance)
        return dict(row, starter_loadout=ready['starter_loadout'], vs_test_character=ready['vs_test_character'],
                    owned_inventory_probe=ready['owned_inventory_probe'])

    try:
        verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        pid = locate_pid()
        print('Switch back to the GAME, close menus/chat and remain idle. Wait for THREE beeps.')
        pause(8)
        stage = 'initialization_capture'
        path, ok = collector(game, output, expected, health=health, locate_pid=lambda: pid, capture=snapshotter)
        files['state.zip'] = path.read_bytes()
        win.require(ok, 'Native capture stopped; upload this report.')
        with zipfile.ZipFile(path) as archive:
            row = json.loads(archive.read('local-state.json'))
        win.require(row['server_instance_id'] == instance, 'Server instance changed')
        require_capture(row['native_snapshot'])
        result['health_after'] = verify_ready(control(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        result.update(ok=True, actor_initialization_observed=True,
                      comparison='Read actor class, class model references, model definitions and arms mapping separately; no gameplay fix is asserted.')
    except (OSError, ValueError, subprocess.SubprocessError, zipfile.BadZipFile, KeyError) as error:
        result.update(stage=stage, error_type=type(error).__name__, windows_error=getattr(error, 'winerror', None),
                      reason=str(error) if isinstance(error, ValueError) else 'Capture stopped; upload the saved report.')
    finally:
        try:
            beep(3)
        except OSError:
            pass
    files['initialization-test.json'] = (json.dumps(result, indent=2, allow_nan=False)+'\n').encode()
    win.require(sum(map(len, files.values())) <= 1024*1024, 'Initialization report exceeds export limit')
    manifest = dict(format='ps2-character-initialization-report-v1', files={name:
        dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in files.items()})
    target = output/('local-character-initialization-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.zip')
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in files.items():
            archive.writestr(name, raw)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
    with zipfile.ZipFile(target) as archive:
        win.require(archive.testzip() is None, 'Initialization report ZIP check failed')
    print('Upload this ZIP:', target)
    if not result['ok']:
        print('Capture stopped:', result['reason'])
    return target, result['ok']


def start(game):
    baseline.baseline.launch.require_closed_server()
    reports = ROOT/'reports'
    reports.mkdir(exist_ok=True)
    process = subprocess.Popen([sys.executable, str(SERVER/'local_server.py'), '--push-lists',
        '--class-delivery-probe', '--vs-test-character', '--starter-loadout-references',
        '--cosmetic-inventory-probe', '--character-state-dir', str(SERVER/'state'),
        '--no-availability-observation', '--log-dir', str(reports)],
        cwd=str(SERVER), creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready = verify_ready(wait_ready(CONTROL_PORT, LOGIN_PORT, 30))
    except BaseException:
        if process.poll() is None:
            process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game), instance_id=ready['instance_id'])))
    for mode in ('client', 'controls'):
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--mode', mode],
                         cwd=str(ROOT), creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Select LocalVSTest, press Play, and keep the game/server open.')
    print('At the 3D world view run capture_character_initialization.cmd once.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('start', 'client', 'controls', 'capture'), default='start')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode == 'start':
            game = baseline.baseline.launch.choose_game()
            if game:
                start(baseline.baseline.launch.verify_game(game))
            return 0
        state = json.loads(SESSION.read_text())
        verify_ready(control_request(CONTROL_PORT, LOGIN_PORT), state['instance_id'])
        game = baseline.baseline.launch.verify_game(state['game_dir'])
        if args.mode == 'client':
            import local_client
            return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT/'reports')])
        if args.mode == 'controls':
            import test_controls
            return test_controls.main(heading='Character initialization diagnostic',
                instructions='LocalVSTest -> Play. At the 3D view run capture_character_initialization.cmd. Return to the game and remain idle until THREE beeps.')
        target, ok = collect_test(game, state['instance_id'])
        try:
            subprocess.Popen(['explorer.exe', str(target.parent)])
        except OSError:
            pass
        return 0 if ok else 1
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('Character initialization test stopped:', str(error))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

"""One local test panel, one independent server console, and the copied game."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT/'PS2_Server'
if not SERVER.is_dir(): SERVER = ROOT
sys.path.insert(0, str(SERVER))
try:
    from scripts import run_bootstrap_test as baseline
except ModuleNotFoundError:
    import run_bootstrap_test as baseline
from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready, timestamp
import win_reader as win

FORMAT = 'ps2-local-test-panel-v1'
SESSION = ROOT/'.local-test-session.json'


def console_python():
    executable = Path(sys.executable)
    if executable.name.lower() == 'pythonw.exe': executable = executable.with_name('python.exe')
    win.require(executable.is_file(), 'The matching Python console interpreter is missing')
    return str(executable)


def verify_bundle(root=ROOT):
    manifest = json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format') == FORMAT, 'Extract the complete Local Test panel ZIP')
    for name, pin in manifest['files'].items():
        path = root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == pin['bytes'] and win.file_sha(path) == pin['sha256'],
                    'Local Test files differ; extract the complete ZIP again')


def start_session(game, *, popen=subprocess.Popen, readiness=wait_ready, closed=None):
    (closed or baseline.baseline.prior.baseline.launch.require_closed_server)()
    reports = ROOT/'reports'; reports.mkdir(exist_ok=True)
    python = console_python()
    server = popen([python, str(SERVER/'local_server.py'), '--push-lists', '--class-delivery-probe',
        '--vs-test-character', '--starter-loadout-references', '--cosmetic-inventory-probe',
        '--profile-activation-probe', '--profile-placement-probe', '--local-admin',
        '--character-state-dir', str(SERVER/'state'), '--no-availability-observation', '--log-dir', str(reports)],
        cwd=str(SERVER), creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
    try:
        health = baseline.verify_ready(readiness(CONTROL_PORT, LOGIN_PORT, 30), fresh=True)
        win.require(health.get('server_pid') == server.pid, 'The new server process did not answer')
        state = dict(game_dir=str(game), instance_id=health['instance_id'], server_pid=server.pid)
        SESSION.write_text(json.dumps(state)+'\n')
        path = reports/('client-monitor-'+timestamp()+'.txt')
        with path.open('xb') as log:
            client = popen([python, str(Path(__file__).resolve()), '--client'], cwd=str(ROOT),
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                           stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        return state, client, path
    except BaseException:
        # Only the process started here is stopped; never touch another server/game.
        if server.poll() is None:
            server.terminate(); server.wait(timeout=5)
        raise


def session_request(state, command='health', *, request=control_request):
    health = request(CONTROL_PORT, LOGIN_PORT, instance=state['instance_id'])
    baseline.verify_ready(health, state['instance_id'])
    win.require(health.get('server_pid') == state['server_pid'], 'Server process changed; start a fresh session')
    if command == 'health': return health
    win.require(command in ('capture_creator', 'capture_profiles', 'export_report'), 'Unsupported panel action')
    return request(CONTROL_PORT, LOGIN_PORT, command, instance=state['instance_id'])


def client_main():
    state = json.loads(SESSION.read_text()); session_request(state)
    launch = baseline.baseline.prior.baseline.launch
    game = launch.verify_game(state['game_dir'])
    import local_client
    return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT/'reports'), '--clean-ui', '--no-watermark'])


def panel():
    import tkinter as tk
    from tkinter import filedialog, messagebox
    window = tk.Tk(); window.title('MoonSol Local Test'); window.geometry('540x445')
    window.resizable(False, False)
    status = tk.StringVar(value='Start one local session. The server gets one console; the client monitor runs in the background.')
    selection = tk.StringVar(); results = queue.Queue(); state = None; client = None; busy = False
    selected_game = None; client_exit_notified = False
    tk.Label(window, text='Local Test', font=('Segoe UI', 16, 'bold')).pack(pady=(14, 8))
    tk.Label(window, textvariable=status, wraplength=490, justify='left').pack(fill='x', padx=24, pady=6)
    row = tk.Frame(window); row.pack(fill='x', padx=24, pady=8)
    tk.Entry(row, textvariable=selection, state='readonly').pack(side='left', fill='x', expand=True)
    def choose():
        chosen = filedialog.askdirectory(parent=window, title='Choose the copied PlanetSide 2 Local game folder')
        if chosen: selection.set(chosen)
    browse = tk.Button(row, text='Game folder…', command=choose); browse.pack(side='right')
    buttons = []
    def available():
        start.config(state='normal' if not busy and state is None else 'disabled')
        browse.config(state='normal' if not busy and state is None else 'disabled')
        for button in buttons: button.config(state='normal' if not busy and state is not None else 'disabled')
    def worker(action):
        try:
            if action == 'start':
                game = baseline.baseline.prior.baseline.launch.verify_game(selected_game)
                result = start_session(game)
            elif action == 'bootstrap':
                session_request(state)
                path, ok = baseline.collect_test(Path(state['game_dir']), state['instance_id'], output=ROOT/'reports')
                result = dict(report_path=str(path), ok=ok)
            else: result = session_request(state, action)
            results.put((action, result, None))
        except Exception as error: results.put((action, None, str(error)))
    def run(action):
        nonlocal busy, selected_game
        if busy: return
        if action == 'start' and not selection.get(): choose()
        if action == 'start' and not selection.get(): return
        if action == 'start': selected_game = selection.get()
        if action == 'bootstrap':
            if client is None or client.poll() is not None:
                status.set('The client monitor is not running. Start a fresh session before an advanced capture.'); return
            if not messagebox.askokcancel('Existing bootstrap diagnostic',
                'This runs the existing one-shot class activation and warpgate placement diagnostic. '
                'It is not a character fix. Close map/menus/chat, click OK, then return to the game '
                'within eight seconds and stay idle until THREE beeps. Do not repeat it in this session.', parent=window): return
        busy = True; available()
        status.set('Starting the server and client…' if action == 'start' else
                   'Return to the game within eight seconds; stay idle until THREE beeps.' if action == 'bootstrap' else
                   'Requesting the local server…')
        threading.Thread(target=worker, args=(action,), daemon=True).start()
    start = tk.Button(window, text='Start local session', command=lambda: run('start')); start.pack(fill='x', padx=24, pady=5)
    for text, action in [('Capture class / loading state', 'capture_profiles'),
                         ('Save server report ZIP', 'export_report')]:
        button = tk.Button(window, text=text, command=lambda a=action: run(a)); button.pack(fill='x', padx=24, pady=5); buttons.append(button)
    advanced = tk.Menubutton(window, text='Advanced ▾', relief='raised'); menu = tk.Menu(advanced, tearoff=False)
    menu.add_command(label='Capture selected head / gender', command=lambda: run('capture_creator'))
    menu.add_command(label='Existing bootstrap diagnostic (once)', command=lambda: run('bootstrap'))
    advanced.config(menu=menu); advanced.pack(pady=5); buttons.append(advanced)
    report_text = tk.StringVar(value='Reports appear in the reports folder beside Start Local Test.cmd.')
    tk.Label(window, textvariable=report_text, wraplength=490, justify='left').pack(fill='x', padx=24, pady=8)
    tk.Label(window, text='Keep the server console open. Type quit there when finished.\nClosing this panel does not close the game or server.', wraplength=490).pack(pady=8)
    def receive():
        nonlocal state, client, busy, client_exit_notified
        if client is not None and not busy and not client_exit_notified and client.poll() is not None:
            client_exit_notified = True
            status.set('Client monitor exited. Read its log in reports if the game did not start. Save the server report before quitting the server.')
        try:
            action, result, error = results.get_nowait()
        except queue.Empty:
            window.after(150, receive); return
        busy = False
        if error: status.set('Stopped: '+error)
        elif action == 'start':
            state, client, path = result
            status.set('Select LocalVSTest → Play. Use this panel for captures/reports. Gameplay initialization is still unfinished.')
            report_text.set('Client monitor log: '+path.name)
        elif action in ('export_report', 'bootstrap'):
            report_text.set('Saved: '+str(result['report_path']))
            status.set('Report saved.' if result.get('ok', True) else 'Capture stopped; the failure report was saved.')
        else: status.set('Capture queued. Return to the game and hold the selection for five seconds.')
        available(); window.after(150, receive)
    def close():
        if busy:
            status.set('Wait for the current startup/capture/export to finish before closing this panel.'); return
        window.destroy()
    window.protocol('WM_DELETE_WINDOW', close); available(); window.after(150, receive); window.mainloop()
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--client', action='store_true')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python 3.10+ on Windows')
        verify_bundle()
        return client_main() if args.client else panel()
    except Exception as error:
        message = 'Local Test stopped: '+str(error)
        if os.name == 'nt' and not args.client:
            ctypes.windll.user32.MessageBoxW(None, message, 'MoonSol Local Test', 0x10)
        else: print(message, file=sys.stderr)
        return 1


if __name__ == '__main__': raise SystemExit(main())

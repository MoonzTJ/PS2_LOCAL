"""Bounded read of the named IsAdminAccount field; never invokes game code."""
from character_observer import StableFields
from scene_observer import require_player,require_signatures
import local_admin
import win_reader as win

VERSION='local-admin-account-observer-v1'
SIGNATURES={
    0x989D47:bytes.fromhex('8039000f95c041888673f9070048ff4710'),
    0x1161228:bytes.fromhex('0fb6b973f907008b4318'),
    0x11DCD9E:bytes.fromhex('80b873f9070000750832c0'),
    0x1425904:bytes.fromhex('418b921cb10000'),
}


def observe(read,base,engine,database,player,guid):
    try:
        require_signatures(read,base,SIGNATURES);f=StableFields(read,512)
        win.require(f.u64(engine+0xA2E0)==database and f.u64(database+0xD68)==player
                    and f.u64(player+0x18)==guid,'Admin permission player identity differs')
        value=f.exact(player+local_admin.PLAYER_PERMISSION_OFFSET,1)[0]
        win.require(value in (0,1),'Admin account field is not a decoded boolean')
        name_id=f.u32(engine+0xB11C)
        f.verify();require_player(read,engine,database,player,guid)
        return dict(available=True,version=VERSION,stable_reread=True,is_admin_account=bool(value),
            current_zone_display_name_id=name_id,native_permission_getter_called=False,
            admin_client_build_verified=False,gameplay_command_execution_verified=False)
    except ValueError as error:
        return dict(available=False,version=VERSION,reason=str(error))

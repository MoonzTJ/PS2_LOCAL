"""Opt-in format13, with the same process guards and one16KiB read budget."""
import ctypes
from datetime import datetime,timezone
import os
from pathlib import Path
import active_profile_observer as active
import actor_initialization_capture as initialize
from actor_loading_capture import input_state
import native_rows as nr
import win_reader as win


def snapshot(read_function,base):
    budget=nr.LimitedReader(read_function)
    result=initialize.snapshot(budget.exact,base)
    try:
        win.require(result.get('actor_initialization',{}).get('available') is True,
                    'Active-profile observation requires the matched initialization snapshot')
        engine=nr.locate(budget,base)[1]
        database=budget.u64(engine+0xA2E0);player=budget.u64(database+0xD68);guid=budget.u64(player+0x18)
        result['active_profile_state']=active.observe(budget,base,engine,database,player,guid)
    except ValueError as error:
        result['active_profile_state']=dict(available=False,version=active.VERSION,reason=str(error))
    result.update(format_version=13,read_bytes=budget.bytes,read_limit_bytes=16384)
    return result


def capture_selected(pid,game,*,sample_input=input_state):
    reader=None
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows')
        win.require(type(pid) is int and 0<pid<=0xFFFFFFFF,'Invalid PID')
        game=Path(game).resolve(strict=True);exe=game/'PlanetSide2_x64.exe'
        win.require(win.file_sha(exe)==win.EXPECTED_SHA256,'Copied executable differs from the captured build')
        config=game/win.CONFIG
        win.require(config.stat().st_size<=128*1024,'Unexpected config size');win.check_local_config(config.read_bytes())
        argv=win.process_arguments(pid);win.check_arguments(argv)
        win.require(Path(argv[0]).samefile(exe),'Command-line executable differs from the copied game')
        reader=win.WindowsReader(pid,exe);before=sample_input(pid)
        result=snapshot(reader.read,reader.base)
        result.update(dummy_launch_verified=True,captured_utc=datetime.now(timezone.utc).isoformat(),
                      input_before=before,input_after=sample_input(pid))
        return result
    finally:
        if reader is not None:reader.close()

"""Focused local bootstrap snapshot with one16KiB budget and original process guards."""
import ctypes,os
import struct
from datetime import datetime,timezone
from pathlib import Path
from character_observer import StableFields
from scene_observer import require_player
import active_profile_observer,actor_initialization,actor_loading_observer,bootstrap_observer,local_admin_observer
import local_admin_capture as guard
import native_rows as nr
from presets import character_presets,VS_TEST_PRESET
import win_reader as win


def snapshot(read_function,base):
    budget=nr.LimitedReader(read_function)
    win.require(budget.exact(base+nr.CHAR_ACCESSOR_RVA,len(nr.ACCESSOR_SIGNATURE))==nr.ACCESSOR_SIGNATURE,
                'Bootstrap engine accessor differs')
    engine=nr.locate(budget,base)[1];f=StableFields(budget,512)
    database=f.u64(engine+0xA2E0);player=f.u64(database+0xD68);guid=f.u64(player+0x18)
    win.require(guid==VS_TEST_PRESET['character_id'],'Select LocalVSTest for the bootstrap diagnostic')
    gateway=nr.gateway_zone_state(budget,base,engine,characters=character_presets(True),
        include_character=True,include_owned=True,cosmetic_owned=True)
    row=gateway.get('player_world_record',{});zone=gateway.get('zone_selection',{})
    zone_fields=struct.unpack('<5I',f.exact(engine+0xB110,20))
    win.require(gateway.get('native_gateway_authenticated') is True and row.get('synthetic_identity_observed') is True
        and row.get('matching_gateway_character') is True and row.get('local_character_name')=='LocalVSTest'
        and row.get('local_faction_id')==1 and zone.get('received_zone_id')==zone_fields[1]==2
        and zone.get('received_zone_instance')==zone_fields[2]==2
        and zone.get('received_display_name_id')==zone_fields[3], 'Bootstrap local gateway/player/zone identity differs')
    result=dict(format_version=1,kind='local-bootstrap-native-state',source_exe_sha256=win.EXPECTED_SHA256,
        character_name='LocalVSTest',faction_id=1,zone_selection=zone,
        character_state=row.get('character_state',{}),owned_equipment_state=row.get('owned_equipment_state',{}),
        world=nr.world_initialization_state(budget,base,engine))
    for name,observe in (
        ('continent',lambda:bootstrap_observer.continent_state(budget,base,2)),
        ('redeploy',lambda:bootstrap_observer.redeploy_state(budget,base,engine,database,player,guid)),
        ('admin',lambda:local_admin_observer.observe(budget,base,engine,database,player,guid)),
        ('active_profile',lambda:active_profile_observer.observe(budget,base,engine,database,player,guid)),
        ('actor_initialization',lambda:actor_initialization.observe(budget,base,engine,database,player,guid)),
        ('actor_loading',lambda:actor_loading_observer.actor_loading_state(budget,base,engine,database,player,guid))):
        try:result[name]=observe()
        except ValueError as error:result[name]=dict(available=False,reason=str(error))
    f.verify();require_player(budget,engine,database,player,guid)
    win.require(nr.locate(budget,base)[1]==engine,'Bootstrap engine changed during capture')
    result.update(identity_stable_reread=True,read_bytes=budget.bytes,read_limit_bytes=16384,
                  native_calls_performed=False,gameplay_state_changed=False,playable_character_verified=False)
    return result


def capture_selected(pid,game,*,sample_input=guard.prior.input_state):
    reader=None
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use64-bit Python on Windows')
        win.require(type(pid) is int and 0<pid<=0xffffffff,'Invalid PID')
        game=Path(game).resolve(strict=True);exe=game/'PlanetSide2_x64.exe'
        win.require(win.file_sha(exe)==win.EXPECTED_SHA256,'Copied executable differs from captured build')
        config=game/win.CONFIG;win.require(config.stat().st_size<=128*1024,'Unexpected config size')
        win.check_local_config(config.read_bytes());argv=win.process_arguments(pid);win.check_arguments(argv)
        win.require(Path(argv[0]).samefile(exe),'Command-line executable differs from copied game')
        reader=win.WindowsReader(pid,exe);before=sample_input(pid);result=snapshot(reader.read,reader.base)
        result.update(dummy_launch_verified=True,captured_utc=datetime.now(timezone.utc).isoformat(),
                      input_before=before,input_after=sample_input(pid));return result
    finally:
        if reader is not None:reader.close()

"""Read-only fields named by the pinned client's own Player diagnostic writer.

Arms callback flags describe first-person arms only. No overall actor readiness,
native IsMoving result, input consumption, camera attachment or spawn is inferred.
"""
import math
import struct

from actor_observer import GETTER_SIGNATURES
from character_observer import StableFields
from scene_observer import ACTOR_SIGNATURES, require_player, require_signatures
import win_reader as win

VERSION = 'typed-player-model-and-motion-v1'
PRIMARY = 0x3491548
IDENTITY = 0x3492500
CALLBACKS = 0x3492418
SIGNATURES = {
    0x974E09: bytes.fromhex('4c8d83f8240000488d15c93da602488b4c2440'),
    0x974EAD: bytes.fromhex('8b83ac170000894424644c8d442464488d15553da602'),
    0x975189: bytes.fromhex('8b83a02c00008944246c4c8d44246c488d15c93ba602'),
    0xA42150: bytes.fromhex('f68189240000027411f30f10055f779902f30f5981a01b0000c3f30f1005f2bf9502f30f5981a01b0000c3'),
    0x2FD8D: bytes.fromhex('e92e2d0e01'),
    0xC4D25: bytes.fromhex('e9e6dc0401'),
    0x1112AC0: bytes.fromhex('405355565741564883ec3048c7442420feffffff'),
    0x1112A10: bytes.fromhex('40534883ec20488b81e82c0000488bd9483bd0'),
    0x339E164: struct.pack('<f', 1.0),
    0x33D98C0: struct.pack('<f', 0.25),
}
FLAG_FIELDS = {
    'is_stunned': (0x9F0, 0x02), 'is_knocked_back': (0x9F1, 0x40),
    'is_nonattackable': (0x9F1, 0x80), 'is_pull': (0x9F2, 0x80),
    'is_falling': (0x2485, 0x08), 'is_jumping': (0x2485, 0x04),
    'is_ignoring_collision': (0x2486, 0x40), 'is_swimming': (0x2486, 0x10),
    'is_in_water': (0x17B1, 0x04),
}


def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


def expected_speed(speed_field, flags_2489):
    """A42150's exact float32 formula; flag meaning and units remain unknown."""
    return f32(speed_field * (0.25 if flags_2489 & 2 else 1.0))


def vector(fields, address):
    values = struct.unpack('<4f', fields.exact(address, 16))
    win.require(all(math.isfinite(v) for v in values), 'Actor motion vector is nonfinite')
    return list(values)


def definition(fields, address):
    header = fields.exact(address, 24)
    pointer, length, capacity = struct.unpack_from('<QII', header)
    win.require(length <= 128 and header[17] <= 3, 'Actor definition string exceeds verified bounds')
    if not length:
        return dict(bytes=0, value='', empty=True)
    raw = fields.exact(pointer, length)
    win.require(all(32 <= b < 127 for b in raw), 'Actor definition is not a printable asset name')
    return dict(bytes=length, value=raw.decode('ascii'), empty=False)


def actor_loading_state(read, base, engine, database, player, guid):
    result = dict(available=False, version=VERSION, actor_fully_loaded_verified=False,
                  input_consumed_verified=False, camera_attachment_verified=False,
                  playable_character_verified=False)
    try:
        require_signatures(read, base, ACTOR_SIGNATURES)
        require_signatures(read, base, GETTER_SIGNATURES)
        require_signatures(read, base, SIGNATURES)
        roots = StableFields(read, 1024)
        win.require(roots.u64(engine+0xA2E0) == database
                    and roots.u64(database+0xD68) == player
                    and roots.u64(player+0x18) == guid, 'Local actor player identity differs')
        manager = roots.u64(engine+0xB010)
        actor = roots.u64(manager+0x2450)
        win.require(actor != 0, 'No selected player actor')
        win.require(roots.u64(actor) == base+PRIMARY, 'Selected actor type is outside this diagnostic layout')
        win.require(roots.u64(actor+0x17C0) == base+IDENTITY
                    and roots.u64(actor+0x410) == base+CALLBACKS
                    and roots.u64(base+PRIMARY+0x210) == base+0x13895
                    and roots.u64(base+IDENTITY+0x20) == base+0x7B459
                    and roots.u64(base+CALLBACKS+0x70) == base+0x2FD8D
                    and roots.u64(base+CALLBACKS+0x78) == base+0xC4D25,
                    'Selected actor interfaces differ from the matching build')
        win.require(roots.u64(actor+0x200) == guid and roots.u64(manager+0x2458) == guid,
                    'Selected actor and manager identities do not match the local character')
        for name, observe in (('model', model_state), ('motion', motion_state)):
            try:
                result[name] = observe(read, actor)
            except ValueError as error:
                result[name] = dict(available=False, reason=str(error))
        roots.verify()
        require_player(read, engine, database, player, guid)
        result.update(available=True, identity_stable_reread=True, primary_vtable_rva=hex(PRIMARY),
                      interpretation='Sequential bounded reads of the matched selected actor; each component has its own stability result.')
    except ValueError as error:
        # Discard all component values if their owning identity changed.
        result = dict(available=False, version=VERSION, reason=str(error),
                      actor_fully_loaded_verified=False, playable_character_verified=False)
    return result


def model_state(read, actor):
    fields = StableFields(read, 1024)
    result = dict(model_id=fields.u32(actor+0x17AC), gender_raw=fields.u32(actor+0x2CA0),
                  actor_definition=definition(fields, actor+0x24F8))
    flags = fields.exact(actor+0x30E8, 1)[0]
    result.update(first_person_arms_resource_present=bool(fields.u64(actor+0x30F8)),
                  first_person_arms_flags_raw=flags, first_person_arms_ready_flag=bool(flags & 0x80),
                  first_person_arms_failed_flag=bool(flags & 0x40))
    fields.verify()
    return dict(available=True, stable_reread=True, **result,
                limitation='Arms callback flags are not overall character readiness; nonzero model/name fields alone do not prove rendering.')


def motion_state(read, actor):
    fields = StableFields(read, 1024)
    transform = fields.u64(actor+0x918)
    win.require(transform != 0, 'Actor transform is not initialized')
    flags = {offset: fields.exact(actor+offset, 1)[0]
             for offset in sorted({v[0] for v in FLAG_FIELDS.values()} | {0x2489})}
    speed = struct.unpack('<f', fields.exact(actor+0x1BA0, 4))[0]
    vertical = struct.unpack('<f', fields.exact(actor+0x268C, 4))[0]
    win.require(math.isfinite(speed) and math.isfinite(vertical), 'Actor speed field is nonfinite')
    result = dict(velocity_f32=vector(fields, transform+0x130),
                  ground_position_f32=vector(fields, actor+0x2A30),
                  vertical_velocity_f32=vertical, speed_field_1ba0_f32=speed,
                  expected_speed_f32=expected_speed(speed, flags[0x2489]),
                  diagnostic_flags={name: bool(flags[offset] & mask) for name,(offset,mask) in FLAG_FIELDS.items()},
                  raw_flag_bytes={hex(offset): value for offset,value in flags.items()})
    cache_flags = fields.u32(transform+0x180)
    result['transform_cache_clean'] = not bool(cache_flags & 1)
    if not cache_flags & 1:
        result['position_f32'] = vector(fields, transform+0x1C0)
    fields.verify()
    return dict(available=True, stable_reread=True, **result,
                native_is_moving_evaluated=False, collision_verified=False,
                limitation='Native diagnostic fields, not a simulated movement update. Dirty position caches are omitted; no native updater is called.')

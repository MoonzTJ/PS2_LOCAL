"""Build-locked loading UI: name fallback and one refresh after native zone 2 arrives.

Only the separate local UI archive is changed. No native state is forced.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import struct
import zlib

import ui_diagnostics as ui

ASSET_HASH = 0x565DE7CD24CE87A0  # LoadingScreen.gfx, confirmed by ABC class names.
GFX_SHA256 = "e69612ee896fc020dfec659837718434e996c729729be98b716af3cf32692775"
ABC_SHA256 = "631f0db7723410184f1f274b383d71f2ccd6c4e9d35f0b7b0cacfb8f040a894d"
METHODS = ((929, 117091, 117497, (929, 3, 9, 13, 14),
            "d89320bcbb2d96437a98aa2f31eaf0f0de61594b2bf4774a7d11144fd9ae6031"),
           (934, 117914, 117938, (934, 2, 1, 13, 14),
            "6a6a6ee95be7b7d9b3a00881ddcf82e85c3458c3b096119551b7b8c304550286"))


def fallback_prefix(indar_index):
    a = ui.Assembly()
    a.local(2); a.branch(0x11, "done")  # Keep the existing nonempty localized name.
    a.emit(0x60, 106); a.emit(0x46, 973, 0); a.emit(0x73)
    a.byte(2); a.branch(0x14, "done")
    a.emit(0x2C, indar_index); a.local(2, True)
    a.label("done")
    return a.finish()


def refresh_prefix(uppercase_index):
    a = ui.Assembly()
    a.emit(0x60, 106); a.emit(0x46, 973, 0); a.emit(0x73)
    a.byte(2); a.branch(0x14, "done")
    a.local(0); a.emit(0x66, 785); a.emit(0x2C, uppercase_index)
    a.branch(0x13, "done")  # Already selected/refreshed; don't randomize on every progress update.
    a.local(0); a.emit(0x4F, 796, 0)
    a.label("done")
    return a.finish()


def patch_abc(data):
    ui.require(ui.digest(data) == ABC_SHA256, "Unsupported LoadingScreen ABC")
    start, entries, pool_end, strings = ui.string_pool(data)
    indices = (len(strings), len(strings) + 1)
    additions = b"".join(ui.u30(len(s)) + s for s in (b"Indar", b"INDAR"))
    replacements = [(start, pool_end, ui.u30(len(strings) + 2) + data[entries:pool_end] + additions)]
    details = []
    for mid, begin, end, expected_header, expected_hash in METHODS:
        r = ui.Reader(data[begin:end])
        header = tuple(r.var() for _ in range(5))
        code = r.read(r.var()); tail = r.read(len(r.data) - r.pos)
        ui.require(header == expected_header and ui.digest(code) == expected_hash and tail == b"\0\0",
                   "Unsupported loading-screen method layout")
        if mid == 929:
            ui.require(code[:14].hex() == "d030208005d7606a46ce070082d6", "Loading-screen name prefix differs")
            prefix = fallback_prefix(indices[0]); changed = code[:14] + prefix + code[14:]
        else:
            prefix = refresh_prefix(indices[1]); changed = code[:2] + prefix + code[2:]
        replacement = b"".join(ui.u30(v) for v in header) + ui.u30(len(changed)) + changed + tail
        replacements.append((begin, end, replacement))
        details.append(dict(method=mid, old_code_bytes=len(code), new_code_bytes=len(changed),
                            insertion_offset=14 if mid == 929 else 2, inserted_code_hex=prefix.hex()))
    changed = data
    for begin, end, replacement in sorted(replacements, reverse=True):
        changed = changed[:begin] + replacement + changed[end:]
    return changed, dict(loading_changed_methods=details, loading_original_abc_sha256=ABC_SHA256,
                         loading_patched_abc_sha256=ui.digest(changed),
                         loading_title_fallback="Indar", loading_title_requires_native_zone_id=2,
                         native_map_completion="unverified")


def patch_gfx(data):
    ui.require(ui.digest(data) == GFX_SHA256, "Unsupported LoadingScreen.gfx")
    declared, payload, (start, end, prefix, abc) = ui.gfx_abc(data)
    changed, details = patch_abc(abc)
    tag = prefix + changed
    replacement = struct.pack("<HI", (82 << 6) | 63, len(tag)) + tag
    delta = len(replacement) - (end - start)
    new_payload = payload[:start] + replacement + payload[end:]
    result = data[:4] + struct.pack("<I", declared + delta) + zlib.compress(new_payload, 9)
    ui.require(new_payload[declared + delta - 8:] == payload[declared - 8:], "Loading GFX trailer changed")
    ui.require(ui.gfx_abc(result)[2][3] == changed, "Loading GFX readback differs")
    details.update(loading_original_gfx_sha256=GFX_SHA256,
                   loading_patched_gfx_sha256=ui.digest(result))
    return result, details


def inspect_archive(path):
    path = Path(path); size = path.stat().st_size
    with path.open("rb") as stream:
        header = stream.read(160)
        ui.require(len(header) == 160 and header[:4] == b"PAK\x01", "Unsupported UI pack")
        count = struct.unpack_from("<I", header, 4)[0]
        length, index = struct.unpack_from("<QQ", header, 8)
        ui.require(length == size and 0 < count <= 100000 and index + count * 32 == size,
                   "Invalid UI pack index")
        stream.seek(index); table = stream.read(count * 32); matches = []
        for i in range(count):
            key, offset, stored, flags, checksum = struct.unpack_from("<QQQII", table, i * 32)
            ui.require(256 <= offset <= index and stored <= index - offset, "Invalid UI asset bounds")
            if key == ASSET_HASH: matches.append((i, offset, stored, flags, checksum))
        ui.require(len(matches) == 1, "LoadingScreen asset is missing or duplicated")
        row, offset, stored, flags, checksum = matches[0]
        ui.require(flags == 16 and stored < 1024 * 1024, "Unsupported loading asset record")
        stream.seek(offset); gfx = stream.read(stored)
        ui.require(ui.crc32c(gfx, ui.crc32c(struct.pack("<Q", ASSET_HASH))) == checksum,
                   "Loading asset checksum mismatch")
    return dict(header=header, table=table, row=row, gfx=gfx)


def patch_independent_archive(path):
    path = Path(path)
    ui.require(not ui.linked(path) and path.stat().st_nlink == 1, "Loading UI output must be an independent file")
    original = inspect_archive(path); gfx, details = patch_gfx(original["gfx"])
    table = bytearray(original["table"])
    offset = (path.stat().st_size + 255) & ~255
    index = (offset + len(gfx) + 255) & ~255
    checksum = ui.crc32c(gfx, ui.crc32c(struct.pack("<Q", ASSET_HASH)))
    struct.pack_into("<QQQII", table, original["row"] * 32, ASSET_HASH, offset, len(gfx), 16, checksum)
    header = bytearray(original["header"]); struct.pack_into("<QQ", header, 8, index + len(table), index)
    with path.open("r+b") as output:
        output.seek(offset); output.write(gfx); output.seek(index); output.write(table)
        output.seek(0); output.write(header); output.truncate(index + len(table))
    checked = inspect_archive(path)
    ui.require(checked["gfx"] == gfx, "Loading asset readback differs")
    old, new = bytearray(original["table"]), bytearray(checked["table"])
    for value in (old, new): value[original["row"] * 32:(original["row"] + 1) * 32] = bytes(32)
    ui.require(old == new, "Unrelated UI asset records changed")
    details["loading_asset_row"] = original["row"]
    return details

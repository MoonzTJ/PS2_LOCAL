"""Read-only Windows helpers reused by the bounded V25 native row inspector.

No game launch, process write, injection, suspension, debugger attachment,
heap dump, or BattlEye operation. Python 3.10+, 64-bit, standard library.
"""
from __future__ import annotations
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import tempfile
import zipfile

from console_common import CONFIG_NAME as CONFIG

EXPECTED_SHA256 = "e32f897cd52e5f24e8000901ab8a18814c691eb8aeb21049b943fb1320bfe957"
DEFAULT_GAME = r"C:\Users\Public\Daybreak Game Company\Installed Games\PlanetSide 2 Local"
MAX_IMAGE = 128 * 1024 * 1024
MAX_SELECTED = 96 * 1024 * 1024
PAGE = 4096
CHUNK = 1024 * 1024
SELECTED = {".text", ".rdata", "_RDATA"}

def require(condition, message):
    if not condition: raise ValueError(message)

def sha(data): return hashlib.sha256(data).hexdigest()

def file_sha(path):
    h=hashlib.sha256()
    with path.open("rb") as stream:
        for b in iter(lambda:stream.read(CHUNK),b""):h.update(b)
    return h.hexdigest()

def pe_layout(data):
    require(len(data)>=64 and data[:2]==b"MZ","Main module has no PE header")
    nt=struct.unpack_from("<I",data,0x3c)[0]
    require(64<=nt<=8192 and nt+24<=len(data) and data[nt:nt+4]==b"PE\0\0","Invalid PE signature")
    machine,count,stamp,_,_,opt_size,_=struct.unpack_from("<HHIIIHH",data,nt+4)
    opt=nt+24
    require(machine==0x8664 and 1<=count<=32 and 112<=opt_size<=1024,"Expected bounded 64-bit PE")
    end=opt+opt_size+count*40
    require(end<=len(data) and struct.unpack_from("<H",data,opt)[0]==0x20b,"Truncated/unsupported PE")
    image_size,header_size=struct.unpack_from("<II",data,opt+56)
    require(end<=header_size<=65536 and header_size<=image_size<=MAX_IMAGE,"Invalid image bounds")
    sections=[]
    for index in range(count):
        p=opt+opt_size+index*40
        name=data[p:p+8].split(b"\0")[0].decode("ascii")
        virtual_size,rva,raw_size,raw_offset=struct.unpack_from("<IIII",data,p+8)
        flags=struct.unpack_from("<I",data,p+36)[0]
        length=virtual_size or raw_size
        require(header_size<=rva<=image_size and length<=image_size-rva,"Section exceeds image")
        sections.append(dict(index=index,name=name,rva=rva,size=length,raw_size=raw_size,raw_offset=raw_offset,flags=flags))
    intervals=sorted((s["rva"],s["rva"]+s["size"]) for s in sections)
    require(all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:])),"Overlapping mapped sections")
    chosen=[s for s in sections if s["name"] in SELECTED]
    require(chosen and sum(s["size"] for s in chosen)<=MAX_SELECTED,"Unexpected selected section size")
    return dict(timestamp=stamp,image_size=image_size,header_size=header_size,sections=sections,selected=chosen)

def check_local_config(data):
    require(len(data)<=128*1024,"Local config is too large")
    servers=[]
    for line in data.removeprefix(b"\xef\xbb\xbf").splitlines():
        if line.lstrip().startswith(b"["):break
        if re.match(rb"(?i)^\s*Server\s*=",line):servers.append(line.split(b"=",1)[1].strip())
    require(len(servers)==1 and re.fullmatch(rb"127\.0\.0\.1:[0-9]{1,5}",servers[0]) is not None,
            "V25 configuration must have exactly one loopback login server")
    port=int(servers[0].rsplit(b":",1)[1]);require(1<=port<=65535,"Invalid loopback port")
    return port

def check_arguments(args):
    # Check values internally; never record the full command line.
    expected=[f"inifile={CONFIG}","sessionid=0","Internationalization:Locale=en_US"]
    require(len(args)==4 and sorted(x.casefold() for x in args[1:])==sorted(x.casefold() for x in expected),
            "Target must be launched by this local CMD with dummy sessionid=0")

class WindowsReader:
    def __init__(self,pid,expected_exe):
        from ctypes import wintypes as w
        require(os.name=="nt" and ctypes.sizeof(ctypes.c_void_p)==8,"Use 64-bit Python on Windows 11")
        self.k=ctypes.WinDLL("kernel32",use_last_error=True);self.p=ctypes.WinDLL("psapi",use_last_error=True)
        self.k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];self.k.OpenProcess.restype=w.HANDLE
        self.k.CloseHandle.argtypes=[w.HANDLE];self.k.CloseHandle.restype=w.BOOL
        self.k.ReadProcessMemory.argtypes=[w.HANDLE,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
        self.k.ReadProcessMemory.restype=w.BOOL
        self.k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
        self.k.QueryFullProcessImageNameW.restype=w.BOOL
        self.p.EnumProcessModulesEx.argtypes=[w.HANDLE,ctypes.POINTER(w.HMODULE),w.DWORD,ctypes.POINTER(w.DWORD),w.DWORD]
        self.p.EnumProcessModulesEx.restype=w.BOOL
        self.p.GetModuleFileNameExW.argtypes=[w.HANDLE,w.HMODULE,w.LPWSTR,w.DWORD];self.p.GetModuleFileNameExW.restype=w.DWORD
        self.handle=self.k.OpenProcess(0x0400|0x0010,False,pid) # QUERY_INFORMATION + VM_READ only
        if not self.handle:raise OSError(ctypes.get_last_error(),"Cannot open the selected local client for reading")
        try:
            path=ctypes.create_unicode_buffer(32768);length=w.DWORD(len(path))
            if not self.k.QueryFullProcessImageNameW(self.handle,0,path,ctypes.byref(length)):
                raise OSError(ctypes.get_last_error(),"Cannot identify the selected executable")
            require(Path(path.value).samefile(expected_exe),"PID is not the executable in the copied game folder")
            modules=(w.HMODULE*4096)();needed=w.DWORD()
            if not self.p.EnumProcessModulesEx(self.handle,modules,ctypes.sizeof(modules),ctypes.byref(needed),2):
                raise OSError(ctypes.get_last_error(),"Cannot enumerate the local client's modules")
            require(needed.value<=ctypes.sizeof(modules),"Module list exceeds diagnostic limit")
            self.base=None
            for module in modules[:needed.value//ctypes.sizeof(w.HMODULE)]:
                if self.p.GetModuleFileNameExW(self.handle,module,path,len(path)) and Path(path.value).samefile(expected_exe):
                    self.base=int(module);break
            require(self.base is not None,"Main client module was not found")
        except BaseException:
            self.close();raise
    def read(self,address,size):
        buffer=ctypes.create_string_buffer(size);done=ctypes.c_size_t()
        ok=self.k.ReadProcessMemory(self.handle,ctypes.c_void_p(address),buffer,size,ctypes.byref(done))
        return buffer.raw if ok and done.value==size else None
    def close(self):
        if self.handle:self.k.CloseHandle(self.handle);self.handle=None

def process_arguments(pid):
    from ctypes import wintypes as w
    powershell=Path(os.environ.get("SystemRoot",r"C:\Windows"))/"System32/WindowsPowerShell/v1.0/powershell.exe"
    require(powershell.is_file(),"Windows PowerShell is needed to verify the V25 dummy launch")
    command=f"$ErrorActionPreference='Stop'; $p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; if (!$p) {{ exit 3 }}; $p.CommandLine | ConvertTo-Json -Compress"
    result=subprocess.run([str(powershell),"-NoProfile","-NonInteractive","-Command",command],capture_output=True,text=True,timeout=20)
    require(result.returncode==0,"Cannot verify the target's dummy-login command line")
    try:line=json.loads(result.stdout.lstrip("\ufeff"))
    except (ValueError,TypeError):raise ValueError("Command-line query returned an unrecognized result") from None
    require(isinstance(line,str) and 0<len(line)<=32768,"Command line is missing or too large")
    shell=ctypes.WinDLL("shell32",use_last_error=True);kernel=ctypes.WinDLL("kernel32",use_last_error=True)
    shell.CommandLineToArgvW.argtypes=[w.LPCWSTR,ctypes.POINTER(ctypes.c_int)];shell.CommandLineToArgvW.restype=ctypes.POINTER(w.LPWSTR)
    kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    count=ctypes.c_int();pointer=shell.CommandLineToArgvW(line,ctypes.byref(count))
    require(bool(pointer),"Cannot parse the verified process command line")
    try:return [pointer[i] for i in range(count.value)]
    finally:kernel.LocalFree(ctypes.cast(pointer,ctypes.c_void_p))

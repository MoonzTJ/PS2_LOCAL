"""Build-locked, opt-in actor placement experiment; no eligible-spawn rules."""
import hashlib
import struct

from zone_scene import SOURCE_SHA256

VERSION = 'native-update-location-asset-anchor-v1'
LOCAL_VS_GUID = 0x1000000000000001
GROUP = 27
INSTANCE = 84
POSITION = (2946.908203125, 65.78419494628906, 126.0810546875, 1.0)
# Explicit horizontal experiment direction, not the asset's unverified rotation.
DIRECTION = (0.0, 0.0, 1.0, 0.0)


def location_packet():
    # 98E610/9B9F20: opcode:u8, subopcode:u16, two vec4, bool, raw byte.
    # A4C615 applies actor virtual+820 when bool is true, then camera callback.
    return b'\x11\x0c\x00' + struct.pack('<8fBB', *POSITION, *DIRECTION, 1, 0)


def require_anchor(scene):
    if scene is None:
        raise ValueError('Location probe requires the matching Indar asset records')
    row = scene.object(GROUP, INSTANCE)
    if (row['asset_name'] != 'Common_Props_SpawnTube.adr'
            or tuple(row['inferred_position']) != POSITION):
        raise ValueError('Location probe asset anchor differs')


def description():
    packet = location_packet()
    return dict(version=VERSION, experimental=True, packet_bytes=len(packet),
        packet_sha256=hashlib.sha256(packet).hexdigest(), zone_id=2,
        character_guid=LOCAL_VS_GUID, source_zone_sha256=SOURCE_SHA256,
        asset_group=GROUP, asset_instance=INSTANCE, position=list(POSITION),
        direction=list(DIRECTION), teleport=True, unknown_byte=0,
        eligible_spawn_verified=False, safe_floor_verified=False,
        territory_assignment_implemented=False, character_equipment_changed=False)

"""Local service console. No shell evaluation or native client control hooks."""
import os
import re
import shutil
import sys
from presets import PRESETS

# Confirmed in uploaded CharacterCreate.gfx bytecode: EmpireIds.EMPIRE_VS/NC/TR/NS.
# These values are not recovered native command arguments.
FACTIONS = {1: "VS", 2: "NC", 3: "TR", 4: "NSO"}
MAX_COMMAND = 200


class LineBuffer:
    def __init__(self):
        self.line = ""
        self.overflow = False

    def feed(self, character):
        if character in ("\r", "\n"):
            result = None if self.overflow else self.line
            self.line = ""
            self.overflow = False
            return True, result
        if character in ("\b", "\x7f"):
            self.line = self.line[:-1]
        elif character.isascii() and character.isprintable():
            if len(self.line) < MAX_COMMAND and not self.overflow:
                self.line += character
            else:
                self.overflow = True
        return False, None


class PromptOutput:
    """Redraw a bounded command line after complete log lines arrive."""
    def __init__(self, stream, line, columns=None):
        self.stream, self.line = stream, line
        self.columns = columns or (lambda: shutil.get_terminal_size((80, 24)).columns)
        self.pending = ''

    def __getattr__(self, name):
        return getattr(self.stream, name)

    def width(self):
        return max(20, min(512, self.columns()))-1

    def clear(self):
        self.stream.write('\r'+' '*self.width()+'\r')

    def redraw(self):
        text = 'MoonSol> '+self.line()
        width = self.width()
        if len(text) > width:
            text = 'MoonSol> ...'+text[-(width-12):]
        self.clear()
        self.stream.write(text)
        self.stream.flush()

    def write(self, text):
        self.pending += text
        if '\n' in self.pending:
            complete, self.pending = self.pending.rsplit('\n', 1)
            self.clear()
            self.stream.write(complete+'\n')
            self.redraw()
        return len(text)

    def flush(self):
        self.stream.flush()

    def submitted(self):
        self.stream.write('\n')
        self.redraw()

    def finish(self):
        self.clear()
        if self.pending:
            self.stream.write(self.pending+'\n')
            self.pending = ''
        self.stream.flush()


class ConsoleInput:
    """Read available input without blocking UDP/ACK/retry processing."""
    def __init__(self):
        self.buffer = LineBuffer()
        self.closed = False
        self.extended_key = False
        self.output = None
        if os.name == 'nt' and sys.stdout.isatty():
            self.output = PromptOutput(sys.stdout, lambda: self.buffer.line)
            sys.stdout = self.output
            self.output.redraw()

    def close(self):
        self.closed = True
        if self.output is not None:
            self.output.finish()
            if sys.stdout is self.output:
                sys.stdout = self.output.stream
            self.output = None

    def poll(self):
        if self.closed:
            return []
        if os.name == "nt":
            import msvcrt
            lines = []
            for _ in range(64):
                if not msvcrt.kbhit():
                    break
                character = msvcrt.getwch()
                if self.extended_key:
                    self.extended_key = False
                    continue
                if character in ("\0", "\xe0"):
                    self.extended_key = True
                    continue
                if character == "\x03":
                    raise KeyboardInterrupt
                if character == "\x1a":
                    self.closed = True
                    break
                complete, line = self.buffer.feed(character)
                if complete:
                    if self.output is not None:
                        self.output.submitted()
                    else:
                        print()
                    lines.append(line)
                elif self.output is not None:
                    self.output.redraw()
                elif character in ("\b", "\x7f"):
                    print("\b \b", end="", flush=True)
                elif character.isascii() and character.isprintable() and not self.buffer.overflow:
                    print(character, end="", flush=True)
            return lines
        # POSIX support is for synthetic/serve-only tests, not native game launch.
        import select
        if not select.select([sys.stdin], [], [], 0)[0]:
            return []
        data = os.read(sys.stdin.fileno(), 64)
        if not data:
            self.closed = True
            return []
        lines = []
        for character in data.decode("ascii", errors="replace"):
            complete, line = self.buffer.feed(character)
            if complete:
                lines.append(line)
        return lines


class Console:
    def __init__(self, probe):
        self.probe = probe

    def execute(self, line):
        # Never emit raw command text: mistyped credentials stay out of the JSONL.
        command = "invalid"
        result = dict(ok=False, applied_to_client=False)
        if line is None or len(line) > MAX_COMMAND:
            result.update(code="input_too_long", message="Command exceeds 200 characters; discarded.")
        elif not line.strip():
            return dict(ok=True, code="empty", applied_to_client=False)
        else:
            words = line.strip().split()
            verb = words[0].lower()
            if verb in ("help", "status", "log", "faction", "factions", "map", "lists", "quit"):
                command = verb
            if words == ["help"]:
                result.update(ok=True, code="help", message=(
                    "help | status | log | factions | faction <1..4> | map load <name-or-id> [preset-name] | lists send | quit. "
                    "Faction/map commands report missing integration; lists send refreshes historical list candidates."))
            elif words == ["status"]:
                result.update(ok=True, code="status", **self.probe.console_status())
            elif words == ["log"]:
                result.update(ok=True, code="log", path=str(self.probe.log_path))
            elif words == ["factions"]:
                result.update(ok=True, code="faction_mapping", mapping=FACTIONS,
                              mapping_source="uploaded UI EmpireIds constants; EMPIRE_NS displayed here as NSO")
            elif verb == "faction" and len(words) == 2 and words[1] in ("1", "2", "3", "4"):
                identifier = int(words[1])
                result.update(code="unsupported", faction_id=identifier, faction_name=FACTIONS[identifier],
                              message="Not applied: native faction-selection integration is unavailable; the menu remains unchanged.")
            elif verb == "map" and len(words) in (3,4) and words[1].lower() == "load" and re.fullmatch(r"[A-Za-z0-9_-]{1,64}", words[2]):
                # Resolve shipped alias metadata; never fabricate a zone handoff.
                if words[2].lower() in ("indar","2"):
                    preset_name=words[3] if len(words)==4 else "LocalVS"
                    preset=next((row for row in getattr(self.probe, 'characters', PRESETS) if row["name"].lower()==preset_name.lower()),None)
                    if preset is None:
                        result.update(code="usage",message="Choose LocalVS, LocalNC, LocalTR, or LocalNSO.")
                    else:
                        result.update(code="unsupported",requested_map="Indar",zone_id=2,terrain_id=86,
                                      requested_character=dict(preset),
                                      zone_id_source="shipped AdminCommandAliases.xml: zone.indar -> zone 2",
                                      character_scope="local service preset; use Play to select the native character",
                                      message="Play sends the Indar zone-details candidate after gateway login. The full player-world record and playable zone service are still missing; this command does not load a map.")
                elif len(words)==3:
                    result.update(code="unsupported",requested_map=words[2],
                                  message="Not loaded: no zone service, character-to-zone handoff, or verified current-client map-load schema is implemented.")
                else:
                    result.update(code="usage",message="Named character requests currently resolve Indar only.")
            elif words == ["lists", "send"]:
                try:
                    counts = self.probe.refresh_lists()
                except (ValueError, OSError):
                    result.update(code="not_ready", message=(
                        "No lists sent. Requires exactly one accepted dummy login with no pending reliable packets, "
                        "and at least five seconds since the previous manual refresh."))
                else:
                    result.update(ok=True, code="lists_sent", **counts,
                                  message="Candidate lists sent; ACKs establish transport delivery only.")
            elif words == ["quit"]:
                result.update(ok=True, code="stopping", stop=True,
                              message="Stopping the local test service. Close the game yourself.")
            elif command == "invalid":
                result.update(code="unknown_command", message="Unknown command. Type help.")
            else:
                result.update(code="usage", message="Invalid arguments. Type help for command syntax.")
        self.probe.event("console_result", command=command, **result)
        return result

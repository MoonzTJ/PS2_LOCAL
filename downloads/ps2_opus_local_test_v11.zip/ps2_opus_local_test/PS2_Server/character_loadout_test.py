"""Shared, exact fingerprint for the isolated received-loadout client test."""
import hashlib
import starter_loadout
from starter_character import seed_states,test_description
from player_world import send_self_to_client
from presets import VS_TEST_PRESET,character_presets
from character_observer import VERSION as OBSERVER_VERSION


def description():
    states=seed_states();row=VS_TEST_PRESET
    packet=send_self_to_client(dict(character_guid=row['character_id'],character_name=row['name'],server_id=101),
                              characters=character_presets(True),starter_state=states[1])
    loadout=starter_loadout.description(states[1])
    loadout.update(send_self_bytes=len(packet),send_self_sha256=hashlib.sha256(packet).hexdigest())
    identity=test_description(states);identity['send_self_sha256']=loadout['send_self_sha256']
    return dict(version='character-loadout-client-test-v1',observer_version=OBSERVER_VERSION,
                starter_loadout=loadout,vs_test_character=identity)

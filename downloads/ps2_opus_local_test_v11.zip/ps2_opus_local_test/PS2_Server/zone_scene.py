"""Build-locked Indar ZONE v2 actor records; no terrain or game simulation.

Layout is measured against Moon's uploaded file. Vector meanings are inferred;
the 10-byte per-placement trailer and other sections remain uninterpreted.
"""
from dataclasses import dataclass
import hashlib
import math
import re
import struct

SOURCE_SHA256 = 'ce2b3b0e7b6ae3ecfdb0c8d5336966adc31067b1509764c452d8344f351caee2'
RECORD_BYTES = 58


@dataclass(frozen=True)
class ActorGroup:
    index: int
    asset_name: str
    metadata_float: float
    count: int
    records_offset: int


class IndarScene:
    def __init__(self, raw):
        if hashlib.sha256(raw).hexdigest() != SOURCE_SHA256:
            raise ValueError('Unsupported Indar.zone build; keep the matching extracted definition')
        if len(raw) < 68 or raw[:4] != b'ZONE' or struct.unpack_from('<I', raw, 4)[0] != 2:
            raise ValueError('Unsupported Indar ZONE header')
        offsets = struct.unpack_from('<6I', raw, 8)
        if offsets != (68, 7099, 9697, 9701, 3946861, 4629849):
            raise ValueError('Unsupported Indar section layout')
        if not all(a <= b for a, b in zip(offsets, offsets[1:])) or offsets[-1] + 4 != len(raw):
            raise ValueError('Indar section bounds differ')
        self.raw = raw
        start, end = offsets[3], offsets[4]
        count = struct.unpack_from('<I', raw, start)[0]
        if count != 631:
            raise ValueError('Indar actor group count differs')
        position = start + 4
        groups, total = [], 0
        bounds = [[math.inf, -math.inf] for _ in range(3)]
        for index in range(count):
            terminator = raw.find(b'\0', position, min(position + 1024, end))
            if terminator < 0:
                raise ValueError('Indar actor name is unterminated')
            name = raw[position:terminator].decode('ascii')
            if not re.fullmatch(r'[A-Za-z0-9_.-]+\.adr', name):
                raise ValueError('Indar actor reference layout differs')
            position = terminator + 1
            if position + 8 > end:
                raise ValueError('Truncated Indar actor metadata')
            metadata, instances = struct.unpack_from('<fI', raw, position)
            position += 8
            if not math.isfinite(metadata) or instances > 100000 or position + instances * RECORD_BYTES > end:
                raise ValueError('Invalid Indar actor count or metadata')
            groups.append(ActorGroup(index, name, metadata, instances, position))
            for offset in range(position, position + instances * RECORD_BYTES, RECORD_BYTES):
                values = struct.unpack_from('<12f', raw, offset)
                if not all(math.isfinite(v) and abs(v) < 1000000 for v in values):
                    raise ValueError('Invalid Indar placement vector')
                for axis in range(3):
                    bounds[axis][0] = min(bounds[axis][0], values[axis])
                    bounds[axis][1] = max(bounds[axis][1], values[axis])
            position += instances * RECORD_BYTES
            total += instances
        if position != end or total != 67308:
            raise ValueError('Indar actor records do not consume the exact section')
        self.groups, self.placement_count = tuple(groups), total
        self.position_bounds = tuple(tuple(row) for row in bounds)
        self.declared_other_section_counts = tuple(struct.unpack_from('<I', raw, offset)[0]
                                                   for offset in (offsets[0], offsets[1], offsets[2], offsets[4], offsets[5]))

    def status(self):
        return dict(zone_definition_parsed=True, format_version=2, source_sha256=SOURCE_SHA256,
                    actor_group_count=len(self.groups), placement_record_count=self.placement_count,
                    actor_section_consumed_exactly=True, all_placement_vectors_finite=True,
                    inferred_position_bounds=[list(row) for row in self.position_bounds],
                    vector_meanings='inferred_from_measured_record_layout',
                    other_sections_interpreted=False, actor_asset_geometry_loaded=False,
                    terrain_geometry_loaded=False, collision_simulation_implemented=False,
                    spawn_locations_verified=False, playable_world_implemented=False)

    def object(self, group_index, instance_index):
        if not 0 <= group_index < len(self.groups):
            raise ValueError('Use an actor group index from 0 through 630')
        group = self.groups[group_index]
        if not 0 <= instance_index < group.count:
            raise ValueError(f'Use an instance index from 0 through {group.count - 1}')
        offset = group.records_offset + instance_index * RECORD_BYTES
        values = struct.unpack_from('<12f', self.raw, offset)
        return dict(group_index=group_index, instance_index=instance_index,
                    asset_name=group.asset_name, inferred_position=list(values[:4]),
                    inferred_rotation=list(values[4:8]), inferred_scale=list(values[8:12]),
                    uninterpreted_trailer_hex=self.raw[offset+48:offset+58].hex(),
                    asset_geometry_loaded=False, gameplay_entity_created=False, verified_spawn=False)

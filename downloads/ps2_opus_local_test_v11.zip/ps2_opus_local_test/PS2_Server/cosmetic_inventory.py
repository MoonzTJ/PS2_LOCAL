"""Opt-in VS starter armor/helmet ownership probe, using current catalog joins.

The native non-weapon instance route accepts type39. These are owned cosmetic
instances and slot links; complete character rendering/control is unverified.
"""
import hashlib
import json
from pathlib import Path
import struct
from functools import lru_cache

from presets import VS_TEST_PRESET
from starter_character import canonical, initialize_vs_starter
from profile_catalog import ProfileCatalog

VERSION = 'vs-cosmetic-equipment-probe-v1'
ITEMS = ((10, 6002573, 0x200000000001010A), (11, 108, 0x200000000001010B))
MODELS = {6002573: 'Armor_VS_<gender>_LightAssault_Look001.adr',
          108: 'Helmet_VS_<gender>_LightAssault_Look001.adr'}
ROW_KEY = 0


@lru_cache(maxsize=1)
def _state_bytes():
    seed = initialize_vs_starter(VS_TEST_PRESET)
    by_slot = {row['slot_id']: row for row in seed['equipped_slots']}
    catalog = ProfileCatalog()
    for slot, item, _ in ITEMS:
        metadata = catalog.item_definitions[item]
        if (by_slot[slot]['item_definition_id'] != item or metadata['CODE_FACTORY_NAME'] != 'InfantryCosmetic'
                or int(metadata['ITEM_TYPE']) != 39 or metadata['MODEL_NAME'] != MODELS[item]):
            raise ValueError('Cosmetic subset differs from the pinned VS starter catalog')
    return canonical(dict(version=VERSION, character_guid=VS_TEST_PRESET['character_id'], equipment_row_key=ROW_KEY,
        items=[dict(slot_id=slot, item_definition_id=item, native_instance_guid=guid,
                    backend_item_key=by_slot[slot]['backend_item_key'], model_template=MODELS[item])
               for slot, item, guid in ITEMS],
        equipment_row_semantics_verified=False, quantity_verified=False, appearance_verified=False,
        playable_character_verified=False))


def state():
    return json.loads(_state_bytes())


def persist(directory):
    directory = Path(directory)
    if directory.is_symlink():
        raise ValueError('Use a regular character-state directory')
    directory.mkdir(parents=True, exist_ok=True)
    path = directory/'1000000000000101.cosmetic-probe.json'
    expected = state()
    if path.exists() or path.is_symlink():
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536 or json.loads(path.read_text()) != expected:
            raise ValueError('Existing cosmetic probe state differs; it has been preserved')
    else:
        with path.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(expected, indent=2)+'\n')


def item_wire(item, guid):
    if (item, guid) not in {(item, guid) for _, item, guid in ITEMS}:
        raise ValueError('Unsupported cosmetic probe instance')
    # Same native generic constructor defaults as the proven type36 route.
    # Type39 is verified independently through the real factory/decoder.
    return struct.pack('<IIQ5IBIBQBB', item, 0, guid, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)


def add_packet():
    body = struct.pack('<I', len(ITEMS))+b''.join(item_wire(item, guid) for _, item, guid in ITEMS)
    return b'\x11\x05\0'+struct.pack('<I', len(body))+body


def equipment_section():
    return struct.pack('<II4I', 1, ROW_KEY, 0, 0, 0, len(ITEMS))+b''.join(
        struct.pack('<IIQII', slot, 0, guid, 0, 0) for slot, _, guid in ITEMS)


def description():
    packet, equipment = add_packet(), equipment_section()
    return dict(version=VERSION, enabled=True, target_character_guid=VS_TEST_PRESET['character_id'],
        state_sha256=hashlib.sha256(canonical(state())).hexdigest(), item_count=2, items=state()['items'],
        equipment_row_key=ROW_KEY, equipment_section_sha256=hashlib.sha256(equipment).hexdigest(),
        add_packet_bytes=len(packet), add_packet_sha256=hashlib.sha256(packet).hexdigest(), delayed_delivery=True,
        cosmetic_items=True, expected_metadata_type=39, equipment_row_semantics_verified=False,
        complete_inventory_implemented=False, appearance_verified=False, playable_character_verified=False)

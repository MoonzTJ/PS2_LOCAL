"""Verified local account permission, distinct from an admin client build."""
VERSION='local-admin-account-v1'
PLAYER_PERMISSION_OFFSET=0x7F973
WIRE_TAIL_BYTES=10


def description(characters):
    return dict(version=VERSION,enabled=True,
        characters=[dict(character_guid=r['character_id'],name=r['name']) for r in characters],
        is_admin_account_sent_at_login=True,admin_client_build_granted=False,
        all_server_gameplay_commands_implemented=False,
        current_native_decoder_and_permission_consumers_verified=True,
        actual_windows_admin_access_verified=False)

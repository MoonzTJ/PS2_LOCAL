"""Matching-build starter equipment; client inventory/wire profiles remain separate."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from profile_identity import profile_identities, REFERENCE_SHA256, REFERENCE_SOURCE

ROOT = Path(__file__).resolve().parent / 'server_data' / 'profiles'
MANIFEST_SHA256 = 'dd41367d001c6209d4ba3aac8d953d40ce353ca60b83aa5db757ba8e8dbd2d59'
LOCAL_VS_PROFILE_ID = 19
LOCAL_VS_LOADOUT_ID = 17


class ProfileCatalog:
    def __init__(self, root=ROOT):
        root = Path(root)
        manifest_bytes = (root/'manifest.json').read_bytes()
        if hashlib.sha256(manifest_bytes).hexdigest() != MANIFEST_SHA256:
            raise ValueError('Unsupported server profile catalog manifest')
        self.manifest = json.loads(manifest_bytes)
        self.tables = {}
        for name, entry in self.manifest['resources'].items():
            raw = (root/name).read_bytes()
            if len(raw) != entry['bytes'] or hashlib.sha256(raw).hexdigest() != entry['sha256']:
                raise ValueError('Server profile resource differs from the bundled source: '+name)
            lines = raw.decode('utf-8').splitlines()
            columns = lines[0].removeprefix('#').removesuffix('^').split('^')
            columns = [column.lstrip('*') for column in columns]
            rows = []
            for line in lines[1:]:
                if not line.strip():
                    continue
                values = line.removesuffix('^').split('^')
                if len(values) != len(columns):
                    raise ValueError('Unsupported server profile row')
                rows.append(dict(zip(columns, values)))
            self.tables[name] = rows
        self.mappings = [dict(loadout_id=int(row['LOADOUT_ID']),
                              profile_id=int(row['PROFILE_ID']),
                              faction_id=int(row['FACTION_ID']),
                              display_index=int(row['DISPLAY_INDEX']))
                         for row in self.tables['Loadouts.txt']]
        if len(self.mappings) != 24 or len({row['loadout_id'] for row in self.mappings}) != 24:
            raise ValueError('Unsupported server loadout mappings')
        self.identities = profile_identities(self.tables, self.mappings)
        self.line_members = defaultdict(list)
        for row in self.tables['ItemLineMembers.txt']:
            self.line_members[int(row['ITEM_LINE_ID'])].append(row)
        self.item_definitions = {int(row['ID']): row for row in self.tables['ClientItemDefinitions.txt']}
        self.item_profiles = defaultdict(list)
        for row in self.tables['ItemProfiles.txt']:
            self.item_profiles[int(row['ITEM_ID'])].append(row)
        starter = self.loadout(LOCAL_VS_LOADOUT_ID)
        if (starter['profile_id'] != LOCAL_VS_PROFILE_ID or starter['faction_id'] != 1
                or not starter['equipment_resolved'] or len(starter['resolved_items']) != 14):
            raise ValueError('Bundled LocalVS starter equipment is incomplete')
        by_slot = {row['slot_id']: row for row in starter['resolved_items']}
        if (by_slot[1]['item_id'] != 44 or by_slot[10]['item_id'] != 6002573
                or by_slot[11]['item_id'] != 108
                or by_slot[10]['model_name'] != 'Armor_VS_<gender>_LightAssault_Look001.adr'
                or by_slot[11]['model_name'] != 'Helmet_VS_<gender>_LightAssault_Look001.adr'):
            raise ValueError('Bundled LocalVS starter differs from the verified Light Assault joins')

    def status(self):
        starter = self.starter()
        return dict(loaded=True, source='server_data/profiles', mapping_count=len(self.mappings),
                    mappings=self.mappings, class_names_verified=False,
                    profile_identity_reference=dict(matched_to_client_tables=True,
                        count=len(self.identities), source=REFERENCE_SOURCE,
                        sha256=REFERENCE_SHA256, source_build_version_available=False,
                        complete_native_class_definitions=False),
                    full_profile_definitions_implemented=False, inventory_implemented=False,
                    active_packet_profile_unchanged=True,
                    item_definition_count=len(self.item_definitions),
                    local_vs_starter=dict(profile_id=LOCAL_VS_PROFILE_ID,
                                          loadout_id=LOCAL_VS_LOADOUT_ID, faction_id=1,
                                          class_name=starter['class_name'],
                                          class_name_source=starter['class_name_source'],
                                          profile_name_id=starter['profile_name_id'],
                                          reference_profile_type_id=starter['reference_profile_type_id'],
                                          equipment_resolved=starter['equipment_resolved'],
                                          resolved_item_count=len(starter['resolved_items']),
                                          applied_to_client=False),
                    next_capture='Class definition hash map and item preload queue; native profile/inventory packets are still incomplete')

    def loadout(self, identifier):
        mapping = next((row for row in self.mappings if row['loadout_id'] == identifier), None)
        if mapping is None:
            raise ValueError('Unknown server loadout ID')
        instances = [row for row in self.tables['LoadoutInstances.txt']
                     if int(row['LOADOUT_ID']) == identifier]
        slots = [row for row in self.tables['LoadoutSlotInstances.txt']
                 if int(row['LOADOUT_ID']) == identifier and int(row['TAB_ID']) == 0]
        resolved, empty, unresolved = [], [], []
        for slot in slots:
            slot_id, line_id = int(slot['SLOT_ID']), int(slot['ITEM_LINE_ID'])
            if not line_id:
                empty.append(slot_id)
                continue
            members = [row for row in self.line_members.get(line_id, ())
                       if int(row['ITEM_LINE_INDEX']) == 0]
            if len(members) != 1:
                unresolved.append(dict(slot_id=slot_id, item_line_id=line_id,
                                       reason='Exactly one rank-zero item-line member is required'))
                continue
            item_id = int(members[0]['ITEM_ID'])
            item = self.item_definitions.get(item_id)
            permissions = [row for row in self.item_profiles.get(item_id, ())
                           if int(row['PROFILE_ID']) == mapping['profile_id']
                           and int(row['FACTION_ID']) == mapping['faction_id']
                           and int(row['LOADOUT_ID']) == identifier]
            if item is None or len(permissions) != 1:
                unresolved.append(dict(slot_id=slot_id, item_line_id=line_id, item_id=item_id,
                                       reason='Matching item definition and profile/faction/loadout permission are required'))
                continue
            resolved.append(dict(slot_id=slot_id, item_line_id=line_id, item_line_index=0,
                                 item_id=item_id, profile_name_id=int(permissions[0]['PROFILE_NAME_ID']),
                                 code_factory_name=item['CODE_FACTORY_NAME'],
                                 item_class_id=int(item['ITEM_CLASS']),
                                 item_definition_slot=int(item['SLOT']), model_name=item['MODEL_NAME'],
                                 name_id=int(item['NAME_ID']), profile_permission_verified=True))
        identity = self.identities[mapping['profile_id']]
        return dict(**mapping, **{key: value for key, value in identity.items()
                                  if key not in mapping}, default_slots=slots, instances=instances,
                    resolved_items=resolved, empty_slot_ids=empty, unresolved_items=unresolved,
                    item_line_ids_are_item_ids=False, equipment_resolved=not unresolved,
                    applied_to_client=False)

    def starter(self):
        loadout = self.loadout(LOCAL_VS_LOADOUT_ID)
        return dict(**loadout,
                    creator_profile_type_id='unverified', complete_profile_definition=False,
                    inventory_instances_created=False)

"""Captured login-tunnel name check; local policy, no character persistence."""
import re
import struct

from presets import PRESETS, SERVER_ID

SUCCESS = 1
NAME_TAKEN = 2
INVALID_NAME = 3
MAX_STRING_BYTES = 128
MAX_INNER_BYTES = 1 + 4 + MAX_STRING_BYTES + 4 + MAX_STRING_BYTES


def parse_name_check(data: bytes):
    """Return None for another well-formed tunnel operation; reject bad lengths."""
    if len(data) < 14 or data[0] != 16:
        raise ValueError("Truncated name-check tunnel")
    server, size = struct.unpack_from("<QI", data, 1)
    if server not in (0, SERVER_ID):
        raise ValueError("Name check targets an unsupported server")
    if size != len(data) - 13:
        raise ValueError("Name-check tunnel length mismatch")
    if data[13] != 1:
        return None
    if size > MAX_INNER_BYTES:
        raise ValueError("Name check exceeds supported bounds")
    offset = 14
    values = []
    for _ in range(2):
        if offset + 4 > len(data):
            raise ValueError("Truncated name-check string length")
        size = struct.unpack_from("<I", data, offset)[0]
        offset += 4
        if size > MAX_STRING_BYTES or offset + size > len(data):
            raise ValueError("Name-check string exceeds supported bounds")
        raw = data[offset:offset + size]
        try:
            value = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("Name-check string is not UTF-8") from exc
        values.append((raw, value))
        offset += size
    if offset != len(data):
        raise ValueError("Unexpected name-check trailing bytes")
    return server, values


def name_check_reply(request: bytes, *, existing_names=None):
    parsed = parse_name_check(request)
    if parsed is None:
        return None
    server, values = parsed
    name = values[0][1]
    if existing_names is None:
        existing_names = (row["name"] for row in PRESETS)
    # Explicit local test policy, not a reconstruction of DBG's name rules.
    if re.fullmatch(r"[A-Za-z0-9]{3,24}", name) is None:
        result = INVALID_NAME
    elif name.casefold() in {value.casefold() for value in existing_names}:
        result = NAME_TAKEN
    else:
        result = SUCCESS
    # Echo both strings exactly. Inner opcode 2 reaches F19010's name callback.
    inner = (b"\x02" + b"".join(struct.pack("<I", len(raw)) + raw
                               for raw, _ in values) + struct.pack("<I", result))
    reply = b"\x11" + struct.pack("<QI", server, len(inner)) + inner
    metadata = dict(name="CharacterNameValidationRequest", inner_opcode=1,
                    server_id=server, name_bytes=len(values[0][0]),
                    context_bytes=len(values[1][0]), validation_result=result,
                    name_available=result == SUCCESS)
    return metadata, reply


def profile_fixture():
    """Include reply layout and local policy in the launcher's server identity."""
    return b"MoonSol-name-check-v24\0outer16/17-inner1/2\0ascii-alnum-3..24\0casefold-presets\0"

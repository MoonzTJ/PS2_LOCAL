"""Isolated current-build VS profile activation, preserving the observed model0.

The active-profile record is distinct from saved/current loadout records. Its
102-byte minimal layout and the138-byte envelope execute in the matching native
reader/dispatcher. Other profile data remains incomplete constructor defaults.
"""
import hashlib
import struct
from presets import VS_TEST_PRESET

VERSION = 'vs-profile-activation-probe-v1'
PROFILE_ID = 19
PRESERVED_MODEL_ID = 0
# Native 9B9320 outer reader (matching sections, marker packet 11111111/22222222/
# 33333333/44444444): the third raw scalar after the attachments count lands in
# outer+48, the model ID passed to B9D0E0 -> engine+B098 lookup -> actor
# virtual+530 (first-person arms path); the first lands in +44 (component key).
MODEL_WORD_OFFSET = 3 + 4 + 102 + 4 + 8


def profile_body():
    body = bytearray(102)
    # Native98A3D0: first word -> active-profile+4 -> BDFB70 actor+7D8.
    struct.pack_into('<I', body, 0, PROFILE_ID)
    # BA4F20's actual constructor default at+84; wire cursor57.
    struct.pack_into('<I', body, 57, 0x3EB33333)
    return bytes(body)


def activation_packet(model_id=PRESERVED_MODEL_ID):
    body = profile_body()
    # 11/u16(15hex), counted active profile, empty attachments, four raw
    # scalars (the third is the model ID), two empty strings, final bool.
    packet = bytearray(b'\x11\x15\0'+struct.pack('<I',len(body))+body+bytes(4+16+8+1))
    struct.pack_into('<I', packet, MODEL_WORD_OFFSET, model_id)
    return bytes(packet)


def description(model_id=PRESERVED_MODEL_ID):
    packet = activation_packet(model_id)
    extra = dict(candidate_model_id=model_id, model_word_offset=MODEL_WORD_OFFSET) if model_id != PRESERVED_MODEL_ID else {}
    return dict(version=VERSION, enabled=True, target_character_guid=VS_TEST_PRESET['character_id'],
                profile_id=PROFILE_ID, preserved_model_id=PRESERVED_MODEL_ID, **extra,
                profile_body_bytes=len(profile_body()), profile_body_sha256=hashlib.sha256(profile_body()).hexdigest(),
                packet_bytes=len(packet), packet_sha256=hashlib.sha256(packet).hexdigest(),
                model_mapping_assigned=False, incremental_items_sent=False,
                complete_profile_data=False, appearance_verified=False, playable_character_verified=False)

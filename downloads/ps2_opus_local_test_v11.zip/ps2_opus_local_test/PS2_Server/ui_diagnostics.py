"""Version-locked display-only patch; use only the copied offline Phase 7 client.

Reads original archives, patches an independent copy, and hard-links the other
asset files into a separate directory. Never writes through the hard links.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import zlib

PACK_NAME = "ui_x64_3.pack2"
ASSET_HASH = 0xFBCEB826E38FCF0A
GFX_SHA256 = "4d9cd442cdbb4ad9af8349a7bd266ef0b0f0ca241952f1a026dfc43fbee5fc24"
ABC_SHA256 = "70addd0cb4b4ba3386a5a6ffdaf2a1885a41cc9409dc7c17b185d75e8e1cae73"
PATCHED_ABC_SHA256 = "5340900754f2d6cb6b7c7bbc350054e658e5f6eed41544342a43312dea209071"
DRAW_METHOD, BODY_START, BODY_END = 2967, 361851, 362003
DRAW_HEX = "d030d04eb70d0060aa01120e000060aa0160ba048780ba04100400002080ba0480ba04d5d112640000d066a61312140000d066a6135d02d166c60146020146fb270061900ed066a71312190000d066a713601e468718002ca02ed166be04a04697020161910ed066a813120c0000d066a813d1668a044fab2501d066a913120b0000d066a913d066aa1361900e47"
OVERLAY_NAME, MANIFEST_NAME = "Assets.local-moonsol-v28", "local-ui-v28-manifest.json"
LABELS = (" [D08]", "D08 faction=", "\nallowed=", "\nreason=", "\ncharacters=", "\nslotRows=", "\nunlocked=")

ROW_METHOD, ROW_BODY_START, ROW_BODY_END = 2959, 360311, 361511
ROW_CODE_SHA256 = "f9d801a8575ff5a631a4ac6346a59d0069f247dff39839dc530f8785890044df"
ROW_LABELS = ("PS2_LOCAL_D12_ROWS", "_sans", "D12 native rows (display only)\n",
              "\ncharacters=", "\nservers=", "\n  row ", " (showing first 4)",
              " missing", "\n    ", " Name=", " Guid=", " EmpireId=", " BattleRank=",
              " ServerId=", " ProfileId=", " Id=", " IsActive=", " IsLocked=")
ALL_LABELS = LABELS + ROW_LABELS + ("MoonSol",)

# Both renderers read these typed row getters. The native source resolves
# NameId=0 to an empty string, even though the wire's literal name is MoonSol.
# Keep resolved names; supply a display fallback only for local server ID 101.
SERVER_LABEL_METHODS = (
    (643, 226964, 226989, 298, 3645, 3644),
    (695, 228300, 228325, 432, 3829, 3828),
)

def require(condition, message):
    if not condition: raise ValueError(message)

def digest(data): return hashlib.sha256(data).hexdigest()

def file_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest()

def u30(value):
    require(0 <= value < 1 << 30, "Invalid u30")
    out = bytearray()
    while value >= 128:
        out.append(value & 127 | 128); value >>= 7
    out.append(value)
    return bytes(out)

class Reader:
    def __init__(self, data): self.data, self.pos = data, 0
    def read(self, size):
        require(0 <= size <= len(self.data) - self.pos, "Truncated binary")
        result = self.data[self.pos:self.pos + size]; self.pos += size
        return result
    def byte(self): return self.read(1)[0]
    def var(self):
        value = 0
        for index in range(5):
            byte = self.byte(); value |= (byte & 127) << (7 * index)
            if byte < 128:
                require(value <= 0xFFFFFFFF, "Invalid integer")
                return value
        raise ValueError("Unterminated integer")

def string_pool(data):
    r = Reader(data)
    require(r.read(4) == b"\x10\x00\x2e\x00", "Unsupported ABC version")
    for _ in range(2):
        count = r.var(); require(count < 100000, "Invalid pool size")
        for _ in range(max(0, count - 1)): r.var()
    count = r.var(); require(count < 100000, "Invalid double pool")
    r.read(max(0, count - 1) * 8)
    start = r.pos; count = r.var(); entries = r.pos
    require(0 < count < 100000, "Invalid string pool")
    strings = [""]
    for _ in range(count - 1): strings.append(r.read(r.var()).decode("utf-8"))
    return start, entries, r.pos, strings

ONE_VAR = {0x25, 0x5D, 0x60, 0x66, 0x61, 0x68, 0x80, 0x2C, 0x62, 0x63, 0xC2}
TWO_VAR = {0x46, 0x4E, 0x4F, 0x4A}
BRANCHES = {0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x17}
PLAIN = {0x26, 0x27, 0x09, 0x20, 0x30, 0x47, 0x48, 0x73, 0x82, 0x87, 0xA0, *range(0xD0, 0xD8)}

def instructions(code):
    r = Reader(code); rows = []
    while r.pos < len(code):
        start = r.pos; op = r.byte(); args = []
        if op in ONE_VAR: args = [r.var()]
        elif op in TWO_VAR: args = [r.var(), r.var()]
        elif op in BRANCHES: args = [r.pos + 3 + int.from_bytes(r.read(3), "little", signed=True)]
        elif op == 0x24: args = [int.from_bytes(r.read(1), "little", signed=True)]
        else: require(op in PLAIN, "Unsupported draw opcode")
        rows.append(dict(offset=start, end=r.pos, op=op, args=args))
    boundaries = {row["offset"] for row in rows}
    for row in rows:
        if row["op"] in BRANCHES: require(row["args"][0] in boundaries, "Branch misses instruction boundary")
    return rows

def validate_draw(code, locals_=8, initial_scope=13, max_scope=14):
    rows = {row["offset"]: row for row in instructions(code)}
    pending = [(0, 0, initial_scope)]; reached = {}; maximum = 0
    while pending:
        pos, depth, scope = pending.pop()
        if pos in reached:
            require(reached[pos] == (depth, scope), "Stack/scope mismatch at join"); continue
        reached[pos] = (depth, scope); row = rows[pos]; op, args = row["op"], row["args"]
        pop = push = 0
        if op in (0x5D, 0x60, 0x2C, 0x24, 0x25, 0x26, 0x27, 0x20, 0x62) or 0xD0 <= op <= 0xD3: push = 1
        elif op == 0x30: pop = 1; scope += 1
        elif op == 0x66: pop, push = 1, 1
        elif op in (0x61, 0x68): pop = 2
        elif op in (0x46, 0x4A): pop, push = args[1] + 1, 1
        elif op in (0x4E, 0x4F): pop = args[1] + 1
        elif op in (0x73, 0x80, 0x82): pop, push = 1, 1
        elif op in (0x87, 0xA0): pop, push = 2, 1
        elif op in (0x63, 0x11, 0x12) or 0xD4 <= op <= 0xD7: pop = 1
        elif op in (0x13, 0x14, 0x15, 0x17): pop = 2
        elif op == 0x48: pop = 1
        if op in (0x62, 0x63, 0xC2): require(args[0] < locals_, "Local index out of bounds")
        require(depth >= pop, "Stack underflow"); depth += push - pop
        maximum = max(maximum, depth); require(scope <= max_scope, "Scope out of bounds")
        if op in (0x47, 0x48):
            require(depth == 0, "Nonempty return stack"); continue
        if op in BRANCHES:
            pending.append((args[0], depth, scope))
            if op == 0x10: continue
        require(row["end"] in rows, "Method falls off end")
        pending.append((row["end"], depth, scope))
    require(len(reached) == len(rows), "Unreachable draw instructions")
    return maximum

class Assembly:
    def __init__(self): self.data = bytearray(); self.labels = {}; self.jumps = []
    def label(self, name):
        require(name not in self.labels, "Duplicate label"); self.labels[name] = len(self.data)
    def emit(self, op, *args):
        self.data.append(op)
        for arg in args: self.data += u30(arg)
    def byte(self, value): self.data += bytes((0x24, value & 255))
    def branch(self, op, name):
        self.data.append(op); self.jumps.append((len(self.data), name)); self.data += b"\0\0\0"
    def local(self, index, write=False):
        if index <= 3: self.emit((0xD4 if write else 0xD0) + index)
        else: self.emit(0x63 if write else 0x62, index)
    def finish(self):
        for pos, name in self.jumps:
            relative = self.labels[name] - pos - 3
            require(-(1 << 23) <= relative < 1 << 23, "Branch too far")
            self.data[pos:pos + 3] = relative.to_bytes(3, "little", signed=True)
        return bytes(self.data)

def diagnostic_draw(original, indices):
    require(original.hex() == DRAW_HEX, "Unsupported draw body")
    a = Assembly()
    def get(name): a.emit(0x66, name)
    def pool(text): a.emit(0x2C, indices[text])
    def preamble():
        # Same data sources and row wrapper as CharacterCreateController.
        # Locals: characters, connection, slot rows, unlocked, index, row.
        for index in (2, 4, 5): a.byte(-1); a.local(index, True)
        a.byte(0); a.local(6, True)
        a.emit(0x20); a.emit(0x80, 561); a.local(7, True)
        a.emit(0x60, 14); a.emit(0x60, 287); get(3319); a.emit(0x46, 3079, 1); a.local(3, True)
        a.local(3); a.branch(0x12, "characters_done")
        a.local(3); a.emit(0x46, 134, 0); a.emit(0x73); a.local(2, True)
        a.label("characters_done")
        a.emit(0x60, 14); a.emit(0x2C, 5389); a.emit(0x46, 3079, 1); a.local(3, True)
        a.local(3); a.branch(0x12, "slots_done")
        a.local(3); a.emit(0x46, 134, 0); a.emit(0x73); a.local(4, True)
        a.local(4); a.byte(0); a.branch(0x15, "slots_done")
        a.local(4); a.byte(64); a.branch(0x17, "slots_done")
        a.byte(0); a.local(5, True); a.branch(0x10, "slot_condition")
        a.label("slot_body"); a.emit(0x09)
        a.emit(0x5D, 561); a.local(3); a.local(6); a.emit(0x4A, 561, 2)
        a.emit(0x80, 561); a.local(7, True)
        a.local(7); a.branch(0x12, "slot_next")
        a.local(5); a.local(7); get(567); a.emit(0xA0); a.emit(0x73); a.local(5, True)
        a.label("slot_next"); a.emit(0xC2, 6)
        a.label("slot_condition"); a.local(6); a.local(4); a.branch(0x15, "slot_body")
        a.label("slots_done")
    def display():
        a.local(0); get(2471); a.branch(0x12, "display_done")
        a.local(0); get(2471); pool("D08 faction="); a.local(1); get(522); a.emit(0xA0)
        pool("\nallowed="); a.emit(0xA0); a.local(0); get(1638); a.emit(0xA0)
        pool("\nreason="); a.emit(0xA0); a.local(0); get(2474); a.emit(0xA0)
        for prefix, index in (("\ncharacters=", 2), ("\nslotRows=", 4), ("\nunlocked=", 5)):
            pool(prefix); a.emit(0xA0); a.local(index); a.emit(0xA0)
        a.emit(0x61, 1808); a.label("display_done")
    for row in instructions(original):
        offset = row["offset"]; a.label(f"original_{offset}")
        if offset == 2: preamble()
        if offset == 66: pool(" [D08]"); a.emit(0xA0)
        if offset == 102: display()
        if row["op"] in BRANCHES: a.branch(row["op"], f"original_{row['args'][0]}")
        else: a.data += original[offset:row["end"]]
    return a.finish()

def row_diagnostics(indices):
    """Suffix for the native row draw; reads sources and writes one TextField only.

    Locals 7 stage, 8 panel, 9 connection, 10 count, 11 index, 12 row,
    13 accumulated text. Native locals 0..6 are never overwritten.
    """
    a = Assembly()
    def get(name): a.emit(0x66, name)
    def set_(name): a.emit(0x61, name)
    def pool(text): a.emit(0x2C, indices[text])
    def append(text): a.local(13); pool(text); a.emit(0xA0); a.local(13, True)
    a.local(0); get(262); a.local(7, True)
    a.local(7); a.branch(0x12, "done")
    a.local(7); pool("PS2_LOCAL_D12_ROWS"); a.emit(0x46, 5085, 1)
    a.emit(0x80, 23); a.local(8, True)
    a.local(8); a.branch(0x11, "panel_ready")
    a.emit(0x5D, 23); a.emit(0x4A, 23, 0); a.emit(0x80, 23); a.local(8, True)
    a.local(8); pool("PS2_LOCAL_D12_ROWS"); set_(198)
    for property_, value in ((5041,False),(1940,False),(2727,True),(5270,True)):
        a.local(8); a.emit(0x26 if value else 0x27); set_(property_)
    for property_, value in ((4522,20),(4523,80),(1636,1100),(1637,560)):
        a.local(8); a.emit(0x25,value); set_(property_)
    a.local(8); a.emit(0x5D,1707); pool("_sans"); a.byte(16); a.byte(-1)
    a.emit(0x4A,1707,3); set_(1706)
    a.local(7); a.local(8); a.emit(0x4F,4582,1)
    a.label("panel_ready"); pool("D12 native rows (display only)\n"); a.local(13,True)
    for kind, source, row_type, fields in (
        ("characters",3319,556,(("Name",3794),("Guid",3999),("EmpireId",4001),("BattleRank",4005),("ServerId",4007),("ProfileId",4019))),
        ("servers",3316,96,(("Id",3792),("Name",3794),("IsActive",3796),("IsLocked",3806)))):
        append("\n"+kind+"=")
        a.emit(0x60,14); a.emit(0x60,287); get(source); a.emit(0x46,3079,1); a.local(9,True)
        a.local(9); a.branch(0x11,kind+"_present")
        append(" missing"); a.branch(0x10,kind+"_done")
        a.label(kind+"_present"); a.local(9); a.emit(0x46,134,0); a.emit(0x73); a.local(10,True)
        a.local(13); a.local(10); a.emit(0xA0); a.local(13,True)
        a.local(10); a.byte(4); a.branch(0x17,kind+"_truncated")
        a.branch(0x10,kind+"_loop_init")
        a.label(kind+"_truncated"); append(" (showing first 4)")
        a.label(kind+"_loop_init"); a.byte(0); a.local(11,True); a.branch(0x10,kind+"_condition")
        a.label(kind+"_body"); a.emit(0x5D,row_type); a.local(9); a.local(11); a.emit(0x4A,row_type,2)
        a.emit(0x80,row_type); a.local(12,True)
        append("\n  row "); a.local(13); a.local(11); a.emit(0xA0); a.local(13,True)
        for i,(name,string_id) in enumerate(fields):
            if i==1 and kind=="characters": append("\n    ")
            a.local(13); pool(" "+name+"="); a.emit(0xA0)
            a.local(12); a.emit(0x2C,string_id); a.emit(0x46,136,1); a.emit(0xA0); a.local(13,True)
        a.emit(0xC2,11)
        a.label(kind+"_condition"); a.local(11); a.byte(4); a.branch(0x17,kind+"_done")
        # Stop at four before constructing a fifth row (index 4).
        a.local(11); a.byte(4); a.branch(0x15,kind+"_count_check")
        a.branch(0x10,kind+"_done")
        a.label(kind+"_count_check"); a.local(11); a.local(10); a.branch(0x15,kind+"_body")
        a.label(kind+"_done")
    a.local(8); a.local(13); set_(1808)
    a.label("done"); a.emit(0x47)
    return a.finish()

def server_name_getter(schema, name_field, id_field, label_index):
    a = Assembly()
    a.local(0); a.emit(0x30)
    a.emit(0x5D, 136); a.emit(0x60, schema); a.emit(0x66, name_field)
    a.emit(0x46, 136, 1); a.local(1, True)
    a.local(1); a.branch(0x11, "original")
    # Server rows expose string IDs; character rows expose numeric IDs.
    # Number(GetData(...)) handles either representation consistently.
    a.emit(0x5D, 8); a.emit(0x5D, 136); a.emit(0x60, schema)
    a.emit(0x66, id_field); a.emit(0x46, 136, 1); a.emit(0x46, 8, 1)
    a.byte(101); a.branch(0x14, "original")
    a.emit(0x2C, label_index); a.emit(0x48)
    a.label("original"); a.local(1); a.emit(0x48)
    code = a.finish()
    require(validate_draw(code, 2, 5, 6) == 3, "Invalid server-name getter stack")
    return code

def server_label_splices(data, label_index):
    splices = []
    for method, start, end, schema, name_field, id_field in SERVER_LABEL_METHODS:
        original = (b"\xd0\x30" + b"\x5d" + u30(136) + b"\x60" + u30(schema)
                    + b"\x66" + u30(name_field) + b"\x46" + u30(136) + u30(1) + b"\x48")
        header = b"".join(u30(v) for v in (method, 2, 1, 5, 6, len(original)))
        require(data[start:end] == header + original + b"\0\0", "Unexpected server-name getter")
        code = server_name_getter(schema, name_field, id_field, label_index)
        body = b"".join(u30(v) for v in (method, 3, 2, 5, 6, len(code))) + code + b"\0\0"
        splices.append((start, end, body))
    return splices

def patch_abc(data):
    require(digest(data) == ABC_SHA256, "Unsupported UI ABC; no patch made")
    start, entries, end, strings = string_pool(data)
    require(len(strings) == 6046, "Unexpected string pool")
    original = bytes.fromhex(DRAW_HEX)
    header = b"".join(u30(v) for v in (DRAW_METHOD,4,2,13,14,len(original)))
    require(data[BODY_START:BODY_END] == header+original+b"\0\0", "Unexpected draw record")
    require(validate_draw(original,2) == 4, "Original stack declaration mismatch")
    indices = {text:len(strings)+i for i,text in enumerate(ALL_LABELS)}
    code = diagnostic_draw(original,indices); stack = validate_draw(code)
    body = b"".join(u30(v) for v in (DRAW_METHOD,max(4,stack),8,13,14,len(code)))+code+b"\0\0"
    r=Reader(data); r.pos=ROW_BODY_START
    require([r.var() for _ in range(5)] == [ROW_METHOD,7,7,13,14], "Unexpected row draw header")
    row_original=r.read(r.var())
    require(digest(row_original)==ROW_CODE_SHA256 and len(row_original)==1190 and row_original[-1:]==b"\x47",
            "Unexpected row draw code")
    require(r.read(2)==b"\0\0" and r.pos==ROW_BODY_END, "Row draw exceptions/traits changed")
    suffix=row_diagnostics(indices); row_stack=validate_draw(suffix,14,14,14)
    row_code=row_original[:-1]+suffix
    row_body=b"".join(u30(v) for v in (ROW_METHOD,max(7,row_stack),14,13,14,len(row_code)))+row_code+b"\0\0"
    pool=u30(len(strings)+len(ALL_LABELS))+data[entries:end]
    pool+=b"".join(u30(len(x.encode()))+x.encode() for x in ALL_LABELS)
    splices=sorted([(start,end,pool),(ROW_BODY_START,ROW_BODY_END,row_body),(BODY_START,BODY_END,body)]
                   + server_label_splices(data, indices["MoonSol"]))
    result=bytearray(); previous=0
    for left,right,replacement in splices:
        result+=data[previous:left]; result+=replacement; previous=right
    result+=data[previous:]; result=bytes(result)
    require(digest(result)==PATCHED_ABC_SHA256,f"Patch differs from validated draft: {digest(result)}")
    require(string_pool(result)[3]==strings+list(ALL_LABELS),"String indices changed")
    return result,dict(method=DRAW_METHOD,row_method=ROW_METHOD,original_code_bytes=len(original),
                       patched_code_bytes=len(code),row_original_code_bytes=len(row_original),
                       row_patched_code_bytes=len(row_code),declared_stack=max(4,stack),declared_locals=8,
                       row_declared_stack=max(7,row_stack),row_declared_locals=14,rows_per_source_limit=4,
                       patched_abc_sha256=digest(result), server_label="MoonSol", server_label_id=101,
                       server_label_methods=[row[0] for row in SERVER_LABEL_METHODS])

def gfx_abc(data):
    require(data[:3] == b"CFX", "Unsupported UI compression")
    declared = struct.unpack_from("<I", data, 4)[0]
    dec = zlib.decompressobj(); payload = dec.decompress(data[8:], 2 * 1024 * 1024)
    require(dec.eof and not dec.unused_data and not dec.unconsumed_tail, "Invalid/big CFX payload")
    require(8 < declared <= len(payload) + 8, "Invalid CFX logical length")
    end = declared - 8; pos = (5 + 4 * (payload[0] >> 3) + 7) // 8 + 4
    matches = []
    while pos < end:
        start = pos; h = struct.unpack_from("<H", payload, pos)[0]; pos += 2
        code, size = h >> 6, h & 63
        if size == 63: size = struct.unpack_from("<I", payload, pos)[0]; pos += 4
        require(pos + size <= end, "Invalid SWF tag bounds")
        if code == 82:
            tag = payload[pos:pos + size]; name_end = tag.index(0, 4) + 1
            matches.append((start, pos + size, tag[:name_end], tag[name_end:]))
        pos += size
        if code == 0:
            require(pos == end, "Unexpected bytes after End tag"); break
    require(len(matches) == 1, "Expected one ABC tag")
    return declared, payload, matches[0]

def patch_gfx(data):
    require(digest(data) == GFX_SHA256, "Unsupported CharacterCreate.gfx; no patch made")
    declared, payload, (start, end, prefix, abc) = gfx_abc(data)
    changed, details = patch_abc(abc); tag = prefix + changed
    replacement = struct.pack("<HI", (82 << 6) | 63, len(tag)) + tag
    delta = len(replacement) - (end - start)
    changed_payload = payload[:start] + replacement + payload[end:]
    result = data[:4] + struct.pack("<I", declared + delta) + zlib.compress(changed_payload, 9)
    require(changed_payload[declared + delta - 8:] == payload[declared - 8:], "Opaque CFX trailer changed")
    require(gfx_abc(result)[2][3] == changed, "Patched ABC readback failed")
    details.update(original_gfx_sha256=digest(data), patched_gfx_sha256=digest(result),
                   opaque_trailer_bytes=len(payload) - declared + 8)
    return result, details

CRC_TABLE = []
for _value in range(256):
    _crc = _value
    for _ in range(8): _crc = (_crc >> 1) ^ (0x82F63B78 if _crc & 1 else 0)
    CRC_TABLE.append(_crc)
def crc32c(data, seed=0):
    crc = seed ^ 0xFFFFFFFF
    for byte in data: crc = CRC_TABLE[(crc ^ byte) & 255] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFF
def asset_crc(data): return crc32c(data, crc32c(struct.pack("<Q", ASSET_HASH)))

def inspect_pack(path):
    size = path.stat().st_size
    with path.open("rb") as stream:
        header = stream.read(160)
        require(len(header) == 160 and header[:4] == b"PAK\x01", "Unsupported pack header")
        count = struct.unpack_from("<I", header, 4)[0]; length, index = struct.unpack_from("<QQ", header, 8)
        require(length == size and 0 < count <= 100000 and index + count * 32 == size, "Invalid pack index")
        stream.seek(index); table = stream.read(count * 32); matches = []
        for i in range(count):
            asset, offset, stored, flags, checksum = struct.unpack_from("<QQQII", table, i * 32)
            require(256 <= offset <= index and stored <= index - offset, "Invalid asset bounds")
            if asset == ASSET_HASH: matches.append((i, offset, stored, flags, checksum))
        require(len(matches) == 1, "CharacterCreate asset missing or duplicated")
        row, offset, stored, flags, checksum = matches[0]
        require(flags == 16 and stored <= 1024 * 1024, "Unsupported CharacterCreate record")
        stream.seek(offset); gfx = stream.read(stored)
        require(asset_crc(gfx) == checksum, "Asset checksum mismatch")
    return dict(header=header, count=count, index=index, table=table, row=row, gfx=gfx)

def patch_pack(source, target):
    require(not target.exists(), "Patch output already exists")
    pack = inspect_pack(source); gfx, details = patch_gfx(pack["gfx"]); table = bytearray(pack["table"])
    offset = (source.stat().st_size + 255) & ~255
    index = (offset + len(gfx) + 255) & ~255; total = index + len(table)
    struct.pack_into("<QQQII", table, pack["row"] * 32, ASSET_HASH, offset, len(gfx), 16, asset_crc(gfx))
    header = bytearray(pack["header"]); struct.pack_into("<QQ", header, 8, total, index)
    # Preserve the opaque 128-byte pack-header field; native acceptance is untested.
    with source.open("rb") as original, target.open("xb") as output:
        shutil.copyfileobj(original, output, 1024 * 1024)
        output.seek(offset); output.write(gfx); output.seek(index); output.write(table)
        output.seek(0); output.write(header)
    from loading_ui import patch_independent_archive
    loading_details = patch_independent_archive(target)
    checked = inspect_pack(target); require(checked["gfx"] == gfx, "Asset readback mismatch")
    old, new = bytearray(pack["table"]), bytearray(checked["table"])
    for data in (old, new):
        for row in (pack["row"], loading_details["loading_asset_row"]):
            data[row * 32:(row + 1) * 32] = b"\0" * 32
    require(old == new, "Unrelated asset records changed")
    details.update(loading_details)
    details.update(patched_pack_sha256=file_digest(target), original_pack_sha256=file_digest(source),
                   original_pack_bytes=source.stat().st_size, patched_pack_bytes=target.stat().st_size)
    return details

def linked(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)

def overlay_config(data):
    ending = b"\r\n" if b"\r\n" in data else b"\n"
    settings = {b"packfiledir": b"PackFileDir=.\\Resources\\" + OVERLAY_NAME.encode("ascii"),
                b"directenabled": b"DirectEnabled=0", b"indirectenabled": b"IndirectEnabled=1"}
    out = []; active = found = False; seen = set()
    def missing():
        if out and not out[-1].endswith(b"\n"): out[-1] += ending
        out.extend(value + ending for key, value in settings.items() if key not in seen)
    for line in data.splitlines(keepends=True):
        stripped = line.strip()
        if stripped.startswith(b"["):
            if active: missing()
            active = stripped.lower() == b"[assetdelivery]"
            if active:
                require(not found, "Duplicate AssetDelivery section"); found = True; seen = set()
        if active and b"=" in stripped:
            key = stripped.split(b"=", 1)[0].strip().lower()
            if key in settings:
                require(key not in seen, "Duplicate asset setting"); line = settings[key] + ending; seen.add(key)
        out.append(line)
    if active: missing()
    if not found:
        if out and not out[-1].endswith(b"\n"): out[-1] += ending
        out.append(b"[AssetDelivery]" + ending); seen = set(); missing()
    return b"".join(out)

def require_local_checkpoint(game, current_config=None):
    names = ["ClientConfig.local-console-v30.ini", "ClientConfig.local-console-v29-1.ini", "ClientConfig.local-console-v29.ini", "ClientConfig.local-console-v28.ini", "ClientConfig.local-console-v25.ini",
             "ClientConfig.local-test-v07.ini"]
    if current_config is not None:
        require(re.fullmatch(r"[A-Za-z0-9_.-]+", current_config) is not None,
                "Local configuration must be a filename")
        if current_config not in names: names.insert(0, current_config)
    for name in names:
        checkpoint = game / name
        if not (checkpoint.is_file() and not linked(checkpoint)
                and checkpoint.stat().st_size < 128 * 1024):
            continue
        data = checkpoint.read_bytes()
        if data.startswith(b"\xef\xbb\xbf"): data = data[3:]
        servers = []
        for line in data.splitlines():
            line = line.strip()
            if line.startswith(b"["): break
            match = re.fullmatch(rb"(?i)Server[ \t]*=[ \t]*(.*)", line)
            if match: servers.append(match[1])
        if len(servers) != 1: continue
        endpoint = re.fullmatch(rb"127\.0\.0\.1:([0-9]+)", servers[0].strip())
        if endpoint and 1 <= int(endpoint[1]) <= 65535:
            return name
    raise ValueError(f"Could not verify copied game folder: {game}. Expected a local loopback "
                     f"configuration in {' or '.join(names)}. Check PS2_LOCAL_GAME_DIR in the CMD launcher.")

def prepare_overlay(game, current_config=None):
    game = game.resolve(strict=True); resources = game / "Resources"; source = resources / "Assets"
    require(resources.is_dir() and source.is_dir() and not linked(resources) and not linked(source),
            "Expected ordinary Resources/Assets directories in the copied game")
    require_local_checkpoint(game, current_config)
    files = sorted(source.iterdir(), key=lambda p: p.name.casefold())
    require(files and all(p.is_file() and not linked(p) for p in files), "Asset directory must contain ordinary files only")
    require(any(p.name == PACK_NAME for p in files), "Expected ui_x64_3.pack2")
    target = resources / OVERLAY_NAME
    require(not target.is_symlink() and (not target.exists() or not linked(target)), "Overlay cannot be a link")
    if target.exists():
        manifest = target / MANIFEST_NAME
        require(manifest.is_file() and not linked(manifest) and manifest.stat().st_size < 1024 * 1024,
                "Existing overlay is unrecognized; rename it before retrying")
        details = json.loads(manifest.read_text("utf-8"))
        require(details.get("version") == 28 and details.get("source_files") == [p.name for p in files], "Overlay source set changed")
        require(details.get("patched_abc_sha256") == PATCHED_ABC_SHA256 and
                details.get("server_label_id") == 101 and details.get("server_label") == "MoonSol",
                "Overlay server-name patch differs")
        require(details.get("loading_title_fallback") == "Indar" and
                details.get("loading_title_requires_native_zone_id") == 2,
                "Overlay loading-map patch differs")
        require({p.name for p in target.iterdir()} == {p.name for p in files} | {MANIFEST_NAME}, "Overlay file set changed")
        for path in files:
            destination = target / path.name; require(not linked(destination), "Unexpected overlay link")
            if path.name != PACK_NAME: require(os.path.samefile(path, destination), "Overlay file identity changed")
        require(not os.path.samefile(source / PACK_NAME, target / PACK_NAME), "Patched archive must be independent")
        require(file_digest(source / PACK_NAME) == details.get("original_pack_sha256") and
                file_digest(target / PACK_NAME) == details.get("patched_pack_sha256"), "Overlay checksum changed")
        return target, details
    pack = inspect_pack(source / PACK_NAME)
    require(digest(pack["gfx"]) == GFX_SHA256, "Unsupported UI build; no patch made")
    target.mkdir(); made = []
    try:
        details = patch_pack(source / PACK_NAME, target / PACK_NAME); made.append(target / PACK_NAME)
        for path in files:
            if path.name != PACK_NAME:
                destination = target / path.name; os.link(path, destination); made.append(destination)
        details.update(version=28, source_files=[p.name for p in files],
                       purpose="display_only_native_indar_selection_and_preserved_moonsol_menus", native_validation="pending")
        manifest = target / MANIFEST_NAME
        with manifest.open("x", encoding="utf-8") as stream:
            made.append(manifest); stream.write(json.dumps(details, indent=2) + "\n")
        return target, details
    except Exception:
        partial = target / PACK_NAME
        if partial.is_file() and partial not in made: made.append(partial)
        for path in reversed(made): path.unlink()
        target.rmdir()
        raise

"""One verified location packet after verified LocalVSTest profile activation."""
import location_probe
from presets import VS_TEST_PRESET

VERSION = 'profile19-warpgate-motion-probe-v1'


def description():
    return dict(location_probe.description(), version=VERSION, enabled=True,
                character_guid=VS_TEST_PRESET['character_id'], required_profile_id=19,
                activation_required=True, original_location_packet_unchanged=True,
                controller_or_movement_fix_verified=False)

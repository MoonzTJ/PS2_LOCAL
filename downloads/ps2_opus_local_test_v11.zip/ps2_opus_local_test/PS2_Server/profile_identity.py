"""Offline public class identities cross-checked against captured client tables.

Census does not identify its source client build. Only profile/faction identity,
English labels and reference type IDs are used; these are not complete class
definitions or the separate creator protocol's profile-type namespace.
"""
import hashlib
import json
from pathlib import Path

REFERENCE_PATH = Path(__file__).resolve().parent / 'server_data' / 'profile_identity' / 'census-profile.json'
REFERENCE_SHA256 = 'c43185e325347d0ec00cf88f87bbc1c13a991463f829ee81987d52cfb93e67b1'
REFERENCE_SOURCE = 'Pinned Daybreak Census profile reference; profile/faction IDs matched to captured client tables'


def profile_identities(tables, mappings, reference_path=REFERENCE_PATH):
    raw = Path(reference_path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != REFERENCE_SHA256:
        raise ValueError('Unsupported public profile identity reference')
    response = json.loads(raw)
    rows = response['profile_list']
    pairs = [(int(row['profile_id']), int(row['faction_id'])) for row in rows]
    expected = {(row['profile_id'], row['faction_id']) for row in mappings}
    if (response['returned'] != len(rows) or len(pairs) != len(set(pairs))
            or set(pairs) != expected):
        raise ValueError('Public profile identities differ from captured loadout mappings')
    reference = dict(zip(pairs, rows))
    types = {int(row['ID']) for row in tables['ProfileTypes.txt']}
    result = {}
    for mapping in mappings:
        profile_id, faction_id = mapping['profile_id'], mapping['faction_id']
        row = reference[(profile_id, faction_id)]
        name_ids = {int(permission['PROFILE_NAME_ID']) for permission in tables['ItemProfiles.txt']
                    if int(permission['PROFILE_ID']) == profile_id
                    and int(permission['FACTION_ID']) == faction_id
                    and int(permission['LOADOUT_ID']) == mapping['loadout_id']}
        type_id = int(row['profile_type_id'])
        if len(name_ids) != 1 or type_id not in types or not row['name']['en']:
            raise ValueError('Public profile identity needs one captured name ID and a captured type ID')
        result[profile_id] = dict(profile_id=profile_id, faction_id=faction_id,
            profile_name_id=next(iter(name_ids)), class_name=row['name']['en'],
            class_name_source=REFERENCE_SOURCE, reference_profile_type_id=type_id,
            reference_profile_type_description=row['profile_type_description'])
    return result

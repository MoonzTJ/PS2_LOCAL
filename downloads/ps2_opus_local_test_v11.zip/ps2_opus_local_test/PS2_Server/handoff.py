"""Captured-build character handoff. Synthetic identity; no world simulation."""
from __future__ import annotations

import base64
import re
import struct
import xml.etree.ElementTree as ET

from presets import PRESETS, SERVER_ID

GATEWAY_PORT = 20044
GATEWAY_PROTOCOL = "ExternalGatewayApi_4"
MAX_XML = 4096


def parse_character_login(data: bytes, *, characters=PRESETS) -> dict:
    # Captured serializer 1743210: byte opcode, two uint64s, uint32 + XML.
    if len(data) < 21 or data[0] != 7:
        raise ValueError("Truncated character-login request")
    guid, server_id, size = struct.unpack_from("<QQI", data, 1)
    if not 0 < size <= MAX_XML or len(data) != 21 + size:
        raise ValueError("Character-login XML length does not match its buffer")
    row = next((row for row in characters if row["character_id"] == guid), None)
    if row is None or server_id != SERVER_ID:
        raise ValueError("Character-login request does not select a local preset/server")
    xml = data[21:]
    if b"\0" in xml or re.search(rb"<!\s*(?:DOCTYPE|ENTITY)", xml, re.I):
        raise ValueError("Unsupported character-login XML declaration")
    try:
        root = ET.fromstring(xml.decode("utf-8"))
    except (UnicodeError, ET.ParseError) as exc:
        raise ValueError("Character-login request has invalid XML") from exc
    if root.tag != "CharacterLoginRequest":
        raise ValueError("Unexpected character-login XML root")
    # Request XML can include ClientBuildInfo and platform fields. Log no values.
    return dict(character_guid=guid, server_id=server_id,
                character_name=row["name"], request_xml_bytes=size)


def character_login_reply(selection: dict, gateway_port: int, ticket: str, key: bytes, *, characters=PRESETS) -> bytes:
    if type(gateway_port) is not int or not 1 <= gateway_port <= 65535:
        raise ValueError("Invalid local gateway port")
    if not re.fullmatch(r"Moon_local_[a-zA-Z0-9_-]{16,64}", ticket) or len(key) != 16:
        raise ValueError("Invalid synthetic local handoff material")
    guid = selection["character_guid"]
    row = next((row for row in characters if row["character_id"] == guid), None)
    if row is None or selection["server_id"] != SERVER_ID or selection["character_name"] != row["name"]:
        raise ValueError("Reply selection does not match a local preset")
    root = ET.Element("CharacterLoginReply", {
        "GatewayAddress": f"127.0.0.1:{gateway_port}",
        "GatewayTicket": ticket,
        "CharacterGuid": str(guid),
        "StationId": "1", "StationName": "Moon_local",
        "CharacterName": row["name"], "ExitURL": "", "FeatureBits": "0",
        "RecentFactionSwitches": "0", "MaxRecentFactionSwitches": "1",
        "TimeFactionSwitchAllowed": "0",
    })
    # Native F122F0 reads Data as an ELEMENT. The other fields are attributes.
    ET.SubElement(root, "Data").text = base64.b64encode(key).decode("ascii")
    xml = ET.tostring(root, encoding="utf-8")
    # Full native decoder 173E570 expects status then the counted XML buffer.
    return b"\x08" + struct.pack("<QQII", guid, SERVER_ID, 1, len(xml)) + xml


def profile_fixture() -> bytes:
    row = PRESETS[0]
    return character_login_reply(dict(character_guid=row["character_id"], server_id=SERVER_ID,
                                     character_name=row["name"]), GATEWAY_PORT,
                                 "Moon_local_profile_test_fixture", bytes(range(16)))

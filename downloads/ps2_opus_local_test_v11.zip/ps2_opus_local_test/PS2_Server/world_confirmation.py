"""Minimal initialization completion messages for the captured offline build.

Wire layouts and flag setters are traced in WORLD_CONFIRMATION_TRACE.md.
These messages report the end of this service's empty initial object stream;
they do not supply terrain, profiles, inventories, or a usable spawn.
"""
import struct

CLIENT_STARTUP_OPCODE = 0x73
CLIENT_READY_OPCODE = 0x04
ZONE_DONE_SENDING_INITIAL_DATA = b"\x05"
# Current ClientUpdate header: uint8 0x11, uint16 subtype 0x1b, bool.
# False leaves the client's required-object loader running normally.
PRELOAD_DONE = b"\x11\x1b\x00\x00"


def parse_startup_signal(payload):
    """Recognize only the exact five-byte startup message seen after self data."""
    if not payload or payload[0] != CLIENT_STARTUP_OPCODE:
        return None
    if len(payload) != 5:
        raise ValueError("Invalid client startup signal length")
    # Meaning of this current-build uint32 has not been established.
    return struct.unpack_from("<I", payload, 1)[0]


def profile_fixture():
    return (b"world-confirmation-v31.2:zone-done-after-73:preload-after-04:channel-0:once-per-session:"
            + ZONE_DONE_SENDING_INITIAL_DATA + PRELOAD_DONE)


def parse_ready_signal(payload):
    """Recognize the empty opcode-04 message emitted on entry to state 25.

    The matching native AE0070 function emits this after the state-24
    AE0550 path clears the preload flag. See the loading timeline review.
    """
    if not payload or payload[0] != CLIENT_READY_OPCODE:
        return False
    if len(payload) != 1:
        raise ValueError("Invalid client ready signal length")
    return True

"""Exact isolated mode fingerprint for VS armor/helmet delivery."""
import hashlib
from functools import lru_cache
import json
from character_loadout_test import description as loadout_description
from player_world import send_self_to_client
from presets import character_presets, VS_TEST_PRESET
from starter_character import initialize_vs_starter
import cosmetic_inventory


@lru_cache(maxsize=1)
def _description_bytes():
    expected = loadout_description()
    row = VS_TEST_PRESET
    packet = send_self_to_client(dict(character_guid=row['character_id'], character_name=row['name'], server_id=101),
        characters=character_presets(True), starter_state=initialize_vs_starter(row), owned_probe=True, cosmetic_probe=True)
    digest = hashlib.sha256(packet).hexdigest()
    expected['starter_loadout'].update(send_self_bytes=len(packet), send_self_sha256=digest)
    expected['vs_test_character']['send_self_sha256'] = digest
    expected.update(version='cosmetic-inventory-client-test-v1', owned_observer_version='local-owned-cosmetic-state-v1',
                    validated_lookup_modes=[0, 1], owned_inventory_probe=cosmetic_inventory.description())
    return json.dumps(expected, sort_keys=True).encode()


def description():
    return json.loads(_description_bytes())

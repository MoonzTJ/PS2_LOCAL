"""Shared server-side VS starter seed; native inventory/appearance remain pending.

Backend item keys are local persistence identifiers, never guessed native GUIDs.
Resolved definitions and equipped slot references are kept separate from wire
serialization and unknown appearance/quantity/ammunition values.
"""
import hashlib
import json
from pathlib import Path

from presets import PRESETS, VS_TEST_PRESET, SERVER_ID, character_presets, candidate_character_list
from profile_catalog import ProfileCatalog, MANIFEST_SHA256, LOCAL_VS_PROFILE_ID, LOCAL_VS_LOADOUT_ID
from player_world import send_self_to_client

VERSION = 'shared-vs-starter-seed-v1'


def canonical(row):
    return (json.dumps(row, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def initialize_vs_starter(identity, catalog=None):
    if (identity.get('faction_id') != 1 or identity.get('server_id') != SERVER_ID
            or identity not in (PRESETS[0], VS_TEST_PRESET)):
        raise ValueError('Starter seed requires a supported local VS identity')
    catalog = catalog if catalog is not None else ProfileCatalog()
    starter = catalog.starter()
    if not starter['equipment_resolved'] or len(starter['resolved_items']) != 14:
        raise ValueError('The VS starter references are incomplete')
    guid = identity['character_id']
    items, equipped = [], []
    for row in sorted(starter['resolved_items'], key=lambda row: row['slot_id']):
        key = f'{guid:016x}:starter-slot-{row["slot_id"]}'
        items.append(dict(backend_item_key=key, item_definition_id=row['item_id'],
                          source_item_line_id=row['item_line_id'], native_instance_guid=None,
                          quantity=None, ammunition=None))
        equipped.append(dict(slot_id=row['slot_id'], backend_item_key=key,
                             item_definition_id=row['item_id']))
    return dict(format=VERSION, identity=dict(identity), source_catalog_sha256=MANIFEST_SHA256,
        selected_class=dict(profile_id=LOCAL_VS_PROFILE_ID, loadout_id=LOCAL_VS_LOADOUT_ID,
                            tab_id=0, class_name=starter['class_name']),
        appearance=dict(head_id=None, body_model_id=None, gender=None, verified=False),
        owned_items=items, equipped_slots=equipped,
        empty_slot_ids=sorted(starter['empty_slot_ids']),
        backend_starter_references_resolved=True, native_inventory_serialized=False,
        native_loadout_applied=False, playable_character_verified=False)


def seed_states(catalog=None):
    catalog = catalog if catalog is not None else ProfileCatalog()
    return [initialize_vs_starter(row, catalog) for row in (PRESETS[0], VS_TEST_PRESET)]


def persist_seeds(directory, records):
    directory = Path(directory)
    if directory.is_symlink():
        raise ValueError('Use a regular character-state directory')
    directory.mkdir(parents=True, exist_ok=True)
    for record in records:
        path = directory / f'{record["identity"]["character_id"]:016x}.starter.json'
        if path.exists() or path.is_symlink():
            if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
                raise ValueError('Unsupported existing starter state')
            if json.loads(path.read_text()) != record:
                raise ValueError('Existing starter state differs; it has been preserved')
        else:
            with path.open('x', encoding='utf-8') as stream:
                stream.write(json.dumps(record, indent=2) + '\n')


def test_description(records=None):
    records = seed_states() if records is None else records
    characters = character_presets(True)
    selection = dict(character_guid=VS_TEST_PRESET['character_id'],
                     character_name=VS_TEST_PRESET['name'], server_id=SERVER_ID)
    return dict(version=VERSION, enabled=True, name=VS_TEST_PRESET['name'],
        character_guid=VS_TEST_PRESET['character_id'], faction_id=1,
        character_count=5, baseline_characters_preserved=True,
        shared_initializer_characters=[row['identity']['name'] for row in records],
        starter_profile_id=LOCAL_VS_PROFILE_ID, starter_loadout_id=LOCAL_VS_LOADOUT_ID,
        backend_owned_item_count=14, backend_equipped_slot_count=14,
        starter_state_sha256=hashlib.sha256(canonical(records)).hexdigest(),
        character_list_sha256=hashlib.sha256(candidate_character_list(True, 1, characters=characters)).hexdigest(),
        send_self_sha256=hashlib.sha256(send_self_to_client(selection, characters=characters)).hexdigest(),
        native_inventory_serialized=False, native_loadout_applied=False,
        appearance_ids_verified=False, playable_character_verified=False)

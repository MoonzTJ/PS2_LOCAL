"""Bounded SOE v3 receive support. Application encryption is not interpreted.

CRC wire convention and packet layouts follow Sanctuary.SoeProtocol docs.
See REFERENCE_NOTICE.txt for attribution and the reused CRC test vector.
"""
from __future__ import annotations

import struct
import zlib

MAX_MESSAGE = 65536
WINDOW = 512


def crc32(data: bytes, seed: int) -> int:
    # SOE's seed scheduling is standard CRC-32 over four little-endian seed
    # bytes before the packet. Checked against an upstream known-answer vector.
    return zlib.crc32(struct.pack("<I", seed) + data) & 0xFFFFFFFF


def wrap(opcode: int, body: bytes, seed: int) -> bytes:
    packet = struct.pack(">H", opcode) + body
    return packet + struct.pack(">H", crc32(packet, seed) & 0xFFFF)


def unwrap(packet: bytes, seed: int) -> tuple[int, bytes]:
    if len(packet) < 4:
        raise ValueError("Context packet is shorter than opcode + CRC")
    expected = crc32(packet[:-2], seed) & 0xFFFF
    if struct.unpack(">H", packet[-2:])[0] != expected:
        raise ValueError("CRC mismatch")
    return struct.unpack(">H", packet[:2])[0], packet[2:-2]


def read_group(data: bytes, *, transport_packets: bool = False) -> list[bytes]:
    """Read MultiPacket lengths, or the subtly different application bundle lengths."""
    result = []
    offset = 0
    while offset < len(data):
        first = data[offset]
        offset += 1
        if first < 255 or (transport_packets and offset < len(data) and data[offset] == 0):
            length = first
        else:
            if offset + 2 > len(data):
                raise ValueError("Truncated extended bundle length")
            length = struct.unpack_from(">H", data, offset)[0]
            offset += 2
            if length == 65535:
                if offset + 4 > len(data):
                    raise ValueError("Truncated 32-bit bundle length")
                length = struct.unpack_from(">I", data, offset)[0]
                offset += 4
        if not length or offset + length > len(data):
            raise ValueError("Bundle member exceeds its buffer or is empty")
        if transport_packets and (length < 2 or data[offset] != 0):
            raise ValueError("Invalid nested transport opcode")
        result.append(data[offset:offset + length])
        offset += length
        if len(result) > 64:
            raise ValueError("Too many bundle members")
    if not result:
        raise ValueError("Empty bundle")
    return result


def application_members(data: bytes) -> list[bytes]:
    return read_group(data[2:]) if data.startswith(b"\0\x19") else [data]


class Receiver:
    """Accept ordered data, acknowledge duplicates, reassemble bounded fragments."""
    def __init__(self):
        self.expected = 0
        self.pending = {}
        self.fragment = None
        self.fragment_length = 0

    def accept(self, opcode: int, sequence: int, payload: bytes) -> tuple[str, list[bytes]]:
        if opcode not in (9, 13) or not payload:
            raise ValueError("Invalid reliable data packet")
        distance = (sequence - self.expected) & 0xFFFF
        if distance >= 0x8000:
            return "duplicate", []
        if distance >= WINDOW:
            return "outside_window", []
        if sequence in self.pending:
            if self.pending[sequence] != (opcode, payload):
                raise ValueError("Conflicting data for the same pending sequence")
            return "duplicate", []
        self.pending[sequence] = (opcode, payload)
        messages = []
        while self.expected in self.pending:
            op, data = self.pending.pop(self.expected)
            self.expected = (self.expected + 1) & 0xFFFF
            if op == 9:
                if self.fragment is not None:
                    raise ValueError("Non-fragment data interrupted fragment assembly")
                messages.append(data)
            else:
                if self.fragment is None:
                    if len(data) < 5:
                        raise ValueError("First fragment has no complete-size field or data")
                    self.fragment_length = struct.unpack_from(">I", data)[0]
                    if not 0 < self.fragment_length <= MAX_MESSAGE:
                        raise ValueError("Fragment message exceeds the 64 KiB limit")
                    self.fragment = bytearray()
                    data = data[4:]
                self.fragment.extend(data)
                if len(self.fragment) > self.fragment_length:
                    raise ValueError("Fragment assembly exceeds declared length")
                if len(self.fragment) == self.fragment_length:
                    messages.append(bytes(self.fragment))
                    self.fragment = None
                    self.fragment_length = 0
        return "accepted", messages


class Sender:
    """Cache wire packets so retransmission never advances the cipher again."""
    def __init__(self, seed: int, udp_length: int):
        self.seed = seed
        self.udp_length = udp_length
        self.next_sequence = 0
        self.pending = {}

    def queue(self, encrypted: bytes, now: float) -> list[tuple[int, bytes]]:
        capacity = self.udp_length - 6  # opcode + sequence + two-byte CRC
        if not encrypted or len(encrypted) > MAX_MESSAGE or capacity < 5:
            raise ValueError("Outgoing message exceeds supported bounds")
        if len(encrypted) <= capacity:
            chunks = [(9, encrypted)]
        else:
            data = struct.pack(">I", len(encrypted)) + encrypted
            chunks = [(13, data[i:i + capacity]) for i in range(0, len(data), capacity)]
        if len(self.pending) + len(chunks) > 64:
            raise ValueError("Outgoing reliable queue is full")
        sequences = [(self.next_sequence + i) & 0xFFFF for i in range(len(chunks))]
        if any(seq in self.pending for seq in sequences):
            raise ValueError("Outgoing sequence would overwrite pending data")
        result = []
        for sequence, (opcode, data) in zip(sequences, chunks):
            packet = wrap(opcode, struct.pack(">H", sequence) + data, self.seed)
            self.pending[sequence] = dict(packet=packet, tries=1, deadline=now + 1)
            result.append((sequence, packet))
        self.next_sequence = (self.next_sequence + len(chunks)) & 0xFFFF
        return result

    def acknowledge(self, sequence: int, cumulative: bool = False) -> int:
        if cumulative:
            # A cumulative acknowledgment ahead of the last sent sequence is invalid.
            last_sent = (self.next_sequence - 1) & 0xFFFF
            distance = (sequence - last_sent) & 0xFFFF
            if 0 < distance < 0x8000:
                return 0
            selected = [seq for seq in self.pending if (sequence - seq) & 0xFFFF < 0x8000]
        else:
            selected = [sequence] if sequence in self.pending else []
        for seq in selected:
            del self.pending[seq]
        return len(selected)

    def retries(self, now: float) -> tuple[list[tuple[int, bytes]], list[int]]:
        packets, expired = [], []
        for sequence, entry in list(self.pending.items()):
            if now < entry["deadline"]:
                continue
            if entry["tries"] >= 5:
                expired.append(sequence)
                del self.pending[sequence]
                continue
            entry["tries"] += 1
            entry["deadline"] = now + min(2 ** (entry["tries"] - 1), 8)
            packets.append((sequence, entry["packet"]))
        return packets, expired

"""Bounded VS starter references in the current client's received-loadout wire.

This fills saved/current loadouts, not owned item instances or equipped GUIDs.
Unresolved scalar fields retain zero constructor defaults. The signed header
byte is zero, not a guessed faction or slot flag. Preview appearance is untouched.
"""
import hashlib
import json
import struct

VERSION = 'vs-starter-loadout-references-v1'
EMPTY_SECTION_BYTES = 106


def encode(starter_state):
    # Import at call time: starter_character also fingerprints the empty player
    # producer. Accept only the exact currently supported initializer output;
    # progression edits need a separate validated schema and serializer.
    from starter_character import initialize_vs_starter
    expected = initialize_vs_starter(starter_state['identity'])
    canonical = lambda value: json.dumps(value, sort_keys=True, allow_nan=False,
                                         separators=(',', ':'))
    if canonical(starter_state) != canonical(expected):
        raise ValueError('Native starter loadout requires the verified unchanged starter seed')
    selected = starter_state['selected_class']
    items = {row['backend_item_key']: row for row in starter_state['owned_items']}
    slots = []
    for slot in sorted(starter_state['equipped_slots'], key=lambda row: row['slot_id']):
        line = items[slot['backend_item_key']]['source_item_line_id']
        # Slot key, raw word; item-line ID/byte/empty attachments/empty pairs/
        # raw tail; two final raw slot words. Item lines are not item IDs/GUIDs.
        slots.append(struct.pack('<IIIB5I', slot['slot_id'], 0, line, 0,
                                 0, 0, 0, 0, 0))
    record = (struct.pack('<IIbII', selected['loadout_id'], selected['profile_id'],
                          0, 0, 0) + struct.pack('<5I', 0, 0, 0, 0, len(slots))
              + b''.join(slots))
    # Saved (loadout, tab) row; empty vehicle and extra line maps; separate
    # current infantry record; empty current vehicle; raw selectors/maps zero.
    return (struct.pack('<3I', 1, selected['loadout_id'], selected['tab_id']) + record
            + bytes(8) + record + bytes(33 + 16 + 8))


def description(starter_state):
    section = encode(starter_state)
    return dict(version=VERSION, enabled=True,
                character_guid=starter_state['identity']['character_id'],
                profile_id=starter_state['selected_class']['profile_id'],
                loadout_id=starter_state['selected_class']['loadout_id'],
                tab_id=starter_state['selected_class']['tab_id'], slot_count=14,
                saved_and_current_records_serialized=True,
                section_bytes=len(section), section_sha256=hashlib.sha256(section).hexdigest(),
                unresolved_scalars_use_zero_defaults=True,
                owned_inventory_serialized=False, equipped_guids_serialized=False,
                native_application_verified=False, playable_character_verified=False)

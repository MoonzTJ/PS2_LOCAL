"""Verified uncompressed ReferenceData framing for the matching client.

This supplies the outer envelope only. Callers must establish each named body's
schema and values independently before sending it to the client.
"""
import struct


REFERENCE_DATA_OPCODE = 0x17
MAX_INLINE_NAME_BYTES = 0x1FFF
MAX_BODY_BYTES = 0x7FFFFFFF


def reference_data_packet(name: str, body: bytes) -> bytes:
    """Encode an inline name and equal raw/wire lengths (uncompressed body)."""
    if not isinstance(name, str):
        raise TypeError('ReferenceData name must be a string')
    try:
        encoded_name = name.encode('ascii')
    except UnicodeEncodeError as error:
        raise ValueError('ReferenceData name must be ASCII') from error
    if not encoded_name or b'\0' in encoded_name or len(encoded_name) > MAX_INLINE_NAME_BYTES:
        raise ValueError('ReferenceData name must contain 1..8191 non-NUL ASCII bytes')
    if not isinstance(body, bytes):
        raise TypeError('ReferenceData body must be bytes')
    if len(body) > MAX_BODY_BYTES:
        raise ValueError('ReferenceData body exceeds the native signed length field')
    return (bytes([REFERENCE_DATA_OPCODE]) +
            struct.pack('<H', 0x2000 | len(encoded_name)) + encoded_name + b'\0' +
            struct.pack('<II', len(body), len(body)) + body)

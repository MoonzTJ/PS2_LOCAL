"""Bounded reads of the matching local player's received character state.

No native calls or process writes. A nonempty loadout is not a playable soldier.
Shared item-line results describe rank zero only, not progression selection.
"""
import struct
import win_reader as win
from profile_catalog import ProfileCatalog

VERSION = 'local-character-state-v1'
SIGNATURES = {
    0x9937F0: bytes.fromhex('48895c2408574883ec20488bda488bf9'),
    0x14252F0: bytes.fromhex('48895c2408574883ec208b0504aec102'),
    0x9AA720: bytes.fromhex('48895c2408488974241048897c242041'),
    0xD3F860: bytes.fromhex('48895c2410574883ec20488bfa488bd9'),
    0x159A7F0: bytes.fromhex('40534883ec20488bc14533c9488b89a8'),
    0xD01530: bytes.fromhex('4883ec28833900440fb6c2488bd17e51'),
}


class StableFields:
    def __init__(self, read, limit):
        self.read, self.limit, self.bytes, self.fields = read, limit, 0, {}

    def exact(self, address, size):
        key = address, size
        if key not in self.fields:
            # Reserve the same reads again for the stability check.
            win.require(2*(self.bytes+size) <= self.limit, 'Character field read limit reached')
            self.fields[key] = self.read.exact(address, size)
            self.bytes += size
        return self.fields[key]

    def u32(self, address):
        return struct.unpack('<I', self.exact(address, 4))[0]

    def u64(self, address):
        return struct.unpack('<Q', self.exact(address, 8))[0]

    def verify(self):
        for (address, size), value in self.fields.items():
            win.require(self.read.exact(address, size) == value,
                        'Character fields changed during snapshot')


def record(fields, address):
    identifier, profile, flag, raw_c, raw_10 = struct.unpack('<IIiii', fields.exact(address, 20))
    count, node, tail = struct.unpack('<QQQ', fields.exact(address+0x68, 24))
    capacity = fields.u64(address+0x88)
    win.require(count <= 32 and count <= capacity <= 65536,
                'Character slot map exceeds diagnostic bounds')
    win.require((not count and not node and not tail) or (count and node and tail and capacity and not capacity & (capacity-1)),
                'Character slot map layout is invalid')
    slots, seen, last = [], set(), 0
    for _ in range(count):
        win.require(node and node not in seen, 'Character slots are incomplete or cyclic')
        seen.add(node)
        raw = fields.exact(node, 20)
        slots.append(dict(slot_id=struct.unpack_from('<I',raw)[0],
                          item_line_id=struct.unpack_from('<I',raw,16)[0]))
        last, node = node, fields.u64(node+0x138)
    win.require(not node and last == tail, 'Character slot count or tail changed')
    qualifies = (0 < identifier <= 0x7fffffff and 0 < profile <= 0x7fffffff
                 and 0 <= flag <= 4 and raw_c >= 0 and raw_10 >= 0 and bool(count))
    return dict(raw_identifier=identifier, profile_id=profile, signed_header_flag=flag,
                raw_c=raw_c, raw_10=raw_10, slot_count=count, slots=slots,
                qualifies_for_native_profile_getter=qualifies)


def shared_rank_zero(read, base, expected):
    fields = StableFields(read, 2048)
    service = fields.u64(base+0x426F320)
    if not service:
        fields.verify()
        return dict(available=True, present=False, rows=[], rank_zero_only=True, stable_reread=True)
    buckets, capacity = struct.unpack('<QQ', fields.exact(service+0xA0,16))
    win.require(capacity <= 1048576 and (not capacity or (buckets and not capacity & (capacity-1))),
                'Shared item-line catalog exceeds diagnostic bounds')
    rows=[]
    for line, definition in sorted(expected.items()):
        node = fields.u64(buckets+(line & (capacity-1))*8) if capacity else 0
        seen, found, resolved, complete = set(), False, None, True
        for _ in range(4):
            if not node:
                break
            win.require(node not in seen, 'Shared item-line bucket is cyclic')
            seen.add(node)
            if fields.u32(node) == line:
                found = True
                rank_node = fields.u64(node+0x38)  # Value+30, key node+08.
                ranks=set()
                for _ in range(4):
                    if not rank_node:
                        break
                    win.require(rank_node not in ranks, 'Shared item-line rank list is cyclic')
                    ranks.add(rank_node)
                    item, rank = struct.unpack('<I4xI',fields.exact(rank_node+0x30,12))
                    if rank == 0:
                        resolved=item
                        break
                    rank_node=fields.u64(rank_node+0x20)
                else:
                    complete = not rank_node
                node=0
                break
            node=fields.u64(node+0x88)
        if node:
            complete=False
        rows.append(dict(item_line_id=line, found=found, rank_zero_definition_id=resolved,
                         expected_definition_id=definition, matches_starter=resolved==definition,
                         search_complete=complete))
    fields.verify()
    return dict(available=True, present=True, rows=rows, rank_zero_only=True, stable_reread=True,
                current_progression_rank_verified=False)


def character_state(read, base, engine, database, player, guid, *, include_shared=True):
    for rva, signature in SIGNATURES.items():
        win.require(read.exact(base+rva,len(signature)) == signature,
                    'Native character-state reader differs from the matching build')
    fields = StableFields(read,4096)
    win.require(fields.u64(engine+0xA2E0)==database and fields.u64(database+0xD68)==player
                and fields.u64(player+0x18)==guid,
                'Native character-state identity changed')
    current=record(fields,player+0x7DF30)
    count,node,tail=struct.unpack('<QQQ',fields.exact(player+0x7DE20,24))
    win.require(count <= 32, 'Saved loadout count exceeds diagnostic bounds')
    saved,seen,last=None,set(),0
    for _ in range(count):
        win.require(node and node not in seen, 'Saved loadouts are incomplete or cyclic')
        seen.add(node)
        keys=struct.unpack('<II',fields.exact(node,8))
        if keys == (17,0):
            win.require(saved is None,'Duplicate VS starter loadout row')
            saved=record(fields,node+8)
        last,node=node,fields.u64(node+0xA0)
    win.require(not node and last==tail, 'Saved loadout count or tail changed')
    counts=dict(owned_definition_count=fields.u64(player+0x7CA40),
                owned_guid_count=fields.u64(player+0x7CA80),
                equipment_row_count=fields.u64(player+0x7D838),
                selected_equipment_key_raw=fields.u32(player+0x218))
    win.require(all(value <= 65536 for key,value in counts.items() if key.endswith('_count')),
                'Character inventory count exceeds diagnostic bounds')
    fields.verify()
    starter=ProfileCatalog().starter()
    expected={row['slot_id']:row['item_line_id'] for row in starter['resolved_items']}
    def matches(row):
        return bool(row and row['raw_identifier']==17 and row['profile_id']==19
                    and row['qualifies_for_native_profile_getter'] and row['slot_count']==14
                    and {s['slot_id']:s['item_line_id'] for s in row['slots']}==expected)
    try:
        shared=(shared_rank_zero(read,base,{row['item_line_id']:row['item_id'] for row in starter['resolved_items']})
                if include_shared else dict(available=False,reason='Previously verified; omitted to reserve ownership read budget'))
    except ValueError as exc:
        shared=dict(available=False,reason=str(exc),rank_zero_only=True)
    return dict(available=True,version=VERSION,current_loadout=current,
                saved_loadout_count=count,saved_vs_starter=saved,
                current_matches_vs_starter=matches(current),saved_matches_vs_starter=matches(saved),
                shared_rank_zero_catalog=shared,stable_reread=True,**counts,
                owned_instances_enumerated=False,equipped_guids_enumerated=False,
                playable_character_verified=False)

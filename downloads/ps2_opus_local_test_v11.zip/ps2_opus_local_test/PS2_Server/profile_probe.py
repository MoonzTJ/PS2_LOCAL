"""Opt-in identity-only class delivery experiment, never a complete catalog.

Unfilled wire fields reproduce the matching native constructor's zero/empty
initial state. They are experimental prerequisites, not recovered server data.
Models, memberships, resource selections and inventory are deliberately absent.
"""
import hashlib
import struct

from profile_catalog import ProfileCatalog
from reference_data import reference_data_packet

PROBE_VERSION = 'identity-only-class-delivery-v1'
RECORD_BYTES = 90


def probe_body(catalog=None, model_pairs=None):
    catalog = catalog if catalog is not None else ProfileCatalog()
    model_pairs = dict(model_pairs or {})
    if not set(model_pairs) <= set(catalog.identities):
        raise ValueError('Class model candidate names an unknown profile')
    records = []
    for key, identity in sorted(catalog.identities.items()):
        record = bytearray(RECORD_BYTES)
        # Current record +00/+04/+0C. Public type IDs are matched reference
        # identities, without a source-build marker; other fields stay native
        # defaults. No historical model pair or classification is substituted.
        struct.pack_into('<II', record, 0, key, identity['profile_name_id'])
        struct.pack_into('<I', record, 12, identity['reference_profile_type_id'])
        if key in model_pairs:
            # Opt-in experiment only: wire 42/46 decode to native male/female
            # model words +28/+2C (native preview cases). Never a default.
            struct.pack_into('<II', record, 42, *model_pairs[key])
        records.append(struct.pack('<I', key) + record)
    return struct.pack('<I', len(records)) + b''.join(records)


def probe_packet(catalog=None, model_pairs=None):
    return reference_data_packet('ProfileDefinitions', probe_body(catalog, model_pairs))


def probe_description(packet=None, model_pairs=None):
    packet = packet if packet is not None else probe_packet(model_pairs=model_pairs)
    extra = dict(candidate_model_pairs={str(k): list(v) for k, v in sorted(model_pairs.items())}) if model_pairs else {}
    return dict(version=PROBE_VERSION, experimental=True, identity_count=24,
                complete_class_definitions=False, live_server_values_recovered=False,
                unfilled_fields='matching_native_constructor_defaults',
                model_ids_assigned=bool(model_pairs), classification_memberships_assigned=False,
                inventory_instances_created=False,
                packet_bytes=len(packet), packet_sha256=hashlib.sha256(packet).hexdigest(), **extra)

"""Opt-in VS Light Assault appearance candidate; never a default or recovered value.

Table-inferred, not live server data: Models.txt has exactly one PC-valid VS LA
base pair (165 male gender1, 166 female gender2). The Windows asset check
local-actor-assets-20261029-195412-729110 found both ADRs and _UI variants,
while V29's Body_*_Standard rows (1/25/26) are absent in that client.
"""
import hashlib
import json
from pathlib import Path

from zone_backend import table

VERSION = 'faction-la-menu-appearance-v3'
CLASS_MODELS_VERSION = 'vs-la-class-models-v1'
DATA = Path(__file__).resolve().parent / 'server_data' / 'appearance'
PROFILE_ID = 19
HEAD_ID = 1
GENDER = 1
MODEL_PAIR = (165, 166)  # Class record +28 male / +2C female; wire record offsets 42/46.
MODEL_FILES = {165: 'Armor_VS_Male_LightAssault_Base.adr', 166: 'Armor_VS_Female_LightAssault_Base.adr'}
# Menu rows only (v2 rendered 165 correctly). Male LA base body per faction; the
# Windows asset report found each ADR and its _UI variant. NSO (4) has no row in
# this family and keeps the default zero appearance.
FACTION_MENU_MODELS = {1: (165, 'Armor_VS_Male_LightAssault_Base.adr'),
                       2: (159, 'Armor_NC_Male_LightAssault_Base.adr'),
                       3: (143, 'Armor_TR_Male_LightAssault_Base.adr')}
ASSET_REPORT_SHA256 = '2830c8157452f9dcb0a7d710110e7d7a867e2c84e07b23a1b0c171458ab4f8aa'


def verified_rows():
    manifest = json.loads((DATA/'manifest.json').read_text())
    resources = {}
    for record in manifest['resources']:
        raw = (DATA/record['name']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != record['sha256']:
            raise ValueError('Appearance table checksum differs')
        resources[record['name']] = {int(row['ID']): row for row in table(raw)}
    models, heads = resources['Models.txt'], resources['HeadTypes.txt']
    for identifier, gender in zip(MODEL_PAIR, ('1', '2')):
        row = models[identifier]
        if (row['MODEL_FILE_NAME'] != MODEL_FILES[identifier] or row['GENDER'] != gender
                or row['IS_VALID_FOR_PC'] != '1'):
            raise ValueError('VS LA base model row differs')
    family = sorted(i for i, row in models.items() if row['IS_VALID_FOR_PC'] == '1'
                    and row['MODEL_FILE_NAME'].startswith('Armor_VS_') and 'LightAssault_Base' in row['MODEL_FILE_NAME'])
    if family != list(MODEL_PAIR):
        raise ValueError('VS LA base model pair is no longer unique')
    for identifier, name in FACTION_MENU_MODELS.values():
        row = models[identifier]
        if row['MODEL_FILE_NAME'] != name or row['GENDER'] != str(GENDER) or row['IS_VALID_FOR_PC'] != '1':
            raise ValueError('Faction LA menu model row differs')
    if heads[HEAD_ID]['GENDER'] != str(GENDER):
        raise ValueError('Candidate head does not match the male gender')
    return models, heads


verified_rows()


def class_model_pairs():
    # Windows v1 (2026-10-29): with these words in ProfileDefinitions, logging
    # into ANY character crashed the client after the class packet. Menu-only
    # v1 preview was correct. Keep this separate and off until traced natively.
    return {PROFILE_ID: MODEL_PAIR}


def class_models_description():
    return dict(version=CLASS_MODELS_VERSION, enabled=True, experimental=True, profile_id=PROFILE_ID,
                class_model_pair=list(MODEL_PAIR), windows_result='client crashed after class delivery for every character')


def preview(characters):
    return {row['character_id']: dict(head_id=HEAD_ID, model_id=FACTION_MENU_MODELS[row['faction_id']][0], gender=GENDER)
            for row in characters if row['faction_id'] in FACTION_MENU_MODELS}


def description():
    return dict(version=VERSION, enabled=True, experimental=True, table_inferred=True,
                live_server_values_recovered=False, menu_head_id=HEAD_ID, menu_gender=GENDER,
                menu_models_by_faction={str(f): m for f, (m, _) in sorted(FACTION_MENU_MODELS.items())},
                unchanged_factions=[4], class_definitions_unchanged=True,
                windows_v2_preview='VS LA body and head rendered for LocalVSTest; login unaffected',
                activation_model_word_changed=False,
                asset_presence_evidence='local-actor-assets-20261029-195412-729110',
                asset_presence_report_sha256=ASSET_REPORT_SHA256, windows_appearance_verified=False)

"""Matching-build item metadata framing, separate from owned inventory.

Only framing is implemented here. Definition bodies must be independently
verified; accepting serialized bytes does not establish their field values.
The backend observes requests but does not send these candidate replies yet.
"""
import struct

ITEM_DEFINITION_REQUEST = b'\x09\x47\x00'
ITEM_DEFINITION_REPLY = b'\x09\x48\x00'
ITEM_DEFINITIONS = b'\x09\x49\x00'


def parse_item_definition_request(payload: bytes):
    """Recognize the actual EFB820/EE62E0 seven-byte request."""
    if not isinstance(payload, bytes):
        raise TypeError('Item definition request must be bytes')
    if not payload.startswith(ITEM_DEFINITION_REQUEST):
        return None
    if len(payload) != 7:
        raise ValueError('Invalid item definition request length')
    identifier = struct.unpack_from('<I', payload, 3)[0]
    if not 0 < identifier <= 0x7fffffff:
        raise ValueError('Invalid item definition request ID')
    return identifier


def item_definition_block(serialized: bytes) -> bytes:
    """Wrap opaque verified metadata in the native uint16/raw-LZ4 block.

    EE71F0 always decompresses this block. Equal sizes do not select the
    uncompressed copy path used by ReferenceData. A single literal run keeps
    compression standard-library-only and avoids inventing metadata fields.
    """
    if not isinstance(serialized, bytes):
        raise TypeError('Serialized item definition must be bytes')
    size = len(serialized)
    if not 0 < size <= 0xffff:
        raise ValueError('Item definition exceeds the nonempty uint16 block limit')
    if size < 15:
        compressed = bytes([size << 4]) + serialized
    else:
        extension = size - 15
        compressed = (b'\xf0' + b'\xff' * (extension // 255) +
                      bytes([extension % 255]) + serialized)
    if len(compressed) > 0xffff:
        raise ValueError('Compressed item definition exceeds the uint16 block limit')
    return struct.pack('<HH', len(compressed), size) + compressed


def item_definition_reply(serialized: bytes) -> bytes:
    """Build command 48 framing; callers still need verified definition data."""
    body = item_definition_block(serialized)
    return ITEM_DEFINITION_REPLY + struct.pack('<I', len(body)) + body


def item_definitions_packet(serialized: tuple[bytes, ...]) -> bytes:
    """Build command 49 framing for a bounded batch of opaque definitions."""
    if not isinstance(serialized, tuple):
        raise TypeError('Item definitions batch must be a tuple')
    if not 1 <= len(serialized) <= 32:
        raise ValueError('Item definitions batch must contain 1..32 records')
    body = struct.pack('<I', len(serialized)) + b''.join(map(item_definition_block, serialized))
    return ITEM_DEFINITIONS + struct.pack('<I', len(body)) + body

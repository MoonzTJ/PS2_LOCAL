"""Current captured ExternalGatewayApi_4 framing and minimal Indar zone candidate.

The first gateway login request is plain. The client then enables the native
RC4 fast cipher with the handoff key. The optional heavy secure trailer below
is a separate envelope handled after fast decoding.
"""
from __future__ import annotations

import struct

SECURE_MAGIC = bytes.fromhex("3a43d956efe3d06208ccb2bc3aed20bc")
GATEWAY_LOGIN_REPLY = b"\x02\x01"
ZONE_NAME = "Indar"
ZONE_ID = 2


def normal_packet(data: bytes) -> bytes:
    if len(data) >= 17 and data.endswith(SECURE_MAGIC):
        if data[-17] != 0:
            raise ValueError("Secure gateway envelope is not implemented")
        return data[:-17]
    return data


def parse_gateway_login(data: bytes) -> dict:
    data = normal_packet(data)
    if not 21 <= len(data) <= 2048 or data[0] != 1:
        raise ValueError("Expected channel-zero gateway LoginRequest")
    guid = struct.unpack_from("<Q", data, 1)[0]
    offset, values = 9, []
    for limit in (128, 256, 256):
        if offset + 4 > len(data):
            raise ValueError("Truncated gateway string length")
        size = struct.unpack_from("<I", data, offset)[0]
        offset += 4
        if size > limit or offset + size > len(data):
            raise ValueError("Invalid gateway string length")
        raw = data[offset:offset + size]
        offset += size
        try:
            value = raw.decode("utf-8")
        except UnicodeDecodeError:
            raise ValueError("Invalid gateway string encoding") from None
        if "\0" in value:
            raise ValueError("Gateway string contains a null byte")
        values.append(value)
    if offset != len(data):
        raise ValueError("Trailing gateway login bytes")
    ticket, descriptor, build = values
    if not ticket.startswith("Moon_local_"):
        raise ValueError("Gateway ticket was not locally issued")
    return dict(character_guid=guid, ticket=ticket, descriptor=descriptor, build=build)


def zone_details(clock_ms: int = 0, *, zone_name=ZONE_NAME, zone_id=ZONE_ID,
                 zone_instance=ZONE_ID, terrain_type=4, display_name_id=0) -> bytes:
    """Wire layout proven with RVA 996D00; some field values remain candidates.

    Terrain type 4 maps to HeightfieldLod. Zone name/IDs select Indar. Optional
    names, flags and settings are empty; no default inventory or player is sent.
    """
    name = zone_name.encode("ascii")
    if not 0 < len(name) <= 128 or b"\0" in name:
        raise ValueError("Invalid zone name")
    if any(type(v) is not int or not 0 <= v <= 0xffffffff
           for v in (zone_id, zone_instance, terrain_type, display_name_id)):
        raise ValueError("Invalid zone metadata integer")
    return (b"\x16" + struct.pack("<I", len(name)) + name
            + struct.pack("<I", terrain_type) + bytes(8)  # two empty counted strings
            + b"\0"  # zone kind candidate
            + struct.pack("<IIII", zone_id, zone_instance, display_name_id, clock_ms & 0xffffffff)
            + b"\0\x01"  # flag byte and boolean, in current decoder order
            + bytes(8))  # uint64 settings count


def tunnel_to_client(zone_packet: bytes, channel: int = 0) -> bytes:
    if not 0 <= channel <= 7 or not zone_packet:
        raise ValueError("Invalid gateway tunnel")
    return bytes([5 | (channel << 5)]) + zone_packet


def profile_fixture() -> bytes:
    from login import RC4
    cipher = RC4(bytes(range(16)))  # Public fixture; live keys are per handoff.
    return (b"ExternalGatewayApi_4:plain-login-then-handoff-rc4:v21:"
            + cipher.transform(GATEWAY_LOGIN_REPLY)
            + cipher.transform(tunnel_to_client(zone_details())))

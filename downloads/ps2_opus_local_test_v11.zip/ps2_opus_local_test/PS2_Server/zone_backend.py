"""Independent, verified Indar static data. This is not a terrain/physics engine."""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
from types import MappingProxyType
import xml.etree.ElementTree as ET
from zone_scene import IndarScene

DEFAULT_DATA = Path(__file__).resolve().parent / "server_data" / "indar"
RESOURCE_NAMES = ("IndarAreas.xml", "ObjectTerrainData.xml", "AdminCommandAliases.xml",
                  "ZoneSetMappings.txt", "ZoneGroupMappings.txt", "LoadingScreenImages.txt")


def verified_resources(root=DEFAULT_DATA):
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if (manifest.get("format_version") != 1 or manifest.get("zone_name") != "Indar"
            or manifest.get("zone_id") != 2 or manifest.get("terrain_type") != 4
            or manifest.get("zone_instance") != 2 or manifest.get("display_name_id") != 0):
        raise ValueError("Unsupported Indar dataset identity/layout")
    rows = manifest.get("resources")
    if not isinstance(rows, list) or sorted(r.get("name", "") for r in rows) != sorted(RESOURCE_NAMES):
        raise ValueError("Indar dataset has missing/duplicate/unexpected resources")
    resources = {}
    for row in rows:
        name = row["name"]
        path = root / name
        if path.stat().st_size != row.get("bytes") or not 0 < path.stat().st_size <= 8 * 1024 * 1024:
            raise ValueError(f"Indar resource size mismatch: {name}")
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != row.get("sha256"):
            raise ValueError(f"Indar resource checksum mismatch: {name}")
        resources[name] = raw
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return manifest, resources, hashlib.sha256(canonical).hexdigest()


def dataset_fixture():
    return b"indar-static-backend-v28:" + verified_resources()[2].encode("ascii")


def xml_records(raw, fragment=False):
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ValueError("Unsupported XML declaration in zone data")
    return ET.fromstring(b"<Records>" + raw + b"</Records>" if fragment else raw)


def table(raw):
    lines = raw.decode("utf-8-sig").splitlines()
    if not lines or not lines[0].startswith("#"):
        raise ValueError("Zone table has no header")
    fields = [s.lstrip("#*") for s in lines[0].rstrip("^").split("^")]
    result = []
    for line in lines[1:]:
        if not line.strip():
            continue
        values = line.rstrip("^").split("^")
        if len(values) != len(fields):
            raise ValueError("Zone table column count differs from header")
        result.append(dict(zip(fields, values)))
    return result


@dataclass(frozen=True)
class Area:
    identifier: int
    name: str
    shape: str
    geometry: object
    properties: tuple

    def summary(self):
        return dict(id=self.identifier, name=self.name, shape=self.shape,
                    geometry=dict(self.geometry), properties=[dict(p) for p in self.properties],
                    gameplay_behavior_implemented=False, verified_spawn=False)


class IndarZone:
    def __init__(self, root=DEFAULT_DATA):
        self.root = Path(root)
        self.manifest, resources, self.dataset_sha256 = verified_resources(self.root)
        self.name, self.zone_id, self.instance_id = "Indar", 2, 2
        self.loaded_utc = datetime.now(timezone.utc).isoformat()
        aliases = xml_records(resources["AdminCommandAliases.xml"])
        commands = [e.attrib.get("commandstring") for e in aliases.iter("Alias")
                    if e.attrib.get("name") == "zone.indar"]
        if commands != ["zone 2"]:
            raise ValueError("Shipped Indar command alias does not select zone 2")
        terrains = xml_records(resources["ObjectTerrainData.xml"], fragment=True)
        matches = [dict(e.attrib) for e in terrains if e.attrib.get("DataName") == "Indar"]
        if len(matches) != 1 or matches[0].get("Id") != "86":
            raise ValueError("Shipped Indar terrain metadata is absent or ambiguous")
        self.terrain = MappingProxyType(matches[0])
        areas = {}
        property_counts = Counter()
        for e in xml_records(resources["IndarAreas.xml"], fragment=True):
            if e.tag != "AreaDefinition":
                raise ValueError("Unexpected Indar area element")
            identifier, shape = int(e.attrib["id"]), e.attrib["shape"]
            if not 0 <= identifier <= 0xffffffff or identifier in areas or shape not in ("box", "sphere"):
                raise ValueError("Invalid/duplicate Indar area ID or shape")
            required = ("x1", "y1", "z1") + (("radius",) if shape == "sphere" else ("x2", "y2", "z2"))
            geometry = {k: float(e.attrib[k]) for k in required}
            geometry.update({k: float(e.attrib[k]) for k in ("rotX", "rotY", "rotZ") if k in e.attrib})
            if not all(math.isfinite(v) and abs(v) <= 1000000 for v in geometry.values()):
                raise ValueError("Invalid Indar area coordinates")
            if shape == "sphere" and geometry["radius"] <= 0:
                raise ValueError("Invalid Indar sphere radius")
            properties = []
            for prop in e:
                if prop.tag != "Property" or not prop.attrib.get("type"):
                    raise ValueError("Invalid Indar property element")
                properties.append(MappingProxyType(dict(prop.attrib)))
                property_counts[prop.attrib["type"]] += 1
            areas[identifier] = Area(identifier, e.attrib.get("name", ""), shape,
                                     MappingProxyType(geometry), tuple(properties))
        if not areas:
            raise ValueError("Indar area definitions are empty")
        self.areas = MappingProxyType(areas)
        self.property_counts = MappingProxyType(dict(property_counts))
        self.shape_counts = MappingProxyType(dict(Counter(a.shape for a in areas.values())))
        self.zone_sets = tuple(MappingProxyType(r) for r in table(resources["ZoneSetMappings.txt"])
                               if int(r["ZONE_ID"]) == self.zone_id)
        self.zone_groups = tuple(MappingProxyType(r) for r in table(resources["ZoneGroupMappings.txt"])
                                 if int(r["ZONE"]) == self.zone_id)
        self.loading_images = tuple(int(r["IMAGE_ID"]) for r in table(resources["LoadingScreenImages.txt"])
                                    if int(r["ZONE_ID"]) == self.zone_id)
        if not self.zone_sets or not self.zone_groups or not self.loading_images:
            raise ValueError("Indar mapping or loading-image data is absent")
        self.world_assets = {}
        world_manifest = self.root / "world_assets" / "manifest.json"
        if world_manifest.exists():
            imported = json.loads(world_manifest.read_text(encoding="utf-8"))
            if (imported.get("format_version") != 1 or imported.get("zone_name") != "Indar"
                    or imported.get("zone_id") != 2):
                raise ValueError("Imported world asset identity differs from Indar")
            for record in imported.get("resources", []):
                name = record.get("name")
                if name not in ("Indar.zone", "Indar.map") or name in self.world_assets:
                    raise ValueError("Invalid/duplicate imported Indar asset name")
                path = world_manifest.parent / name
                if path.stat().st_size != record.get("bytes") or not 0 < path.stat().st_size <= 128 * 1024 * 1024:
                    raise ValueError(f"Imported Indar asset size differs: {name}")
                raw = path.read_bytes()
                if hashlib.sha256(raw).hexdigest() != record.get("sha256"):
                    raise ValueError(f"Imported Indar asset checksum differs: {name}")
                self.world_assets[name] = raw
            if "Indar.zone" not in self.world_assets:
                raise ValueError("Imported world assets have no Indar.zone")
        self.scene = IndarScene(self.world_assets['Indar.zone']) if 'Indar.zone' in self.world_assets else None

    def wire_fields(self):
        return dict(zone_name=self.name, zone_id=self.zone_id, zone_instance=self.instance_id,
                    terrain_type=self.manifest["terrain_type"],
                    display_name_id=self.manifest["display_name_id"])

    def status(self):
        return dict(zone_name=self.name, zone_id=self.zone_id, zone_instance=self.instance_id,
                    static_data_loaded=True, loaded_utc=self.loaded_utc,
                    independent_of_client_process=True, client_assets_read_at_server_start=False,
                    dataset_sha256=self.dataset_sha256,
                    source_pack_sha256=self.manifest["source_pack_sha256"],
                    verified_resources=len(self.manifest["resources"]), area_count=len(self.areas),
                    area_shapes=dict(self.shape_counts), area_property_counts=dict(self.property_counts),
                    terrain_metadata=dict(self.terrain), zone_set_count=len(self.zone_sets),
                    zone_group_count=len(self.zone_groups), loading_image_ids=list(self.loading_images),
                    terrain_geometry_loaded=False, collision_simulation_implemented=False,
                    world_asset_files_cached=sorted(self.world_assets),
                    world_asset_bytes_cached=sum(len(raw) for raw in self.world_assets.values()),
                    world_asset_contents_interpreted=bool(self.scene),
                    world_asset_interpretation_scope='actor_records_only' if self.scene else 'raw_bytes_only',
                    zone_definition_actor_records=self.scene.status() if self.scene else dict(zone_definition_parsed=False),
                    world_simulation_implemented=False, spawn_verified=False,
                    client_map_load_complete="unverified", client_loading_title_visible="unverified")

    def verify(self):
        checked = IndarZone(self.root)
        if (checked.dataset_sha256 != self.dataset_sha256
                or checked.world_assets != self.world_assets):
            raise ValueError("On-disk Indar data differs from the running zone; restart with the intended build")
        return dict(self.status(), on_disk_data_matches_running_zone=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA)
    args = parser.parse_args()
    try:
        print(json.dumps(IndarZone(args.data_dir).status(), indent=2))
    except (OSError, ValueError, KeyError, ET.ParseError) as exc:
        parser.exit(1, f"Indar data verification failed: {exc}\n")


if __name__ == "__main__":
    main()

"""Isolated, server-assigned two-item ownership probe for LocalVSTest.

Only the verified generic type-36 subset is constructed. Unknown instance
scalars retain native constructor defaults; this is not a usable ability or a
weapon/loadout completion claim. Row zero is an explicit experimental equipment
row, matching the observed raw selector zero, not a profile/class ID mapping.
"""
import hashlib
import json
import struct
from functools import lru_cache
from pathlib import Path

from presets import VS_TEST_PRESET
from starter_character import canonical, initialize_vs_starter

VERSION = 'vs-owned-equipment-probe-v1'
ITEMS = ((7, 804621, 0x2000000000010107), (8, 25, 0x2000000000010108))
ROW_KEY = 0


@lru_cache(maxsize=1)
def _state_bytes():
    seed = initialize_vs_starter(VS_TEST_PRESET)
    by_slot = {row['slot_id']: row for row in seed['equipped_slots']}
    from profile_catalog import ProfileCatalog
    definitions=ProfileCatalog().item_definitions
    for slot, item, _ in ITEMS:
        if (by_slot[slot]['item_definition_id'] != item or definitions[item]['CODE_FACTORY_NAME'] != 'InfantryEquipment'
                or int(definitions[item]['ITEM_TYPE']) != 36):
            raise ValueError('Ownership subset differs from the pinned starter catalog')
    return canonical(dict(version=VERSION, character_guid=VS_TEST_PRESET['character_id'],
        equipment_row_key=ROW_KEY, equipment_row_semantics_verified=False,
        items=[dict(slot_id=slot, item_definition_id=item, native_instance_guid=guid,
                    backend_item_key=by_slot[slot]['backend_item_key'])
               for slot, item, guid in ITEMS],
        quantity_verified=False, abilities_verified=False, playable_character_verified=False))


def state():
    return json.loads(_state_bytes())


def persist(directory):
    directory = Path(directory)
    if directory.is_symlink():
        raise ValueError('Use a regular character-state directory')
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / '1000000000000101.owned-probe.json'
    expected = state()
    if path.exists() or path.is_symlink():
        if (path.is_symlink() or not path.is_file() or path.stat().st_size > 65536
                or json.loads(path.read_text()) != expected):
            raise ValueError('Existing ownership probe state differs; it has been preserved')
    else:
        with path.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(expected, indent=2) + '\n')


def item_wire(item_id, guid):
    if (item_id, guid) not in {(item, guid) for _, item, guid in ITEMS}:
        raise ValueError('Unsupported ownership probe instance')
    # BA32C0 defaults: all raw scalars zero, base boolean +2C = 1.
    # Generic detail +49 = 0; no optional record. No quantity/ammo guess.
    return struct.pack('<IIQ5IBIBQBB', item_id, 0, guid, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)


def add_packet():
    # A4B9B0 subtype 5 -> counted blob -> count -> D3F720 per instance.
    body = struct.pack('<I', len(ITEMS)) + b''.join(item_wire(item, guid) for _, item, guid in ITEMS)
    return b'\x11\x05\x00' + struct.pack('<I', len(body)) + body


def equipment_section():
    # 9AA720: one row with constructor-default raw identifier/strings,
    # two keyed slots, each default raw word/strings + authoritative owned GUID.
    return (struct.pack('<II4I', 1, ROW_KEY, 0, 0, 0, len(ITEMS))
            + b''.join(struct.pack('<IIQII', slot, 0, guid, 0, 0) for slot, _, guid in ITEMS))


def description():
    packet, equipment = add_packet(), equipment_section()
    return dict(version=VERSION, enabled=True, target_character_guid=VS_TEST_PRESET['character_id'],
        state_sha256=hashlib.sha256(canonical(state())).hexdigest(),
        item_count=2, items=state()['items'], equipment_row_key=ROW_KEY,
        equipment_section_sha256=hashlib.sha256(equipment).hexdigest(),
        add_packet_bytes=len(packet), add_packet_sha256=hashlib.sha256(packet).hexdigest(),
        delayed_delivery=True, equipment_row_semantics_verified=False,
        complete_inventory_implemented=False, playable_character_verified=False)

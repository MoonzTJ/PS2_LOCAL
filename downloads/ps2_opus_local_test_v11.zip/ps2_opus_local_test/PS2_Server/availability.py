"""Observe requests to the exact loopback ping address advertised by the reply.

No invented ping response, transport session, login reply or zone is provided.
Only bounded metadata is retained; application payloads are never logged.
"""
import os
import re
import socket
import struct

from local_test import parse_request

HOST, PORT = "127.0.0.1", 60000


def packet_metadata(data):
    result = dict(bytes=len(data), reply_sent=False, observation_only=True)
    if len(data) >= 2:
        result["possible_network_order_opcode"] = struct.unpack_from(">H", data)[0]
    if data[:2] == b"\0\1":
        try:
            request = parse_request(data)
        except ValueError:
            result["session_request_shape"] = "unrecognized"
        else:
            result.update(session_request_shape="valid", transport_version=request["protocol_version"],
                          advertised_udp_length=request["udp_length"])
            application = request["application_protocol"]
            # Arbitrary plaintext/session IDs are deliberately excluded.
            if re.fullmatch(r"(?:LoginUdp|PingUdp|ExternalGatewayApi|ExternalLoggingUdp)_[0-9]{1,3}", application):
                result["application_protocol"] = application
            else:
                result["application_protocol"] = "[unrecognized descriptor omitted]"
    return result


class AvailabilityObserver:
    def __init__(self, event):
        self.event = event
        self.sock = None
        self.tcp_sock = None
        self.tcp_connections = 0
        self.packets = 0
        self.bytes = 0
        self.errors = 0
        self.truncated = False
        self.reason = None
        candidate = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            if os.name == "nt":
                candidate.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            candidate.bind((HOST, PORT))
            candidate.setblocking(False)
            self.sock = candidate
        except OSError as exc:
            candidate.close()
            self.reason = "port_unavailable"
            self.event("availability_observation_unavailable", port=PORT,
                       error_type=type(exc).__name__, error_code=getattr(exc, "errno", None))
        else:
            self.event("availability_observation_ready", host=HOST, port=PORT,
                       scope="advertised candidate PingAddress only", responses_implemented=False,
                       attribution="destination observation; sender PID unverified")
        # The unchanged environment fixture advertises 58 HTTP placeholders at port 9.
        tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if os.name == "nt":
                tcp.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            tcp.bind((HOST, 9))
            tcp.listen(8)
            tcp.setblocking(False)
            self.tcp_sock = tcp
            self.event("environment_connection_observation_ready", host=HOST, port=9,
                       response_behavior="accept then close; no HTTP response or content read")
        except OSError as exc:
            tcp.close()
            self.event("environment_connection_observation_unavailable", port=9,
                       error_type=type(exc).__name__, error_code=getattr(exc, "errno", None))

    def status(self):
        return dict(host=HOST, port=PORT, listener_ready=self.sock is not None,
                    reason=self.reason, packets=self.packets, bytes=self.bytes,
                    truncated=self.truncated, receive_errors=self.errors,
                    replies_sent=0, zone_service_ready=False,
                    environment_tcp_listener_ready=self.tcp_sock is not None,
                    environment_tcp_connections=self.tcp_connections,
                    caveat="UDP binding changes closed-port ICMP into silent timeout; TCP binding changes refusal into accept/close. No game protocol is served.")

    def sockets(self):
        return [s for s in (self.sock, self.tcp_sock) if s is not None]

    def poll_tcp(self):
        try:
            connection, peer = self.tcp_sock.accept()
        except BlockingIOError:
            return
        except OSError:
            return
        connection.close()
        if peer[0] == HOST:
            self.tcp_connections += 1
            if self.tcp_connections <= 64:
                self.event("environment_tcp_connection_observed", source_port=peer[1], destination_port=9,
                           response_sent=False, content_read=False, source_pid_verified=False)

    def poll(self):
        try:
            data, peer = self.sock.recvfrom(65535)
        except BlockingIOError:
            return
        except OSError as exc:
            self.errors += 1
            if self.errors <= 3:
                self.event("availability_receive_error", error_type=type(exc).__name__)
            return
        if peer[0] != HOST:
            return
        self.packets += 1
        self.bytes += len(data)
        # Never allow an application packet stream to grow the diagnostic log indefinitely.
        if self.packets <= 64:
            self.event("availability_datagram_observed", source_port=peer[1], destination_port=PORT,
                       **packet_metadata(data))
        elif not self.truncated:
            self.truncated = True
            self.event("availability_detail_limit", packets=self.packets, detail_limit=64)

    def close(self):
        if self.sock is not None:
            self.sock.close()
            self.sock = None
        if self.tcp_sock is not None:
            self.tcp_sock.close()
            self.tcp_sock = None

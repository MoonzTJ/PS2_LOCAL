# Opus Local Test v10 — rebuild the arms after placement

The client's own `Logs/FirstPersonArms.log` showed the cause of the frozen view:
the model-165 activation creates the VS LA first-person arms and they become
"ready for attachments", then the placement detaches the camera from them and
nothing rebuilds them. In this version the server resends the same activation
message once, three seconds after the placement, so the client can build the
arms again and attach the camera. No new message type and no forced flags.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Select **LocalVSTest**, press **Play**, and run **Advanced → Existing bootstrap
   diagnostic (once)**. Wait for THREE beeps. About three seconds after the
   placement the server resends the activation once.
4. Look around and walk. Note whether the view now moves with the character,
   and whether arms appear.
5. Run **Capture Camera.cmd**. Return to the game within five seconds. At TWO
   beeps, hold W and turn with the mouse until THREE beeps.
6. Upload the new `reports/local-camera-….json`, the bootstrap ZIP and the
   copied game's `Logs/FirstPersonArms.log`. If it crashes, include the newest
   Logs files.

The server status records `post_placement_reactivation` (sent once, seconds
after placement, packet hash). Whether the arms were rebuilt or the camera
attached is only established by the Windows capture and log, not by the server.

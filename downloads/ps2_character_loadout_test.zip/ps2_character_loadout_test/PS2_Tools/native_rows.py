"""Bounded read-only snapshot of the exact offline client's character records.

Offsets come from the captured build's native character datasource accessor.
No arbitrary memory dump, process writes, injection, or function calls.
"""
import sys as _probe_sys
from pathlib import Path as _ProbePath
_probe_sys.path.insert(0, str(_ProbePath(__file__).resolve().parents[1] / "PS2_Server"))
import argparse
import ctypes
from datetime import datetime, timezone
import json
import math
import os
import re
from pathlib import Path
import struct
import win_reader as win
from presets import PRESETS, SERVER_NAME, ACCOUNT_CHARACTER_SLOTS, character_presets
from creator_capture import creator_state, class_definition_state, profile_loader_state

PLAYER_VECTOR_SIGNATURES = {
    0x988C9D: bytes.fromhex('498d9620020000488bcfe8746074ff'),
    0x988CAC: bytes.fromhex('498d9630020000488bcfe8656074ff'),
}


def player_record_vectors(read, base, engine, database, player, guid):
    """Observe two decoded vectors on a matched local record, not a live camera."""
    for rva, signature in PLAYER_VECTOR_SIGNATURES.items():
        win.require(read.exact(base + rva, len(signature)) == signature,
                    'Native player vector reader differs from the matching build')
    raw = read.exact(player + 0x220, 32)
    values = struct.unpack('<8f', raw)
    win.require(all(math.isfinite(value) for value in values), 'Native player record vector is nonfinite')
    win.require(read.exact(player + 0x220, 32) == raw
                and read.u64(engine + 0xA2E0) == database
                and read.u64(database + 0xD68) == player
                and read.u64(player + 0x18) == guid,
                'Native player record vectors changed during snapshot')
    return dict(available=True, field_220_f32=list(values[:4]), field_230_f32=list(values[4:]),
                field_220_raw_u32=list(struct.unpack('<4I', raw[:16])),
                field_230_raw_u32=list(struct.unpack('<4I', raw[16:])), stable_reread=True,
                camera_position_verified=False, valid_spawn_verified=False,
                interpretation='Decoded player-record fields; live transform/camera semantics remain unverified')

COUNTER_RVA = 0x4040238
TABLE_RVA = 0x4175A60
CHAR_ACCESSOR_RVA = 0x1755A26
ACCESSOR_SIGNATURE = bytes.fromhex('8b050ca88e02f7d08d48f183e13f')
STRIDE = 0x168
LOGIN_GATE_SIGNATURES = {
    0xF22990: bytes.fromhex('488b41084885c0740c80b8a1020000007403b001c332c0c3'),
    0xF229B0: bytes.fromhex('488b41084885c0740c80b8a0020000007403b001c332c0c3'),
}
FACTION_GATE_RVA = 0x1760190
FACTION_GATE_SIGNATURE = bytes.fromhex('40534883ec208d42ff')
WORLD_READY_SIGNATURES = {
    0xAE7240: bytes.fromhex('4038aeaeaf0000743a4038aeafaf00007431'),
    0xAE7267: bytes.fromhex('4038aeb0af000075134038ae38a30000740a'),
}


def world_initialization_state(read, base, engine):
    """Observe the four flags read by WaitForWorldReady, without calling it."""
    for rva, signature in WORLD_READY_SIGNATURES.items():
        win.require(read.exact(base+rva, len(signature)) == signature,
                    'Loaded world-ready gate differs from the captured build')
    state = read.u32(engine+0xA2E8)
    flags = read.exact(engine+0xAFAE, 3)
    profile = read.exact(engine+0xA338, 1)[0]
    win.require(state <= 255 and all(flag in (0, 1) for flag in flags) and profile in (0, 1),
                'Native world initialization fields differ from the captured layout')
    win.require(read.u32(engine+0xA2E8) == state
                and read.exact(engine+0xAFAE, 3) == flags
                and read.exact(engine+0xA338, 1)[0] == profile,
                'Native world initialization changed during the snapshot')
    names = {24: 'WaitForFirstZone', 25: 'WaitForConfirmationPacket',
             26: 'PostWaitForFirstZone', 27: 'Running'}
    return dict(available=True, client_run_state=state,
                client_run_state_name=names.get(state, 'other'),
                initial_zone_data_complete=bool(flags[0]),
                received_preload_done_packet=bool(flags[1]),
                wait_for_zone_ready_packet=bool(flags[2]),
                profile_preload_finished=bool(profile),
                required_objects_loaded='unverified', map_load_complete='unverified',
                interpretation='Observed native flags and run state; terrain and usability require Windows test')


def faction_permissions(read, base, wrapper):
    """Read the four cached permissions used by CanCreateCharacterOfFaction."""
    win.require(read.exact(base + FACTION_GATE_RVA, len(FACTION_GATE_SIGNATURE)) == FACTION_GATE_SIGNATURE,
                'Loaded faction gate differs from the captured build')
    descriptor = read.exact(wrapper + 0x30, 24)
    pointer, count, capacity = struct.unpack('<QQQ', descriptor)
    win.require(count <= 64 and count <= capacity <= 64,
                'Faction permission map exceeds diagnostic bounds')
    win.require(not count or (pointer and capacity and not (capacity & (capacity - 1))),
                'Faction permission map layout is invalid')
    rows, checked = [], []
    for identifier in range(1, 5):
        found, allowed, reason = False, False, 0
        if count:
            mask = capacity - 1
            bucket = identifier & mask
            for distance in range(capacity):
                address = pointer + bucket * 0x48
                key = read.u32(address)
                fields = read.exact(address + 0x38, 16)
                stored_hash = struct.unpack_from('<Q', fields, 8)[0]
                if stored_hash == 0x7FFFFFFFFFFFFFFF:
                    break
                if stored_hash == identifier and key == identifier:
                    win.require(fields[0] in (0, 1), 'Faction permission is not boolean')
                    found, allowed = True, bool(fields[0])
                    reason = 0 if allowed else struct.unpack_from('<I', fields, 4)[0]
                    checked.append((address, key, fields))
                    break
                if distance > ((bucket - stored_hash) & mask):
                    break
                bucket = (bucket + 1) & mask
        rows.append(dict(faction_id=identifier, record_present=found,
                         allowed=allowed, reason_name_id=reason))
    win.require(read.exact(wrapper + 0x30, 24) == descriptor
                and all(read.u32(address) == key and read.exact(address + 0x38, 16) == fields
                        for address, key, fields in checked),
                'Faction permissions changed during snapshot')
    return dict(available=True, cached_count=count, rows=rows,
                all_four_allowed=all(row['allowed'] for row in rows),
                interpretation='Read from the native creation permission cache; hovering/clicking needs Windows UI test')


def character_slots(read, base, wrapper):
    """Read the definition cache used by the native menu and creation gate."""
    win.require(read.exact(base + 0xF1C4B0, 5) == bytes.fromhex('48895c2408'),
                'Loaded slot decoder differs from the captured build')
    manager = read.u64(base + 0x4220D50)
    win.require(manager != 0, 'Character slot manager is not initialized')
    descriptor = read.exact(manager + 0x50, 16)
    count, node = struct.unpack('<QQ', descriptor)
    win.require(count <= 8, 'Character slot count exceeds diagnostic bounds')
    loaded = read.exact(manager + 0x80, 1)[0]
    win.require(loaded in (0, 1), 'Slot definition loaded flag is not boolean')
    account = read.exact(wrapper + 0x402, 6)
    win.require(account[0] in (0, 1), 'Slot membership flag is not boolean')
    purchased = struct.unpack_from('<I', account, 2)[0]
    win.require(purchased <= 64, 'Purchased slot count exceeds diagnostic bounds')
    api = read.u64(wrapper + 8)
    is_member = read.exact(api + 0x2A3, 1)[0] if api else 0
    win.require(is_member in (0, 1), 'Login membership flag is not boolean')
    rows, seen = [], set()
    for _ in range(count):
        win.require(node and node not in seen, 'Slot definition list is incomplete or cyclic')
        seen.add(node)
        data = read.exact(node, 0x48)
        key, identifier = struct.unpack_from('<II', data)
        flags = data[0x1C]
        maximum = struct.unpack_from('<I', data, 0x20)[0]
        win.require(key == identifier and 0 < identifier <= 64 and maximum <= 64,
                    'Slot definition fields exceed diagnostic bounds')
        unlocked = purchased if flags & 0x80 else maximum if not flags & 0x40 or account[0] or is_member else 0
        rows.append(dict(slot_id=identifier, maximum=maximum, unlocked=unlocked,
                         member_only=bool(flags & 0x40), purchasable=bool(flags & 0x80)))
        node = struct.unpack_from('<Q', data, 0x28)[0]
    win.require(node == 0 and read.exact(manager + 0x50, 16) == descriptor,
                'Slot definitions changed during snapshot')
    win.require(read.exact(wrapper + 0x402, 6) == account and read.u64(wrapper + 8) == api,
                'Slot account fields changed during snapshot')
    total = sum(row['unlocked'] for row in rows)
    return dict(available=True, definitions_loaded=bool(loaded), definition_count=count,
                rows=rows, total_unlocked=total, expected_capacity=ACCOUNT_CHARACTER_SLOTS,
                expected_capacity_observed=bool(loaded) and total == ACCOUNT_CHARACTER_SLOTS,
                interpretation='Read from native slot definitions and account fields; UI visibility needs screenshot')


def gateway_zone_state(read, base, engine, *, include_scene=False, include_actor=False,
                       include_character=False, characters=PRESETS):
    """Read current native gateway flag and zone selection, never keys/tickets.

    A received zone name is not proof that terrain or the local player loaded.
    """
    win.require(read.exact(base + 0x207EFB0, 19) == bytes.fromhex('40534883ec300fb64210488bd9888138170000'),
                'Loaded gateway callback differs from the captured build')
    raw_index = read.u32(base + 0x40402C0)
    index = (~raw_index) & 0xffffffff
    win.require(index < 64, 'Gateway singleton index differs from the captured build')
    alternate = (index-15) & 63
    network = read.u64(base + 0x417AD40 + alternate*8) ^ read.u64(base + 0x417AD40 + index*8)
    api = read.u64(network + 8)
    result = dict(available=False, reason='Native gateway API is not initialized')
    if api:
        win.require(read.u64(api) == base + 0x36F1CC0, 'Native gateway vtable differs from the captured build')
        flag = read.exact(api+0x1738,1)[0]
        win.require(flag in (0,1), 'Native gateway flag is not boolean')
        guid = read.u64(api+0x16B0)
        win.require(read.u64(network+8) == api and read.u32(base+0x40402C0) == raw_index,
                    'Native gateway changed during the snapshot')
        result = dict(available=True, native_gateway_authenticated=bool(flag),
                      known_local_character=any(row['character_id']==guid for row in characters))
        try:
            enabled = read.exact(api+0x1360,1)[0]
            after_login = read.exact(api+0x173B,1)[0]
            win.require(enabled in (0,1) and after_login in (0,1), 'Native cipher flags are not boolean')
            codec = read.u64(api+0x1350)
            vtable = read.u64(codec) if codec else 0
            result['packet_crypto'] = dict(available=True, fast_mode_enabled=bool(enabled),
                enable_after_login=bool(after_login), codec_initialized=bool(codec),
                codec_type='RC4' if vtable==base+0x36E6410 else 'uninitialized' if not codec else 'unrecognized')
        except ValueError as exc:
            result['packet_crypto'] = dict(available=False,reason=str(exc))
    try:
        pointer, length = struct.unpack('<QI',read.exact(engine+0xB0F8,12))
        fields = read.exact(engine+0xB110,20)
        selected = length==5 and read.exact(pointer,5)==b'Indar'
        result['zone_selection'] = dict(available=True, indar_name_observed=selected,
            indar_id_observed=struct.unpack_from('<I',fields,4)[0]==2,
            received_zone_id=struct.unpack_from('<I',fields,4)[0],
            received_zone_instance=struct.unpack_from('<I',fields,8)[0],
            received_display_name_id=struct.unpack_from('<I',fields,12)[0],
            map_load_complete='unverified')
    except ValueError as exc:
        result['zone_selection'] = dict(available=False,reason=str(exc))
    try:
        database = read.u64(engine+0xA2E0)
        player = read.u64(database+0xD68)
        player_guid = read.u64(player+0x18) if player else 0
        result['player_world_record'] = dict(available=True, present=bool(player),
            known_local_character=any(row['character_id']==player_guid for row in characters),
            map_load_complete='unverified')
        if player:
            win.require(read.u64(player) == base+0x3421F00,
                        'Native player vtable differs from the captured build')
            row = next((row for row in characters if row['character_id']==player_guid), None)
            faction = read.u32(player+0x20)
            name_descriptor = read.exact(player+0x28,12)
            pointer, length = struct.unpack('<QI',name_descriptor)
            name_matches = bool(row and length==len(row['name'])
                                and read.exact(pointer,length)==row['name'].encode('ascii'))
            win.require(read.u64(engine+0xA2E0)==database and read.u64(database+0xD68)==player
                        and read.u64(player+0x18)==player_guid,
                        'Native player changed during the snapshot')
            win.require(read.u32(player+0x20)==faction
                        and read.exact(player+0x28,12)==name_descriptor,
                        'Native player identity changed during the snapshot')
            matched = bool(row and name_matches and faction==row['faction_id'])
            result['player_world_record'].update(
                synthetic_identity_observed=matched,
                local_character_name=row['name'] if matched else None,
                local_faction_id=faction if matched else None,
                matching_gateway_character=bool(api and player_guid==guid),
                interpretation='Player pointer and local identity observed; terrain loading remains unverified')
            if matched:
                if include_character:
                    from character_observer import character_state
                    try:
                        state = character_state(read,base,engine,database,player,player_guid)
                    except ValueError as exc:
                        state = dict(available=False,reason=str(exc))
                    result['player_world_record']['character_state'] = state
                try:
                    vectors = player_record_vectors(read, base, engine, database, player, player_guid)
                except ValueError as exc:
                    vectors = dict(available=False, reason=str(exc))
                result['player_world_record']['decoded_vectors'] = vectors
                if include_scene or include_actor:
                    from scene_observer import scene_state
                    result['player_world_record']['scene_location'] = scene_state(
                        read, base, engine, database, player, player_guid)
                    if include_actor:
                        from actor_observer import actor_transform_state
                        result['player_world_record']['scene_location']['actor_transform'] = actor_transform_state(
                            read, base, engine, database, player, player_guid)
    except ValueError as exc:
        result['player_world_record'] = dict(available=False,reason=str(exc))
    return result


def login_state(read, base, wrapper):
    """Read only the three bounded flags used by the native login state checks.

    The completion predicate belongs to character login, NOT initial account
    authentication. These observations must never be labeled auth success.
    """
    for rva, signature in LOGIN_GATE_SIGNATURES.items():
        win.require(read.exact(base + rva, len(signature)) == signature,
                    'Loaded login gate differs from the captured build')
    api = read.u64(wrapper + 8)
    if not api:
        return dict(available=False, reason='Native login API is not initialized')
    flags = read.exact(api + 0x2A0, 3)
    win.require(all(value in (0, 1) for value in flags), 'Native login flags differ from the captured layout')
    win.require(read.u64(wrapper + 8) == api, 'Native login API changed during the snapshot')
    return dict(available=True, login_can_continue_predicate=bool(flags[0]),
                character_login_complete_predicate=bool(flags[1]),
                api_request_pending=bool(flags[2]),
                initial_account_authentication_accepted='unverified',
                interpretation='Character-login completion is not initial account authentication; pending flag is shared by API operations')


class LimitedReader:
    def __init__(self, read):
        self.read = read
        self.bytes = 0

    def exact(self, address, size):
        win.require(0x10000 <= address <= 0x7FFFFFFFFFFF - size, 'Invalid user-memory pointer')
        win.require(0 < size <= 4096 and self.bytes + size <= 16384, 'Native row read limit reached')
        self.bytes += size
        value = self.read(address, size)
        win.require(value is not None and len(value) == size, 'A native row field is unreadable')
        return value

    def u32(self, address): return struct.unpack('<I', self.exact(address,4))[0]
    def u64(self, address): return struct.unpack('<Q', self.exact(address,8))[0]


def locate(read, base):
    raw_index = read.u32(base + COUNTER_RVA)
    index = (~raw_index) & 0xFFFFFFFF
    win.require(index < 64, 'Singleton index differs from the captured build')
    alternate = (index - 15) & 63
    engine = read.u64(base + TABLE_RVA + alternate*8) ^ read.u64(base + TABLE_RVA + index*8)
    wrapper = read.u64(engine + 0xB268)
    win.require(wrapper != 0, 'Login wrapper is not initialized')
    descriptor = read.exact(wrapper + 0x20,16)
    pointer, count, capacity = struct.unpack('<Qii', descriptor)
    win.require(0 <= count <= 64 and count <= capacity <= 4096, 'Character vector is outside diagnostic bounds')
    return raw_index, engine, wrapper, descriptor, pointer, count


def snapshot(read_function, base, *, include_scene=False, include_actor=False,
             include_character=False, characters=PRESETS):
    win.require(tuple(characters) in (PRESETS, character_presets(True)),
                'Unsupported local diagnostic character catalog')
    read = LimitedReader(read_function)
    win.require(read.exact(base + CHAR_ACCESSOR_RVA, len(ACCESSOR_SIGNATURE)) == ACCESSOR_SIGNATURE,
                'Loaded character accessor differs from the captured build')
    for attempt in range(3):
        state = locate(read, base)
        raw_index, engine, wrapper, descriptor, pointer, count = state
        try:
            login = login_state(read, base, wrapper)
        except ValueError as exc:
            login = dict(available=False, reason=str(exc))
        try:
            gateway = gateway_zone_state(read, base, engine, include_scene=include_scene,
                include_actor=include_actor, include_character=include_character, characters=characters)
        except ValueError as exc:
            gateway = dict(available=False, reason=str(exc))
        try:
            world = world_initialization_state(read, base, engine)
        except ValueError as exc:
            world = dict(available=False, reason=str(exc))
        try:
            slots = character_slots(read, base, wrapper)
        except ValueError as exc:
            slots = dict(available=False, reason=str(exc))
        try:
            factions = faction_permissions(read, base, wrapper)
        except ValueError as exc:
            factions = dict(available=False, reason=str(exc))
        try:
            creator = creator_state(read, base, wrapper)
        except ValueError as exc:
            creator = dict(available=False, reason=str(exc))
        try:
            definitions = class_definition_state(read, base, engine)
        except ValueError as exc:
            definitions = dict(available=False, reason=str(exc), class_loadout_valid='unverified')
        try:
            if world.get('available') and world.get('client_run_state') in (24, 25, 26, 27):
                profiles = profile_loader_state(read, base, engine)
            else:
                profiles = dict(available=False, reason='Profile-loader inspection waits for a world-state capture',
                                client_run_state=world.get('client_run_state'),
                                class_loadout_valid='unverified')
        except ValueError as exc:
            profiles = dict(available=False, reason=str(exc))
        rows=[]
        for index in range(min(count,len(characters))):
            data = read.exact(pointer + STRIDE*index,STRIDE)
            guid=struct.unpack_from('<Q',data,0)[0]
            expected=next((r for r in characters if r['character_id']==guid),None)
            name_ptr, name_len = struct.unpack_from('<QI',data,8)
            name = dict(bytes=name_len, value=None, preset_match=False)
            if expected and 0 < name_len <= 64:
                value = read.exact(name_ptr,name_len).rstrip(b'\0')
                if value == expected['name'].encode():
                    name.update(value=expected['name'],preset_match=True)
                else:
                    name['value']='[unexpected text omitted]'
            def field(offset):return struct.unpack_from('<I',data,offset)[0]
            rows.append(dict(row=index,guid=guid,known_local_preset=bool(expected),name=name,
                             empire_id=field(0x20),home_faction_id=field(0x24),battle_rank=field(0x2C),
                             server_id=field(0x34),server_name_lookup_id=field(0x38),
                             head_id=field(0x3C), model_id=field(0x40), gender=field(0x44), profile_id=field(0x48),
                             freelance=bool(data[0x162]),prestige_level=field(0x164)))
        if locate(read,base) == state:
            # Record contents can change independently; only vector/root stability is checked.
            return dict(format_version=8 if include_character else 7 if include_actor else 6 if include_scene else 5,kind='bounded_native_character_rows',
                        native_login_state=login,
                        native_gateway_state=gateway,
                        native_world_initialization=world,
                        native_character_slots=slots,
                        native_faction_permissions=factions,
                        native_character_creator=creator,
                        native_profile_definitions=definitions,
                        native_profile_loader=profiles,
                        source_exe_sha256=win.EXPECTED_SHA256,character_count=count,
                        rows=rows,truncated=count>len(characters),read_bytes=read.bytes,vector_stable=True,
                        consistency='sequential read; process not suspended; fields may change',
                        server_rows_measured=False,expected_server_id=101,
                        expected_server_name=SERVER_NAME,world_loading_implemented=False)
    raise ValueError('Native character vector changed during all snapshot attempts')


def capture_selected(pid, game, *, include_scene=False, include_actor=False,
                     include_character=False, characters=PRESETS):
    """Version-locked capture; the opt-in VS helper allows its fifth preset."""
    reader = None
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python on Windows')
        win.require(type(pid) is int and 0 < pid <= 0xFFFFFFFF, 'Invalid PID')
        game = game.resolve(strict=True)
        exe = game / 'PlanetSide2_x64.exe'
        win.require(win.file_sha(exe) == win.EXPECTED_SHA256, 'Copied executable differs from the captured build')
        config = game / win.CONFIG
        win.require(config.stat().st_size <= 128*1024, 'Unexpected config size')
        win.check_local_config(config.read_bytes())
        argv = win.process_arguments(pid)
        win.check_arguments(argv)
        win.require(Path(argv[0]).samefile(exe), 'Command-line executable differs from the copied game')
        reader = win.WindowsReader(pid, exe)
        report = snapshot(reader.read, reader.base, include_scene=include_scene,
            include_actor=include_actor, include_character=include_character, characters=characters)
        report.update(dummy_launch_verified=True, captured_utc=datetime.now(timezone.utc).isoformat())
        return report
    finally:
        if reader is not None:
            reader.close()


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid',type=int)
    parser.add_argument('--game-dir',type=Path,default=Path(win.DEFAULT_GAME))
    parser.add_argument('--instance-id', default=None)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--capture-phase', choices=('scheduled', 'creator_selection', 'profile_loading', 'after_character_handoff'), default='scheduled')
    parser.add_argument('--creator-request', type=int, default=0)
    parser.add_argument('--profile-request', type=int, default=0)
    parser.add_argument('--creation-request', type=int, default=0)
    args=parser.parse_args(argv)
    report=None
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows')
        pid=args.pid
        if pid is None:
            value=input('V31 client_started PID (leave the game open): ').strip()
            win.require(value.isascii() and value.isdecimal() and len(value)<=10,'Enter the numeric V31 PID')
            pid=int(value)
        if args.instance_id is not None:
            win.require(re.fullmatch(r'[0-9a-f]{16}',args.instance_id) is not None,'Invalid local server run ID')
        win.require(0 <= args.creator_request <= 65536 and 0 <= args.creation_request <= 65536
                    and 0 <= args.profile_request <= 65536,
                    'Invalid diagnostic capture request number')
        report=capture_selected(pid,args.game_dir)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        output=Path(__file__).resolve().parent/'logs'
        output.mkdir(exist_ok=True)
        target=args.output or output/f'native-rows-{stamp}.json'
        report['server_instance_id']=args.instance_id
        report['capture_context']=dict(phase=args.capture_phase,
                                       creator_capture_request=args.creator_request,
                                       profile_capture_request=args.profile_request,
                                       character_creation_request=args.creation_request)
        with target.open('x',encoding='utf-8') as stream:
            json.dump(report,stream,indent=2);stream.write('\n')
        print(json.dumps(report,indent=2))
        print(f'Saved: {target}')
        print('Send this JSON together with the V31 report and screenshot.')
    except (OSError,ValueError,win.subprocess.SubprocessError) as exc:
        print(f'Native row inspection stopped: {exc}')
        if args.output is not None:
            failure=dict(kind='native_snapshot_failed',format_version=1,
                         captured_utc=datetime.now(timezone.utc).isoformat(),
                         error_type=type(exc).__name__,reason=str(exc)[:300],
                         server_instance_id=args.instance_id)
            try:
                with args.output.open('x',encoding='utf-8') as stream:
                    json.dump(failure,stream,indent=2)
            except OSError:
                pass
        return 1
    return 0


if __name__=='__main__':
    raise SystemExit(main())

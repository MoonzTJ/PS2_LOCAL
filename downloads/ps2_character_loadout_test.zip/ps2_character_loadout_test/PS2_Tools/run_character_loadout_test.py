"""Launch the isolated loadout-reference test and export bounded character state."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_class_probe as launch
except ModuleNotFoundError:
    import run_class_probe as launch
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready
from character_loadout_test import description
from presets import character_presets
import capture_local_state as capture
import native_rows
import win_reader as win

SESSION=ROOT/'.character-loadout-test-session.json'


def verify_bundle(root=ROOT):
    manifest=json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format')=='ps2-character-loadout-test-v1'
                and manifest.get('test_description')==description(),
                'Extract the complete character loadout test ZIP again.')
    for name,entry in manifest['files'].items():
        path=root/name
        win.require(not path.is_symlink() and path.is_file()
                    and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size==entry['bytes'] and win.file_sha(path)==entry['sha256'],
                    'Character loadout test files differ; extract the ZIP again.')


def verify_ready(ready,instance=None):
    launch.verify_ready(ready,instance)
    expected=description()
    win.require(ready.get('starter_loadout')==expected['starter_loadout']
                and ready.get('vs_test_character')==expected['vs_test_character']
                and not ready.get('location_probe',{}).get('enabled'),
                'Use start_character_loadout_test.cmd with its separate server.')
    return ready


def start(game):
    launch.require_closed_server()
    reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),
        '--push-lists','--class-delivery-probe','--vs-test-character','--starter-loadout-references',
        '--character-state-dir',str(SERVER/'state'),'--no-availability-observation','--log-dir',str(reports)],
        cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30))
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],
                         cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Select LocalVSTest, press Play, and keep the game/server open.')
    print('After the world HUD appears, run capture_character_loadout_test.cmd.')
    print('If loading stays on screen, wait 30 seconds and capture there instead.')
    print('This checks received loadouts; appearance, owned equipment and movement remain incomplete.')


def collect_test(game,instance,*,collector=capture.collect):
    expected=capture.read_input(Path(__file__).resolve().parent)
    def health(expected,instance=instance):
        ready=verify_ready(control_request(CONTROL_PORT,LOGIN_PORT,instance=instance),instance)
        baseline=capture.server_health(expected,instance=instance)
        return dict(baseline,starter_loadout=ready['starter_loadout'],vs_test_character=ready['vs_test_character'])
    def snapshot(pid,folder):
        result=native_rows.capture_selected(pid,folder,include_scene=True,include_actor=True,
                                          include_character=True,characters=character_presets(True))
        win.require(result.get('format_version')==8,'Use the new character loadout capture from this ZIP.')
        return result
    path,ok=collector(game,ROOT/'reports',expected,health=health,capture=snapshot)
    print('Upload this ZIP:',path)
    if ok:
        with zipfile.ZipFile(path) as archive:
            report=json.loads(archive.read('local-state.json'))
        player=report['native_snapshot'].get('native_gateway_state',{}).get('player_world_record',{})
        state=player.get('character_state',{})
        if player.get('local_character_name')!='LocalVSTest':
            print('This capture is not on LocalVSTest. Select LocalVSTest and capture again.')
        elif state.get('available'):
            print('Current starter:',state['current_matches_vs_starter'],'Saved starter:',state['saved_matches_vs_starter'])
            print('Owned GUID count:',state['owned_guid_count'],'Equipment rows:',state['equipment_row_count'])
        else:
            print('Character fields were unavailable; upload this report with the server report too.')
    else:
        print('Capture stopped; upload this small failure ZIP and the server report too.')
    try:subprocess.Popen(['explorer.exe',str(path.parent)])
    except OSError:pass
    return path,ok


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('start','client','controls','capture'),default='start')
    args=parser.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode=='start':
            selected=launch.choose_game()
            if selected:start(launch.verify_game(selected))
            return 0
        state=json.loads(SESSION.read_text())
        verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='LocalVSTest loadout delivery',
                instructions='Use LocalVSTest. After the world HUD appears, run the separate character-loadout capture CMD. Save report ZIP here if the game closes.')
        return 0 if collect_test(game,state['instance_id'])[1] else 1
    except (OSError,ValueError,subprocess.SubprocessError) as exc:
        print('Character loadout test stopped:',str(exc))
        return 1


if __name__=='__main__':raise SystemExit(main())

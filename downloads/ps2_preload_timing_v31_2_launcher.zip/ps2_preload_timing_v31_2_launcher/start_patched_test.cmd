@echo off
setlocal
cd /d "%~dp0"
title V31.2 preload timing test helper
py -3 -c "import sys, ctypes; sys.exit(sys.version_info < (3, 10) or ctypes.sizeof(ctypes.c_void_p) != 8)" >nul 2>&1
if not errorlevel 1 (
    py -3 apply_preload_patch.py --launch
    goto done
)
python -c "import sys, ctypes; sys.exit(sys.version_info < (3, 10) or ctypes.sizeof(ctypes.c_void_p) != 8)" >nul 2>&1
if not errorlevel 1 (
    python apply_preload_patch.py --launch
    goto done
)
echo 64-bit Python 3.10 or newer is required.
:done
echo.
pause

V31.2 VERIFIED-FOLDER LAUNCHER

Use this optional helper if you have several test folders and may launch the
wrong copy. It applies the same V31.2 packet timing change as the original patch.

1. Close the game, client launcher, controls, and ALL old local server consoles.
2. Extract All from this ZIP.
3. Double-click start_patched_test.cmd.
4. Choose your V31 test folder containing start_local_server.cmd,
   start_local_client.cmd, and open_test_controls.cmd.
5. The helper verifies the original/prior-patched files, creates backups, and
   opens that exact folder's server. It checks the running build before
   opening the client and controls from the SAME folder.
6. Look for V31.2 SERVER VERIFIED in the helper console.
7. Select LocalVS. Use your existing capture_loading_timeline.cmd helper,
   press Enter, click Play once, and leave the game open for 90 seconds.
8. Upload the loading timeline ZIP and the same-run console report ZIP.

If an old server is still using the test ports, the helper stops before
installing or launching. It never closes another process automatically.
The server now prints V31.2 PRELOAD TIMING TEST at startup.

The packet bytes and timing are unchanged from the original V31.2 patch.
Class definitions remain unfinished; this verifies completion flag timing,
not full world entry. The original V31.2 patch is still valid for this test.

Rollback: close all consoles and copy the three backed-up Python files
from preload_backup_... back into your selected V31 test folder.

No game executable, assets, credentials, or logs are included.

"""Install the three-file V31.2 patch into a verified V31 test folder."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import uuid

FILES = ('gateway.py', 'local_server.py', 'world_confirmation.py')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def install(target, package):
    target, package = Path(target).resolve(), Path(package).resolve()
    if not all((target/name).is_file() for name in ('start_local_server.cmd', 'start_local_client.cmd')):
        raise ValueError('Choose the V31 test folder containing start_local_server.cmd and start_local_client.cmd.')
    manifest = json.loads((package/'patch-manifest.json').read_text(encoding='utf-8'))
    if set(manifest['files']) != set(FILES):
        raise ValueError('Unexpected patch file list. Extract the complete downloaded ZIP again.')
    originals, replacements = {}, {}
    for name in FILES:
        path = target/name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Missing regular V31 file: {name}')
        originals[name] = path.read_bytes()
        replacements[name] = (package/'payload'/name).read_bytes()
        row = manifest['files'][name]
        if digest(replacements[name]) != row['patched_sha256']:
            raise ValueError(f'Patch integrity check failed: {name}. Extract the ZIP again.')
        accepted = (row['original_sha256'], row['patched_sha256'],
                    *row.get('previous_patch_sha256s', []))
        if digest(originals[name]) not in accepted:
            raise ValueError(f'{name} differs from the supplied V31 build. No files were changed.')
    if all(originals[name] == replacements[name] for name in FILES):
        return None
    label = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]
    backup = target/('preload_backup_'+label)
    backup.mkdir()
    for name in FILES:
        shutil.copy2(target/name, backup/name)
    changed, temporary = [], []
    try:
        for name in FILES:
            path = target/name
            pending = target/('.'+name+'.'+label+'.tmp')
            temporary.append(pending)
            with pending.open('xb') as stream:
                stream.write(replacements[name])
            os.replace(pending, path)
            changed.append(name)
    except Exception:
        for name in changed:
            shutil.copy2(backup/name, target/name)
        raise
    finally:
        for path in temporary:
            path.unlink(missing_ok=True)
    return backup


def require_closed_server():
    """A running backend caches its old modules until it is restarted."""
    bound = []
    try:
        for port in (20042, 20043, 20044):
            listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            bound.append(listener)
            try:
                listener.bind(('127.0.0.1', port))
            except OSError:
                raise ValueError('A local server is still running. Close all old server consoles and retry.') from None
    finally:
        for listener in bound:
            listener.close()


def launch(target, package, *, start_file=None, wait_ready=None):
    """Open all three existing launchers from the exact verified patch folder."""
    target, package = Path(target).resolve(), Path(package).resolve()
    manifest = json.loads((package/'patch-manifest.json').read_text(encoding='utf-8'))
    for name in FILES:
        if digest((target/name).read_bytes()) != manifest['files'][name]['patched_sha256']:
            raise ValueError('The selected folder is not fully patched. Run the helper again.')
    launchers = ('start_local_server.cmd', 'start_local_client.cmd', 'open_test_controls.cmd')
    if not all((target/name).is_file() for name in launchers):
        raise ValueError('The selected test folder is missing a server, client, or controls launcher.')
    if start_file is None:
        if os.name != 'nt':
            raise ValueError('Launching the game test requires Windows.')
        start_file = os.startfile
    if wait_ready is None:
        sys.path.insert(0, str(target))
        import console_common
        wait_ready = console_common.wait_ready
    start_file(str(target/launchers[0]))
    health = wait_ready(20043, 20042, 20)
    if health.get('profile_sha256') != manifest['expected_profile_sha256']:
        raise ValueError('A different server build answered. Close all server consoles and retry.')
    print('V31.2 SERVER VERIFIED. Starting the client and controls from:', target)
    for name in launchers[1:]:
        start_file(str(target/name))


def choose_folder():
    import tkinter as tk
    from tkinter import filedialog
    window = tk.Tk()
    window.withdraw()
    window.attributes('-topmost', True)
    try:
        return filedialog.askdirectory(parent=window,
            title='Choose your V31 test folder (contains start_local_server.cmd)')
    finally:
        window.destroy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('test_folder', nargs='?')
    parser.add_argument('--launch', action='store_true',
                        help='Install, verify the running build, and open its server/client/controls.')
    args = parser.parse_args()
    print('V31.2 preload timing patch. Close the game and local server first.')
    selected = args.test_folder or choose_folder()
    if not selected:
        print('No folder selected. No files changed.')
        return
    require_closed_server()
    package = Path(__file__).resolve().parent
    backup = install(selected, package)
    print('V31.2 patch installed.' if backup else 'V31.2 patch is already installed.')
    if backup:
        print('Original files saved in:', backup)
    print('Patched test folder:', Path(selected).resolve())
    if args.launch:
        launch(selected, package)
    else:
        print('Run start_local_server.cmd and start_local_client.cmd from this exact folder.')
    print('Repeat the LocalVS loading timeline capture for 90 seconds, then save a console report.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Patch stopped:', error)
        raise SystemExit(1)

"""Launch the separate LocalVSTest identity and capture its bounded state."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'PS2_Server'
if not SERVER.is_dir():
    SERVER = ROOT
sys.path.insert(0, str(SERVER))
try:
    from scripts import run_class_probe as launch
except ModuleNotFoundError:
    import run_class_probe as launch
from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready
from presets import character_presets
from starter_character import test_description
import capture_local_state as capture
import native_rows
import win_reader as win

SESSION = ROOT / '.vs-test-session.json'


def verify_bundle(root=ROOT):
    manifest = json.loads((root / 'helper-manifest.json').read_text())
    win.require(manifest.get('format') == 'ps2-vs-test-character-v1'
                and manifest.get('vs_test_character') == test_description(),
                'Extract the complete LocalVSTest bundle again.')
    for name, entry in manifest['files'].items():
        path = root / name
        win.require(not path.is_symlink() and path.is_file()
                    and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == entry['bytes'] and win.file_sha(path) == entry['sha256'],
                    'LocalVSTest files differ; extract the ZIP again.')


def verify_ready(ready, instance=None):
    launch.verify_ready(ready, instance)
    win.require(ready.get('vs_test_character') == test_description()
                and not ready.get('location_probe', {}).get('enabled'),
                'Use start_vs_test_character.cmd for this character test.')
    return ready


def start(game):
    launch.require_closed_server()
    reports = ROOT / 'reports'
    reports.mkdir(exist_ok=True)
    process = subprocess.Popen([sys.executable, str(SERVER / 'local_server.py'),
        '--push-lists', '--class-delivery-probe', '--vs-test-character',
        '--character-state-dir', str(SERVER / 'state'), '--no-availability-observation',
        '--log-dir', str(reports)], cwd=str(SERVER), creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready = verify_ready(wait_ready(CONTROL_PORT, LOGIN_PORT, 30))
    except BaseException:
        if process.poll() is None:
            process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game), instance_id=ready['instance_id'])))
    for mode in ('client', 'controls'):
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--mode', mode],
                         cwd=str(ROOT), creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('LocalVSTest is the fifth character. Original LocalVS is preserved.')
    print('Starter references are saved on the server; native appearance/equipment remain incomplete.')
    print('Use this identity for future initialization tests. No repeat location test is required.')


def collect_test(game, instance):
    expected = capture.read_input(Path(__file__).resolve().parent)
    def health(expected, instance=instance):
        verify_ready(control_request(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
        return capture.server_health(expected, instance=instance)
    path, ok = capture.collect(game, ROOT / 'reports', expected, health=health,
        capture=lambda pid, folder: native_rows.capture_selected(pid, folder,
            include_scene=True, include_actor=True, characters=character_presets(True)))
    print('Upload this ZIP:', path)
    return path, ok


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('start', 'client', 'controls', 'capture'), default='start')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8,
                    'Use 64-bit Python on Windows.')
        verify_bundle()
        if args.mode == 'start':
            selected = launch.choose_game()
            if selected:
                start(launch.verify_game(selected))
            return 0
        state = json.loads(SESSION.read_text())
        verify_ready(control_request(CONTROL_PORT, LOGIN_PORT), state['instance_id'])
        game = launch.verify_game(state['game_dir'])
        if args.mode == 'client':
            import local_client
            return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT / 'reports')])
        if args.mode == 'controls':
            import test_controls
            return test_controls.main()
        path, ok = collect_test(game, state['instance_id'])
        subprocess.Popen(['explorer.exe', str(path.parent)])
        return 0 if ok else 1
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('LocalVSTest helper stopped:', error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_vs_test_character.py" --mode start
pause

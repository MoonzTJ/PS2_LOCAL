# Opus Local Test v10.2 — automatic spawn: place first, then build the VS LA body

The client's own `Logs/FirstPersonArms.log` shows the model-165 activation
creating the first-person arms, then the placement removing them, and every
activation sent after the placement being ignored (v10 and v10.1). This version
reverses the order and runs it automatically when you spawn: about 5 seconds
after you are in the world the server places LocalVSTest at the warpgate (no
arms yet), and about 8 seconds after that it activates the VS LA body.
No new message type, no forced flags.

**No bootstrap button is needed.** Do not use Advanced → Existing bootstrap
diagnostic in this version; the server refuses its activation step on purpose.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Select **LocalVSTest** and press **Play**. Stay in the game.
4. About 5 seconds after loading in you move to the warpgate; about 8 seconds
   later the VS LA body is activated. Then look around and walk. Note whether
   the view moves with the character and whether arms appear.
5. Run **Capture Camera.cmd**. Return to the game within five seconds. At TWO
   beeps, hold W and turn with the mouse until THREE beeps.
6. Upload the new `reports/local-camera-….json` and the copied game's
   `Logs/FirstPersonArms.log`. If it crashes, include the newest Logs files.

The server status records `placement_first` (automatic placement time after
PreloadDone, activation time after placement). Whether the arms were built or
the camera attached is only established by the Windows capture and log.

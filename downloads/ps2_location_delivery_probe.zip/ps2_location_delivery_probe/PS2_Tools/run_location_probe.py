"""Isolated Windows one-shot native location delivery and paired captures."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'PS2_Server'
if not SERVER.is_dir():
    SERVER = ROOT
sys.path.insert(0, str(SERVER))

from console_common import CONTROL_PORT, LOGIN_PORT, control_request, wait_ready
import location_probe as probe
try:
    from scripts import run_class_probe as launch
except ModuleNotFoundError:
    import run_class_probe as launch
import capture_local_state as capture
import win_reader as win

SESSION = ROOT / '.location-probe-session.json'


def verify_bundle(root=ROOT):
    manifest = json.loads((root / 'helper-manifest.json').read_text())
    win.require(manifest.get('format') == 'ps2-location-delivery-probe-v1'
                and manifest.get('location_probe') == probe.description(), 'Extract the complete location probe ZIP again.')
    for name, row in manifest['files'].items():
        path = root / name
        win.require(not path.is_symlink() and path.is_file()
                    and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == row['bytes'] and win.file_sha(path) == row['sha256'],
                    'Location probe files differ; extract the ZIP again.')


def verify_ready(ready, instance=None):
    launch.verify_ready(ready, instance)
    observed = ready.get('location_probe', {})
    win.require(observed.get('enabled') is True
                and all(observed.get(k) == v for k, v in probe.description().items()),
                'Run this test using start_location_probe.cmd.')
    return ready


def require_ready_actor(snapshot):
    win.require(snapshot.get('format_version') == 7 and snapshot.get('dummy_launch_verified') is True,
                'A matching local actor capture is required before sending.')
    world = snapshot.get('native_world_initialization', {})
    gateway = snapshot.get('native_gateway_state', {})
    player = gateway.get('player_world_record', {})
    actor = player.get('scene_location', {}).get('actor_transform', {})
    win.require(world.get('client_run_state') == 27
                and world.get('initial_zone_data_complete') is True
                and world.get('received_preload_done_packet') is True
                and world.get('wait_for_zone_ready_packet') is False
                and gateway.get('native_gateway_authenticated') is True
                and gateway.get('zone_selection', {}).get('received_zone_id') == 2
                and player.get('local_character_name') == 'LocalVS'
                and player.get('local_faction_id') == 1
                and player.get('matching_gateway_character') is True
                and actor.get('available') is True and actor.get('actor_matches_local_character') is True
                and actor.get('manager_cached_identity_matches_actor') is True
                and actor.get('transform_cache_clean') is True and actor.get('stable_reread') is True
                and actor.get('primary_vtable_rva') == '0x3491548'
                and actor.get('position_f32') == [0, 0, 0, 1],
                'Wait until LocalVS is in the world at the original position, then retry. No location sent.')


def start(game):
    launch.require_closed_server()
    reports = ROOT / 'reports'
    reports.mkdir(exist_ok=True)
    process = subprocess.Popen([sys.executable, str(SERVER / 'local_server.py'), '--push-lists',
        '--class-delivery-probe', '--location-probe', '--no-availability-observation',
        '--log-dir', str(reports)], cwd=str(SERVER), creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:
        ready = verify_ready(wait_ready(CONTROL_PORT, LOGIN_PORT, 30))
    except BaseException:
        if process.poll() is None:
            process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game), instance_id=ready['instance_id'])))
    for mode in ('client', 'controls'):
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--mode', mode],
                         cwd=str(ROOT), creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Use LocalVS, press PLAY, then return to the game view and wait for the HUD.')
    print('Keep these consoles open. Run apply_location_once.cmd when the world view appears.')


def paired_test(game, instance, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    expected = capture.read_input(Path(__file__).resolve().parent)
    files, stage = {}, 'before_capture'
    result = dict(kind='local_location_probe', format_version=1, ok=False,
                  server_instance_id=instance, target=probe.description(), location_packet_queued=False)
    def health():
        return verify_ready(control_request(CONTROL_PORT, LOGIN_PORT, instance=instance), instance)
    try:
        ready = health()
        win.require(not ready['location_probe']['attempted'], 'This experiment was already attempted. Start a fresh run.')
        path, ok = capture.collect(game, output, expected)
        files['before.zip'] = path.read_bytes()
        win.require(ok, 'Before capture failed; no packet sent.')
        with zipfile.ZipFile(path) as archive:
            before = json.loads(archive.read('local-state.json'))
        win.require(before['server_instance_id'] == instance, 'Server instance changed.')
        require_ready_actor(before['native_snapshot'])
        stage = 'request_location'
        health()
        result['location_packet_queued'] = 'unverified'
        reply = control_request(CONTROL_PORT, LOGIN_PORT, 'apply_location_probe', instance=instance, timeout=2)
        result['control_reply'] = reply
        result['location_packet_queued'] = True
        print('Location packet queued. Return to the game; wait while the after capture runs.')
        stage = 'after_capture'
        time.sleep(5)
        path, ok = capture.collect(game, output, expected)
        files['after.zip'] = path.read_bytes()
        result['health_after'] = health()
        win.require(ok, 'After capture failed; upload this report without sending again.')
        win.require(result['health_after']['location_probe']['packets_sent'] == 1,
                    'Server did not record exactly one location send.')
        result['ok'] = True
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        result.update(stage=stage, error_type=type(error).__name__, reason=str(error))
    result.update(game_files_changed=False, native_acceptance_requires_report_review=True,
                  safe_floor_verified=False, equipment_changed=False)
    files['location-probe.json'] = (json.dumps(result, indent=2) + '\n').encode()
    manifest = dict(format='ps2-location-probe-report-v1', files={name:
        dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in files.items()})
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    path = output / ('local-location-' + stamp + '-' + secrets.token_hex(4) + '.zip')
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in files.items():
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(path) as archive:
        win.require(archive.testzip() is None, 'Report ZIP integrity failed')
    return path, result['ok']


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('start', 'client', 'controls', 'apply'), default='start')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and win.ctypes.sizeof(win.ctypes.c_void_p) == 8,
                    'Run this helper with 64-bit Python on Windows.')
        verify_bundle()
        if args.mode == 'start':
            selected = launch.choose_game()
            if not selected:
                return 0
            start(launch.verify_game(selected))
            return 0
        state = json.loads(SESSION.read_text())
        verify_ready(control_request(CONTROL_PORT, LOGIN_PORT), state['instance_id'])
        game = launch.verify_game(state['game_dir'])
        if args.mode == 'client':
            import local_client
            return local_client.main(['--game-dir', str(game), '--log-dir', str(ROOT / 'reports')])
        if args.mode == 'controls':
            import test_controls
            return test_controls.main()
        path, ok = paired_test(game, state['instance_id'], ROOT / 'reports')
        print('Paired capture complete.' if ok else 'Test stopped; upload this report too.')
        print('Upload this ZIP:', path)
        subprocess.Popen(['explorer.exe', str(path.parent)])
        return 0 if ok else 1
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('Location probe stopped:', error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

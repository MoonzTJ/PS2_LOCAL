@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_location_probe.py" --mode start
pause

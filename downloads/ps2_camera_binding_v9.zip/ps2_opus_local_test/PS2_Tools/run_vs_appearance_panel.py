"""Local Test panel with the opt-in, table-inferred VS LA appearance candidate.

Two opt-in changes. (1) Menu rows only: each faction's LA body/head at character
select. (2) Bounded full-byte capture of client zone messages around the bootstrap
placement. (3) Model 165 in the bootstrap activation message's model word (native
9B9320: third scalar -> outer+48 -> B9D0E0), so the actor can build first-person
arms; E70700 attaches the camera to the arms' "camera" bone and detaches otherwise. v1 also put 165/166 in
the class definitions and every character crashed on login, so class data is
back to its original bytes and every frozen guard runs unchanged. The client
uses the panel's clean-UI configuration exactly as before.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT/'PS2_Server'
if not SERVER.is_dir(): SERVER = ROOT
sys.path.insert(0, str(SERVER))
try:
    from scripts import run_local_test as panel
except ModuleNotFoundError:
    import run_local_test as panel
import vs_appearance
from profile_probe import probe_description
from console_common import CONTROL_PORT, LOGIN_PORT, wait_ready, timestamp
import win_reader as win

FORMAT = 'ps2-codex-camera-binding-v9'
ACTIVATION_MODEL_ID = 165  # VS LA male; arms FPArmor_VS_Male_LightAssault.adr
bootstrap = panel.baseline
launch = bootstrap.baseline.prior.baseline.launch
_frozen_verify_ready = bootstrap.verify_ready
_frozen_phase = bootstrap.require_phase
import profile_activation
_frozen_activation_description = profile_activation.description


def verify_bundle(root=ROOT):
    manifest = json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format') == FORMAT and manifest.get('appearance') == vs_appearance.description()
                and manifest.get('class_delivery_probe') == probe_description(),
                'Extract the complete VS appearance Local Test ZIP again')
    for name, pin in manifest['files'].items():
        path = root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size == pin['bytes'] and win.file_sha(path) == pin['sha256'],
                    'VS appearance Local Test files differ; extract the complete ZIP again')


def verify_ready(ready, instance=None, *, fresh=False):
    # Every frozen guard runs unchanged: class definitions keep their original
    # identity-only bytes, so only the menu candidate needs an added check.
    _frozen_verify_ready(ready, instance, fresh=fresh)
    observed = ready.get('vs_la_appearance_candidate', {})
    win.require(all(observed.get(k) == v for k, v in vs_appearance.description().items())
                and isinstance(observed.get('character_list_sha256'), str)
                and 'vs_la_class_models' not in ready
                and ready.get('zone_payload_capture', {}).get('enabled') is True
                and (not fresh or ready['zone_payload_capture'].get('window_open') is False)
                and ready.get('profile_activation_probe', {}).get('candidate_model_id') == ACTIVATION_MODEL_ID,
                'Use Start Opus Local Test.cmd with its separate server.')
    return ready


def start_session(game, *, popen=subprocess.Popen, readiness=wait_ready, closed=None):
    """The frozen panel's session start, plus the candidate flag and this wrapper as client."""
    (closed or launch.require_closed_server)()
    reports = ROOT/'reports'; reports.mkdir(exist_ok=True)
    python = panel.console_python()
    server = popen([python, str(SERVER/'local_server.py'), '--push-lists', '--class-delivery-probe',
        '--vs-test-character', '--starter-loadout-references', '--cosmetic-inventory-probe',
        '--profile-activation-probe', '--profile-placement-probe', '--local-admin', '--vs-la-appearance-candidate', '--zone-payload-capture',
        '--activation-model-id', str(ACTIVATION_MODEL_ID),
        '--character-state-dir', str(SERVER/'state'), '--no-availability-observation', '--log-dir', str(reports)],
        cwd=str(SERVER), creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
    try:
        health = verify_ready(readiness(CONTROL_PORT, LOGIN_PORT, 30), fresh=True)
        win.require(health.get('server_pid') == server.pid, 'The new server process did not answer')
        state = dict(game_dir=str(game), instance_id=health['instance_id'], server_pid=server.pid)
        panel.SESSION.write_text(json.dumps(state)+'\n')
        path = reports/('client-monitor-'+timestamp()+'.txt')
        with path.open('xb') as log:
            client = popen([python, str(Path(__file__).resolve()), '--client'], cwd=str(ROOT),
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                           stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        return state, client, path
    except BaseException:
        if server.poll() is None:
            server.terminate(); server.wait(timeout=5)
        raise


def candidate_activation_description(model_id=ACTIVATION_MODEL_ID):
    return _frozen_activation_description(model_id)


def require_phase(snapshot, phase):
    # The frozen guard expects actor model 0 after activation. The candidate may
    # change it to 165 (or the client may ignore it); either way it is recorded
    # in the saved snapshot and the frozen checks see their original view.
    actor = snapshot.get('actor_initialization', {})
    win.require(actor.get('actor_model_id') in (0, ACTIVATION_MODEL_ID), 'Unexpected actor model after activation')
    _frozen_phase(dict(snapshot, actor_initialization=dict(actor, actor_model_id=0)), phase)


def install_candidate_guards():
    profile_activation.description = candidate_activation_description
    bootstrap.require_phase = require_phase
    bootstrap.verify_ready = verify_ready
    panel.start_session = start_session


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--client', action='store_true')
    parser.add_argument('--camera', action='store_true', help='Sample actor and camera positions (read-only)')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, 'Use 64-bit Python 3.10+ on Windows')
        verify_bundle(); install_candidate_guards()
        if args.camera:
            import camera_capture
            state = json.loads(panel.SESSION.read_text())
            _, result = camera_capture.collect(launch.verify_game(state['game_dir']), ROOT/'reports')
            return 0 if result['ok'] else 1
        return panel.client_main() if args.client else panel.panel()
    except Exception as error:
        message = 'Opus Local Test stopped: '+str(error)
        if os.name == 'nt' and not (args.client or args.camera):
            ctypes.windll.user32.MessageBoxW(None, message, 'MoonSol Opus Local Test', 0x10)
        else: print(message, file=sys.stderr)
        return 1


if __name__ == '__main__': raise SystemExit(main())

# Local Test v9 — camera target and arms attachment check

The previous capture identified a first-person camera while the actor moved and
the view stayed fixed. This version checks whether that camera targets LocalVSTest
and whether its arms attachment is still waiting. It is a read-only diagnostic,
not a camera fix. The tested model-165 activation and startup sequence are unchanged.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Select **LocalVSTest**, press **Play**, and run **Advanced → Existing bootstrap
   diagnostic (once)**. Wait for THREE beeps.
4. Run **Capture Camera.cmd**. Return to the game within five seconds. At TWO
   beeps, hold W and turn with the mouse until THREE beeps.
5. Upload the new `reports/local-camera-….json` and the bootstrap ZIP. Note whether
   the view moved or arms appeared. If it crashes, include the copied game's
   newest Logs files.

The added fields compare the camera target to the verified local actor and record
its cached arms ID and guarded native arms-ID result. Changed identities/signatures
or unstable reads produce unavailable fields instead of guessed values. The capture
performs no native calls, process writes, forced readiness or new gameplay messages.

"""Loopback gateway login and current-format Indar ZoneDetails experiment."""
from __future__ import annotations

import secrets
import time

from handoff import GATEWAY_PORT, GATEWAY_PROTOCOL, character_login_reply
from login import RC4
from gateway_protocol import (GATEWAY_LOGIN_REPLY, normal_packet, parse_gateway_login,
                              tunnel_to_client, zone_details, ZONE_NAME, ZONE_ID)
from local_test import Probe
from player_world import send_self_to_client
from item_definitions import parse_item_definition_request
from world_confirmation import (parse_startup_signal, parse_ready_signal, ZONE_DONE_SENDING_INITIAL_DATA,
                                PRELOAD_DONE)
from zone_backend import IndarZone
from profile_probe import probe_packet, probe_description
import location_probe
from presets import PRESETS
import starter_loadout
import starter_inventory


class GatewayApplication:
    def __init__(self, gateway, peer, request):
        self.gateway = gateway
        self.zone_session_ended = False
        self.owner = (peer, request["session_id"])
        self.authenticated = False
        self.character_guid = None
        self.incoming = self.outgoing = None
        self.initial_data_done_issued = False
        self.preload_done_issued = False
        self.class_probe_issued = False
        self.character_profile_issued = False

    def handle(self, data):
        if len(data) > 1 and data[0] == 0:
            data = data[1:]  # SOE leading-zero escape is outside the cipher.
        encoding = "plain_initial_login"
        if self.authenticated:
            data = self.incoming.transform(data)
            encoding = "rc4_handoff_key"
        data = normal_packet(data)
        if not data:
            raise ValueError("Empty gateway application")
        opcode, channel = data[0] & 31, data[0] >> 5
        if opcode == 1:
            if self.zone_session_ended:
                raise ValueError('Use a new transport and handoff after character logout')
            parsed = parse_gateway_login(data)
            row = self.gateway.validate(parsed, self.owner)
            metadata = dict(name="GatewayLoginRequest", opcode=1, channel=0,
                            character_guid=row["character_guid"], character_name=row["character_name"],
                            ticket_matched=True, descriptor_bytes=len(parsed["descriptor"].encode("utf-8")),
                            build_bytes=len(parsed["build"].encode("utf-8")), application_encoding=encoding,
                            duplicate=self.authenticated)
            if self.authenticated:
                if self.character_guid != row["character_guid"]:
                    raise ValueError("Gateway identity changed within a transport session")
                return metadata, []
            self.authenticated = True
            self.character_guid = row["character_guid"]
            key = self.gateway.materials[parsed["ticket"]]["key"]
            self.incoming, self.outgoing = RC4(key), RC4(key)
            replies = [("GatewayLoginReply", GATEWAY_LOGIN_REPLY)]
            if self.gateway.send_zone_details:
                clock = int(time.monotonic() * 1000)
                packet = zone_details(clock, **self.gateway.zone.wire_fields())
                replies.append(("IndarZoneDetails", tunnel_to_client(packet)))
                metadata.update(backend_zone_data_loaded=True,
                                backend_zone_dataset_sha256=self.gateway.zone.dataset_sha256,
                                selected_zone=self.gateway.zone.name, selected_zone_id=self.gateway.zone.zone_id)
                if self.gateway.send_player_record:
                    starter = self.gateway.starter_states.get(row['character_guid'])
                    repository = self.gateway.character_repository
                    if repository is not None and repository.contains(row['character_guid']):
                        from character_wire import send_self
                        packet = send_self(row,repository,admin=row['character_guid'] in self.gateway.admin_character_guids)
                        record = repository.load(row['character_guid'])
                        metadata['persisted_character_revision'] = record['revision']
                        from character_inventory import description
                        metadata['persistent_inventory'] = description(record,repository.catalog)
                        import character_metadata
                        replies.append(('InitializePersistentItemMetadata',tunnel_to_client(
                            character_metadata.startup_packet(record,repository.catalog))))
                        metadata['persistent_item_metadata'] = character_metadata.description(record,repository.catalog)
                    else:
                        packet = send_self_to_client(row, characters=self.gateway.characters, starter_state=starter,
                            owned_probe=self.gateway.owned_probe_enabled and starter is not None,
                            cosmetic_probe=self.gateway.cosmetic_probe_enabled and starter is not None,
                            **({'admin':True} if row['character_guid'] in self.gateway.admin_character_guids else {}))
                    replies.append(("SendSelfToClient", tunnel_to_client(packet)))
                    if starter is not None:
                        metadata['starter_loadout'] = starter_loadout.description(starter)
            return metadata, replies
        if not self.authenticated:
            raise ValueError("Gateway application arrived before a validated local login")
        if opcode == 6:
            if len(data) < 2:
                raise ValueError("Empty client-to-server zone tunnel")
            if self.gateway.character_repository is not None:
                if channel == 0 and data[1] == 0xc7:
                    from character_logout import handle
                    metadata, reply = handle(data[1:],self.gateway.character_repository,self.character_guid)
                    metadata['duplicate'] = self.zone_session_ended
                    self.zone_session_ended = True
                    return metadata, [('CharacterLogoutReply',tunnel_to_client(reply))]
                if self.zone_session_ended:
                    raise ValueError('Character zone session has ended')
            # Header only. Character/account strings, inventory and keys are not logged.
            metadata = dict(name="ClientZoneTunnel", opcode=6, channel=channel,
                        character_guid=self.character_guid, zone_payload_bytes=len(data)-1,
                        application_encoding=encoding,
                        zone_opcode_prefix_hex=data[1:5].hex())
            capture = getattr(self.gateway, 'zone_capture', None)
            if capture is not None:
                capture.consider(channel, data[1:], metadata)
            item_id = parse_item_definition_request(data[1:]) if channel == 0 else None
            if item_id is not None:
                metadata.update(item_definition_request_observed=True,
                                requested_item_definition_id=item_id,
                                item_definition_reply_implemented=False)
            startup = parse_startup_signal(data[1:]) if channel == 0 else None
            if startup is not None:
                metadata.update(client_startup_signal_observed=True,
                                world_confirmation_duplicate=self.initial_data_done_issued)
                if self.gateway.send_world_confirmation and not self.initial_data_done_issued:
                    self.initial_data_done_issued = True
                    replies = []
                    if self.gateway.class_probe_packet is not None and not self.class_probe_issued:
                        self.class_probe_issued = True
                        metadata['experimental_class_delivery_probe'] = self.gateway.class_probe_description()
                        replies.append(('ExperimentalClassIdentityProbe',
                                        tunnel_to_client(self.gateway.class_probe_packet)))
                    repository = self.gateway.character_repository
                    if repository is not None and repository.contains(self.character_guid):
                        import character_initialization
                        record = repository.load(self.character_guid)
                        packet = character_initialization.profile_packet(record)
                        metadata['persistent_active_profile'] = character_initialization.description(record)
                        self.character_profile_issued = True
                        replies.append(('InitializePersistentCharacterProfile',tunnel_to_client(packet)))
                    replies.append(("ZoneDoneSendingInitialData", tunnel_to_client(ZONE_DONE_SENDING_INITIAL_DATA)))
                    return metadata, replies
            if channel == 0 and parse_ready_signal(data[1:]):
                metadata.update(client_ready_signal_observed=True,
                                client_ready_signal_before_initial_data=not self.initial_data_done_issued,
                                preload_confirmation_duplicate=self.preload_done_issued)
                # State 24 clears the preload flag. The native state-25 entry
                # sends 04 afterward; answering 73 with both packets loses it.
                if (self.gateway.send_world_confirmation and self.initial_data_done_issued
                        and not self.preload_done_issued):
                    self.preload_done_issued = True
                    return metadata, [("PreloadDone", tunnel_to_client(PRELOAD_DONE))]
                claim = getattr(self.gateway, 'claim_post_placement_preload', None)
                if self.preload_done_issued and claim is not None and claim('answered_client_ready'):
                    metadata['post_placement_preload_path'] = 'answered_client_ready'
                    return metadata, [("PostPlacementPreloadDone", tunnel_to_client(PRELOAD_DONE))]
            return metadata, []
        return dict(name="UnhandledGatewayApplication", opcode=opcode,
                    channel=channel, bytes=len(data), application_encoding=encoding), []

    def encrypt_reply(self, data):
        if not self.authenticated or self.outgoing is None:
            raise ValueError("Gateway reply requires a validated local handoff")
        encrypted = self.outgoing.transform(data)
        return b"\0" + encrypted if encrypted.startswith(b"\0") else encrypted


class ZonePayloadCapture:
    """Bounded full-byte samples of client zone messages around one placement.

    The 4-byte prefix log showed the client's 15 Hz 2:02 stream stopping after
    placement, with new 2:fe and 0:02 messages. Bytes are diagnostic samples for
    offline decoding; no meaning is assumed and nothing is replied.
    """
    MAX_BYTES = 256
    # Windows run 214141: the W/mouse movement burst began 21 s after placement,
    # past the first 15 s window. 60 s at the ~15 Hz stream fits the limit.
    LIMITS = dict(window=1500, baseline=30, rare=60)
    AFTER_PLACEMENT = 60.0
    # Seen every session at high rate or carrying bulk data; sampled by prefix only.
    COMMON = {(0, 0x3c), (0, 0x48), (2, 0x00)}

    def __init__(self):
        self.window_opened = self.placed_at = None
        self.counts = dict(window=0, baseline=0, rare=0)
        self.seen = set()

    def consider(self, channel, payload, metadata):
        if not payload:
            return
        key, now = (channel, payload[0]), time.monotonic()
        in_window = (self.window_opened is not None and
                     (self.placed_at is None or now - self.placed_at <= self.AFTER_PLACEMENT))
        if in_window and key not in self.COMMON:
            reason = 'window'
        elif key == (2, 0x02) and self.window_opened is None:
            reason = 'baseline'
        elif key not in self.seen and key not in self.COMMON:
            reason = 'rare'
        else:
            reason = None
        self.seen.add(key)
        if reason is None or self.counts[reason] >= self.LIMITS[reason]:
            return
        self.counts[reason] += 1
        metadata.update(payload_hex=payload[:self.MAX_BYTES].hex(), payload_truncated=len(payload) > self.MAX_BYTES,
                        capture_reason=reason, seconds_after_placement=(round(now-self.placed_at, 3)
                                                                         if self.placed_at is not None else None))

    def status(self):
        return dict(enabled=True, version='zone-payload-capture-v2', max_bytes=self.MAX_BYTES,
                    limits=dict(self.LIMITS), captured=dict(self.counts),
                    window_open=self.window_opened is not None, placed=self.placed_at is not None)


class Gateway(Probe):
    def __init__(self, path, parent_event, port=GATEWAY_PORT, send_zone_details=True,
                 send_player_record=True, send_world_confirmation=True, zone=None,
                 class_delivery_probe=False, location_delivery_probe=False, characters=PRESETS,
                 starter_states=(), owned_inventory_probe=False, cosmetic_inventory_probe=False,
                 profile_activation_probe=False, profile_placement_probe=False, admin_character_guids=(),
                 character_repository=None, class_model_pairs=None, post_placement_preload=False,
                 zone_payload_capture=False, activation_model_id=None):
        if character_repository is not None and not class_delivery_probe:
            raise ValueError('Persistent profile startup requires class-definition delivery')
        if character_repository is not None and (starter_states or owned_inventory_probe or cosmetic_inventory_probe
                or profile_activation_probe or profile_placement_probe or location_delivery_probe):
            raise ValueError('Persistent characters require a separate run from immutable probe states')
        self.character_repository = character_repository
        configured={row['character_id'] for row in characters}
        if (any(type(guid) is not int or guid not in configured for guid in admin_character_guids)
                or len(set(admin_character_guids))!=len(admin_character_guids)):
            raise ValueError('Local admin grants require distinct configured character identities')
        self.admin_character_guids=frozenset(admin_character_guids)
        if owned_inventory_probe and cosmetic_inventory_probe:
            raise ValueError('Use a separate run for cosmetic and original ownership probes')
        if profile_activation_probe and (not cosmetic_inventory_probe or not class_delivery_probe
                                         or location_delivery_probe):
            raise ValueError('Profile activation requires the isolated cosmetic/class starter mode')
        self.profile_activation_enabled = profile_activation_probe
        if activation_model_id is not None and not profile_activation_probe:
            raise ValueError('An activation model candidate requires the profile activation probe')
        self.activation_model = {} if activation_model_id is None else {'model_id': activation_model_id}
        self.profile_activation_attempted = False
        self.profile_activation_sent = 0
        if profile_placement_probe and not profile_activation_probe:
            raise ValueError('Profile placement requires the isolated profile activation mode')
        self.profile_placement_enabled = profile_placement_probe
        if post_placement_preload and not profile_placement_probe:
            raise ValueError('Post-placement PreloadDone requires the profile placement probe')
        # Opt-in experiment: every Windows placement left the observed PreloadDone
        # flag false with input locked. After the one placement, answer one ready
        # 04 with the existing PreloadDone bytes, or send them once unsolicited if
        # no 04 arrives within the delay. The path taken is recorded.
        self.post_placement_preload = dict(enabled=True, armed_at=None, path=None, sent=0) if post_placement_preload else None
        if zone_payload_capture and not profile_placement_probe:
            raise ValueError('Zone payload capture requires the profile placement probe')
        self.zone_capture = ZonePayloadCapture() if zone_payload_capture else None
        self.profile_placement_attempted = False
        self.profile_placement_sent = 0
        self.cosmetic_probe_enabled = cosmetic_inventory_probe
        self.inventory_provider = starter_inventory
        if cosmetic_inventory_probe:
            import cosmetic_inventory
            self.inventory_provider = cosmetic_inventory
        owned_inventory_probe = owned_inventory_probe or cosmetic_inventory_probe
        self.characters = characters
        self.starter_states = {}
        if starter_states and (not class_delivery_probe or location_delivery_probe):
            raise ValueError('Starter loadouts require class delivery and a separate run from location probe')
        for starter in starter_states:
            identity = starter['identity']
            if identity not in characters or identity['character_id'] in self.starter_states:
                raise ValueError('Starter loadout requires a distinct configured character')
            starter_loadout.encode(starter)
            self.starter_states[identity['character_id']] = starter
        if owned_inventory_probe and set(self.starter_states) != {starter_inventory.state()['character_guid']}:
            raise ValueError('Ownership probe requires only the isolated starter character')
        if profile_activation_probe:
            import profile_activation
            target = profile_activation.description()['target_character_guid']
            if (set(self.starter_states) != {target}
                    or self.starter_states[target]['selected_class']['profile_id'] != profile_activation.PROFILE_ID):
                raise ValueError('Profile activation requires the exact LocalVSTest starter profile')
        self.owned_probe_enabled = owned_inventory_probe
        self.owned_probe_attempted = False
        self.owned_probe_sent = 0
        if location_delivery_probe and not class_delivery_probe:
            raise ValueError('The location probe requires the class delivery probe')
        if class_delivery_probe and not (send_zone_details and send_player_record and send_world_confirmation):
            raise ValueError('The class delivery probe requires the normal V31.2 initialization flow')
        if class_model_pairs and not class_delivery_probe:
            raise ValueError('Class model candidates require class-definition delivery')
        self.class_model_pairs = dict(class_model_pairs or {})
        # Keyword only when used: older frozen helper bundles ship the original profile_probe.
        candidate = {'model_pairs': self.class_model_pairs} if self.class_model_pairs else {}
        self.class_probe_packet = probe_packet(**candidate) if class_delivery_probe else None
        self.class_probe_sent = 0
        self.zone = zone if zone is not None else IndarZone()
        self.location_probe_enabled = location_delivery_probe
        self.location_probe_attempted = False
        self.location_probe_sent = 0
        if location_delivery_probe or profile_placement_probe:
            location_probe.require_anchor(self.zone.scene)
        self.parent_event = parent_event
        self.handoffs_issued = 0
        self.last_material = None
        self.materials = {}
        self.send_zone_details = send_zone_details
        self.send_player_record = bool(send_player_record and send_zone_details)
        self.send_world_confirmation = bool(send_world_confirmation and self.send_player_record)
        self.initial_data_done_sent = self.preload_done_sent = 0
        self.player_records_sent = 0
        self.character_profiles_sent = 0
        self.login_replies_sent = self.zone_details_sent = self.zone_tunnels = 0
        super().__init__(path, port=port, allowed_protocol=GATEWAY_PROTOCOL,
                         application_factory=lambda peer, request: GatewayApplication(self, peer, request),
                         characters=characters,**({'character_repository':character_repository} if character_repository is not None else {}))
        self.event("gateway_ready", host=self.address[0], port=self.address[1],
                   protocol=GATEWAY_PROTOCOL, application_login_implemented=True,
                   application_reply_encoding="rc4_handoff_key",
                   indar_zone_details_enabled=send_zone_details,
                   synthetic_player_record_enabled=self.send_player_record,
                   world_confirmation_enabled=self.send_world_confirmation,
                   playable_world_implemented=False)

    def event(self, event, **fields):
        super().event(event, **fields)
        if event == "candidate_reply_sent":
            if fields.get("name") == "GatewayLoginReply":
                self.login_replies_sent += 1
            elif fields.get("name") == "IndarZoneDetails":
                self.zone_details_sent += 1
            elif fields.get("name") == "SendSelfToClient":
                self.player_records_sent += 1
            elif fields.get('name') == 'InitializePersistentCharacterProfile':
                self.character_profiles_sent += 1
            elif fields.get("name") == "ZoneDoneSendingInitialData":
                self.initial_data_done_sent += 1
            elif fields.get("name") == "PreloadDone":
                self.preload_done_sent += 1
            elif fields.get('name') == 'ExperimentalClassIdentityProbe':
                self.class_probe_sent += 1
            elif fields.get('name') == 'ExperimentalUpdateLocation':
                self.location_probe_sent += 1
            elif fields.get('name') == 'ExperimentalAddOwnedItems':
                self.owned_probe_sent += 1
            elif fields.get('name') == 'ExperimentalActivateProfile':
                self.profile_activation_sent += 1
            elif fields.get('name') == 'ExperimentalProfilePlacement':
                self.profile_placement_sent += 1
        elif event == "application_packet_decoded" and fields.get("name") == "ClientZoneTunnel":
            self.zone_tunnels += 1
        if event in ("session_request", "session_response_sent", "application_data",
                     "request_rejected", "transport_rejected", "client_disconnect",
                     "application_packet_decoded", "application_data_rejected", "candidate_reply_sent"):
            self.parent_event("gateway_" + event, **fields)

    def class_probe_description(self):
        if self.class_model_pairs:
            return probe_description(self.class_probe_packet, self.class_model_pairs)
        return probe_description(self.class_probe_packet)

    def trim_materials(self):
        now = time.monotonic()
        self.materials = {ticket: row for ticket, row in self.materials.items() if now-row["issued"] < 900}

    def issue(self, selection):
        self.trim_materials()
        if len(self.materials) >= 32:
            self.materials.pop(next(iter(self.materials)))
        ticket = "Moon_local_" + secrets.token_urlsafe(24)
        key = secrets.token_bytes(16)
        reply = character_login_reply(selection, self.address[1], ticket, key, characters=self.characters)
        self.handoffs_issued += 1
        self.last_material = (dict(selection), ticket, key)
        self.materials[ticket] = dict(selection=dict(selection), key=key, issued=time.monotonic(), owner=None)
        self.event("handoff_issued", character_guid=selection["character_guid"],
                   character_name=selection["character_name"], server_id=selection["server_id"],
                   gateway_port=self.address[1], key_bytes=len(key), synthetic_local_identity=True)
        return reply

    def validate(self, parsed, owner):
        self.trim_materials()
        record = self.materials.get(parsed["ticket"])
        if record is None or record["selection"]["character_guid"] != parsed["character_guid"]:
            raise ValueError("Gateway identity or ticket does not match a current local handoff")
        if record["owner"] is not None and record["owner"] != owner:
            raise ValueError("Gateway ticket is already bound to another transport session")
        record["owner"] = owner
        return record["selection"]

    def gateway_status(self):
        authenticated = sum(bool(state.get("application") and state["application"].authenticated)
                            for state in self.peers.values())
        status = dict(transport_ready=True, host=self.address[0], port=self.address[1],
                    expected_protocol=GATEWAY_PROTOCOL, handoffs_issued=self.handoffs_issued,
                    session_requests=self.requests, session_responses_sent=self.responses,
                    application_buffers=self.messages, acknowledgments_sent=self.acks,
                    crc_failures=self.crc_failures, active_transport_peers=len(self.peers),
                    active_authenticated_peers=authenticated, application_login_implemented=True,
                    application_reply_encoding="rc4_handoff_key",
                    local_login_replies_sent=self.login_replies_sent,
                    native_gateway_login_acceptance="unverified",
                    indar_zone_details_enabled=self.send_zone_details,
                    zone_details_sent=self.zone_details_sent, client_zone_tunnels=self.zone_tunnels,
                    synthetic_player_record_enabled=self.send_player_record,
                    player_records_sent=self.player_records_sent,
                    world_confirmation_enabled=self.send_world_confirmation,
                    initial_data_done_sent=self.initial_data_done_sent,
                    preload_done_sent=self.preload_done_sent,
                    native_world_confirmation_acceptance="unverified",
                    native_player_record_acceptance="unverified",
                    class_delivery_probe=dict(enabled=self.class_probe_packet is not None,
                        packets_sent=self.class_probe_sent,
                        **(self.class_probe_description() if self.class_probe_packet is not None else {})),
                    requested_zone=ZONE_NAME, requested_zone_id=ZONE_ID,
                    backend_zone_data=self.zone.status(),
                    zone_loaded=False, world_loading_implemented=False)
        if self.character_repository is not None:
            status['persistent_active_profile'] = dict(enabled=True,packets_sent=self.character_profiles_sent,
                profile_id=19,delivery='after_class_definitions_before_initial_data_done',
                windows_startup_order_verified=False,playable_character_verified=False)
        return status

    def location_probe_status(self):
        return dict(enabled=self.location_probe_enabled, attempted=self.location_probe_attempted,
                    packets_sent=self.location_probe_sent,
                    **(location_probe.description() if self.location_probe_enabled else {}))

    def owned_probe_status(self):
        return dict(**self.inventory_provider.description(), attempted=self.owned_probe_attempted,
                    packets_sent=self.owned_probe_sent)

    def profile_activation_status(self):
        if not self.profile_activation_enabled:
            return dict(enabled=False)
        import profile_activation
        return dict(profile_activation.description(**self.activation_model), attempted=self.profile_activation_attempted,
                    packets_sent=self.profile_activation_sent)

    def request_profile_activation(self):
        if not self.profile_activation_enabled or self.profile_activation_attempted:
            return dict(ok=False, message='Profile activation is disabled or already attempted.')
        if self.owned_probe_attempted or self.owned_probe_sent:
            return dict(ok=False, message='Use a fresh profile activation run without item delivery.')
        import profile_activation
        peers = [(peer,state) for peer,state in self.peers.items()
                 if state.get('application') and state['application'].authenticated]
        if len(peers) != 1:
            return dict(ok=False, message='Exactly one authenticated local client is required.')
        peer,state = peers[0]
        app = state['application']
        if (app.character_guid != profile_activation.description()['target_character_guid']
                or not app.class_probe_issued or not app.preload_done_issued or state['sender'].pending):
            return dict(ok=False, message='Wait for LocalVSTest initialization and reliable replies to finish.')
        # Consume before sending; only the reliable transport retries wire data.
        self.profile_activation_attempted = True
        try:
            self.send_candidate(peer,state,'ExperimentalActivateProfile',
                                tunnel_to_client(profile_activation.activation_packet(**self.activation_model)))
        except OSError:
            return dict(ok=False, message='Profile activation send failed; start a fresh experiment.')
        self.event('profile_activation_queued',**profile_activation.description(**self.activation_model))
        if self.zone_capture is not None:
            self.zone_capture.window_opened = time.monotonic()
        return dict(ok=True,profile_activation_probe=self.profile_activation_status(),
                    native_acceptance_verified=False)

    POST_PLACEMENT_PRELOAD_DELAY = 5.0

    def claim_post_placement_preload(self, path):
        state = self.post_placement_preload
        if state is None or state['armed_at'] is None or state['path'] is not None:
            return False
        state.update(path=path, sent=1)
        self.event('post_placement_preload', path=path,
                   seconds_after_placement=round(time.monotonic()-state['armed_at'], 3))
        return True

    def post_placement_preload_status(self):
        state = self.post_placement_preload
        if state is None:
            return dict(enabled=False)
        return dict(enabled=True, version='post-placement-preload-v1', delay_seconds=self.POST_PLACEMENT_PRELOAD_DELAY,
                    armed=state['armed_at'] is not None, path=state['path'], packets_sent=state['sent'],
                    packet_hex=PRELOAD_DONE.hex(), native_effect_verified=False)

    def tick(self):
        super().tick()
        state = self.post_placement_preload
        if (state is None or state['armed_at'] is None or state['path'] is not None
                or time.monotonic()-state['armed_at'] < self.POST_PLACEMENT_PRELOAD_DELAY):
            return
        peers = [(peer, row) for peer, row in self.peers.items()
                 if row.get('application') and row['application'].authenticated]
        if len(peers) == 1 and self.claim_post_placement_preload('unsolicited_after_delay'):
            self.send_candidate(*peers[0], 'PostPlacementPreloadDone', tunnel_to_client(PRELOAD_DONE))

    def profile_placement_status(self):
        if not self.profile_placement_enabled:
            return dict(enabled=False)
        import profile_placement
        return dict(profile_placement.description(), attempted=self.profile_placement_attempted,
                    packets_sent=self.profile_placement_sent)

    def request_profile_placement(self):
        if not self.profile_placement_enabled or self.profile_placement_attempted:
            return dict(ok=False, message='Profile placement is disabled or already attempted.')
        if (not self.profile_activation_attempted or self.profile_activation_sent != 1
                or self.owned_probe_attempted or self.owned_probe_sent):
            return dict(ok=False, message='One successful profile activation and no item delivery are required.')
        import profile_placement
        peers = [(peer, state) for peer, state in self.peers.items()
                 if state.get('application') and state['application'].authenticated]
        if len(peers) != 1:
            return dict(ok=False, message='Exactly one authenticated local client is required.')
        peer, state = peers[0]
        app = state['application']
        if (app.character_guid != profile_placement.description()['character_guid']
                or not app.class_probe_issued or not app.preload_done_issued or state['sender'].pending):
            return dict(ok=False, message='Wait for LocalVSTest initialization and reliable replies to finish.')
        self.profile_placement_attempted = True
        try:
            self.send_candidate(peer, state, 'ExperimentalProfilePlacement',
                                tunnel_to_client(location_probe.location_packet()))
        except OSError:
            return dict(ok=False, message='Placement send failed; upload the report and use a fresh run.')
        self.event('profile_placement_queued', **profile_placement.description())
        if self.zone_capture is not None:
            self.zone_capture.placed_at = time.monotonic()
        if self.post_placement_preload is not None:
            self.post_placement_preload['armed_at'] = time.monotonic()
        return dict(ok=True, profile_placement_probe=self.profile_placement_status(),
                    native_acceptance_verified=False)

    def request_owned_probe(self):
        if self.profile_activation_enabled:
            return dict(ok=False, message='Item delivery is disabled in the profile activation experiment.')
        if not self.owned_probe_enabled or self.owned_probe_attempted:
            return dict(ok=False, message='Ownership experiment is disabled or already attempted.')
        peers = [(peer, state) for peer, state in self.peers.items()
                 if state.get('application') and state['application'].authenticated]
        if len(peers) != 1:
            return dict(ok=False, message='Exactly one authenticated local client is required.')
        peer, state = peers[0]
        app = state['application']
        if (app.character_guid != self.inventory_provider.state()['character_guid'] or not app.class_probe_issued
                or not app.preload_done_issued or state['sender'].pending):
            return dict(ok=False, message='Wait for LocalVSTest initialization and reliable replies to finish.')
        self.owned_probe_attempted = True
        try:
            self.send_candidate(peer, state, 'ExperimentalAddOwnedItems',
                                tunnel_to_client(self.inventory_provider.add_packet()))
        except OSError:
            return dict(ok=False, message='Ownership send failed; start a fresh experiment.')
        self.event('owned_probe_queued', **self.inventory_provider.description())
        return dict(ok=True, owned_inventory_probe=self.owned_probe_status(),
                    native_acceptance_verified=False)

    def request_location_probe(self):
        if not self.location_probe_enabled or self.location_probe_attempted:
            return dict(ok=False, message='Location experiment is disabled or already attempted.')
        peers = [(peer, state) for peer, state in self.peers.items()
                 if state.get('application') and state['application'].authenticated]
        if len(peers) != 1:
            return dict(ok=False, message='Exactly one authenticated local client is required.')
        peer, state = peers[0]
        app = state['application']
        if (app.character_guid != location_probe.LOCAL_VS_GUID or not app.class_probe_issued
                or not app.preload_done_issued or state['sender'].pending):
            return dict(ok=False, message='Wait for LocalVS initialization and reliable replies to finish.')
        # Consume before sending: a partial OS send must never cause a second
        # application packet. The existing reliable sender owns wire retries.
        self.location_probe_attempted = True
        try:
            self.send_candidate(peer, state, 'ExperimentalUpdateLocation',
                                tunnel_to_client(location_probe.location_packet()))
        except OSError:
            return dict(ok=False, message='Location send failed; restart the experiment before retrying.')
        self.event('location_probe_queued', **location_probe.description())
        return dict(ok=True, message='One location packet queued; native acceptance needs the after capture.',
                    location_probe=self.location_probe_status(), native_acceptance_verified=False)

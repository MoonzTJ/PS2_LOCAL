@echo off
cd /d "%~dp0"
py -3 collect_weapon_resources.py
echo.
pause

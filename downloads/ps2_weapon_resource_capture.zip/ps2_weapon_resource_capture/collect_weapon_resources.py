"""Read verified local PACK2 indexes and selected weapon/ability tables from disk.

No game-process access, network requests, game launches or game changes.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import secrets
import struct
import subprocess
import tempfile
import zipfile
import zlib

import collect_profile_resources as packs
from capture_client_build import prepare_uploads

# Literal filenames from the matching loaded .rdata, not invented field mappings.
TABLE_NAMES=(
    'WeaponMounts.txt','FireModeDisplayStats.txt','FireModeEffectGroups.txt',
    'ProjectileDisplayStats.txt','Projectiles.txt','AbilityDefinitions.txt',
    'AbilityEx.txt','AbilityClasses.txt','AbilitySets.txt','AbilityLines.txt',
    'AbilityLineMembers.txt','ProfileAbilityLines.txt','ProfileSkillSets.txt',
    'ProfileTypes.txt','ItemClasses.txt','ItemClassSets.txt','Requirements.txt',
    'RequirementExpressions.txt','Skills.txt','SkillLines.txt','SkillSets.txt',
    'SkillCategories.txt','FactionSkillSets.txt','FactionAbilityLines.txt',
    'ZoneFactionAbilityLines.txt',
)
MAX_PACKS=512
MAX_INDEX_BYTES=64*1024*1024
MAX_TABLE_BYTES=32*1024*1024
MAX_ARCHIVE_BYTES=100*1024*1024
EXPECTED_PACKS={row['name']:row for row in json.loads(
    Path(__file__).with_name('weapon_pack_indexes.json').read_text())['packs']}


def choose_game_folder():
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        selected=input('Paste the copied PlanetSide 2 Local folder path: ').strip().strip('"')
    else:
        try:root=tk.Tk()
        except tk.TclError:
            selected=input('Paste the copied PlanetSide 2 Local folder path: ').strip().strip('"')
        else:
            root.withdraw()
            try:
                selected=filedialog.askdirectory(title='Choose the copied PlanetSide 2 Local game folder',
                    initialdir=str(packs.DEFAULT_GAME) if packs.DEFAULT_GAME.is_dir() else None,mustexist=True)
            finally:root.destroy()
    if not selected:raise ValueError('No copied local game folder was selected')
    return Path(selected)


def sha(data):return hashlib.sha256(data).hexdigest()


def capture(game_dir,output_root):
    output_root=Path(output_root).resolve();output_root.mkdir(parents=True,exist_ok=True)
    report=dict(format='ps2-local-weapon-resources-v1',captured_at_utc=datetime.now(timezone.utc).isoformat(),
        expected_client_sha256=packs.EXPECTED_CLIENT,client_sha256=None,capture_complete=False,
        anchor_tables_verified=False,matching_pack_indexes_verified=False,
        index_entry_layout='<QQQII',requested_tables=list(TABLE_NAMES),
        packs=[],tables=[],missing_candidate_tables=[],process_access_performed=False,
        network_access_performed=False,game_or_backend_files_modified=False,
        account_or_character_data_exported=False,complete_class_values_verified=False,
        complete_weapon_values_verified=False,successful_native_assets_verified=False)
    stage='folder_selection'
    with tempfile.TemporaryDirectory(prefix='weapon-resources-',dir=output_root) as folder:
        staging=Path(folder);data_zip=staging/'resources.zip'
        try:
            game_dir=Path(game_dir) if game_dir is not None else choose_game_folder()
            stage='executable_hash';client=game_dir/'PlanetSide2_x64.exe'
            report['client_sha256']=packs.file_sha256(client)
            if report['client_sha256']!=packs.EXPECTED_CLIENT:
                raise ValueError('Selected executable differs from the verified local build; no packs were read')
            stage='pack_discovery'
            paths=sorted((game_dir/'Resources/Assets').glob('*.pack2'),key=lambda p:p.name.casefold())
            if not 0<len(paths)<=MAX_PACKS:raise ValueError('No pack files found or pack count exceeds the capture limit')
            if len({p.name.casefold() for p in paths})!=len(paths):raise ValueError('Duplicate pack filenames')
            if {p.name for p in paths}!=set(EXPECTED_PACKS):
                raise ValueError('Pack filenames differ from the matching saved asset set')
            wanted={packs.name_hash(packs.safe_name(n)):n for n in set(TABLE_NAMES)|set(packs.ANCHORS)}
            if len(wanted)!=len(set(TABLE_NAMES)|set(packs.ANCHORS)):raise ValueError('Requested resource names collide')
            found={};members={};index_total=0;table_total=0
            with zipfile.ZipFile(data_zip,'x',compression=zipfile.ZIP_DEFLATED) as archive:
                for index,path in enumerate(paths):
                    print(f'Reading pack index {index+1}/{len(paths)}: {path.name}',flush=True)
                    packs.safe_name(path.name)
                    stage='pack_index';entries,record=packs.read_index(path)
                    if any(record[k]!=EXPECTED_PACKS[path.name][k] for k in ('name','bytes','entries','index_sha256')):
                        raise ValueError('A pack index differs from the matching saved asset set')
                    raw=b''.join(struct.pack('<QQQII',key,*entry) for key,entry in entries.items())
                    if sha(raw)!=record['index_sha256']:raise ValueError('Pack index reconstruction differs')
                    index_total+=len(raw)
                    if index_total>MAX_INDEX_BYTES:raise ValueError('Combined pack indexes exceed the capture limit')
                    member='pack-indexes/'+path.name+'.index.bin'
                    archive.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=sha(raw))
                    record.update(index_file=member,index_bytes=len(raw),index_offset=record['bytes']-len(raw))
                    report['packs'].append(record)
                    for key in sorted(wanted.keys()&entries.keys()):
                        stage='resource_integrity';name=wanted[key]
                        data=packs.read_resource(path,key,entries[key]);digest=sha(data)
                        if name in found:
                            if found[name]['sha256']!=digest:raise ValueError('Different versions of a requested table were found')
                            found[name]['source_packs'].append(path.name);continue
                        # Recheck payloads as well as the index; no table interpretation
                        # or claimed mapping to server reference fields occurs here.
                        if packs.read_resource(path,key,entries[key])!=data:raise ValueError('Resource changed during capture')
                        found[name]=dict(name=name,bytes=len(data),sha256=digest,asset_hash=f'{key:016x}',
                                         source_packs=[path.name],stored_crc_verified=True,second_read_matches=True)
                        if name in TABLE_NAMES:
                            table_total+=len(data)
                            if table_total>MAX_TABLE_BYTES:raise ValueError('Selected tables exceed the capture limit')
                            member='tables/'+name;archive.writestr(member,data)
                            members[member]=dict(bytes=len(data),sha256=digest)
                stage='anchor_tables'
                for name,expected in packs.ANCHORS.items():
                    if name not in found or found[name]['sha256']!=expected:
                        raise ValueError('Matching anchor tables are missing or different')
                report['anchor_tables_verified']=True;report['matching_pack_indexes_verified']=True
                stage='final_pack_indexes'
                for path,record in zip(paths,report['packs']):
                    _,final=packs.read_index(path)
                    if any(final[k]!=record[k] for k in ('name','bytes','entries','index_sha256')):
                        raise ValueError('A pack index changed during capture')
                stage='final_executable_hash'
                if packs.file_sha256(client)!=packs.EXPECTED_CLIENT:raise ValueError('Executable changed during capture')
                report.update(tables=[found[n] for n in sorted(TABLE_NAMES) if n in found],
                              missing_candidate_tables=sorted(set(TABLE_NAMES)-found.keys()),
                              anchors={n:found[n] for n in packs.ANCHORS},
                              index_bytes=index_total,table_bytes=table_total,capture_complete=True)
                payload=(json.dumps(report,indent=2)+'\n').encode();archive.writestr('capture.json',payload)
                members['capture.json']=dict(bytes=len(payload),sha256=sha(payload))
                archive.writestr('manifest.json',json.dumps(dict(format=report['format'],capture_complete=True,files=members),indent=2)+'\n')
        except (OSError,ValueError,EOFError,zlib.error,zipfile.BadZipFile) as error:
            report.update(capture_complete=False,error_stage=stage,
                          error=str(error) if isinstance(error,ValueError) else type(error).__name__)
            code=getattr(error,'winerror',None) or getattr(error,'errno',None)
            if type(code) is int:report['os_error_code']=code
            # Do not upload any partly collected indexes or resources on failure.
            data_zip.unlink(missing_ok=True)
            payload=(json.dumps(report,indent=2)+'\n').encode()
            with zipfile.ZipFile(data_zip,'x',compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('capture.json',payload)
                archive.writestr('manifest.json',json.dumps(dict(format=report['format'],capture_complete=False,
                    files={'capture.json':dict(bytes=len(payload),sha256=sha(payload))}),indent=2)+'\n')
        stage='archive_integrity'
        if data_zip.stat().st_size>MAX_ARCHIVE_BYTES:raise ValueError('Capture archive exceeds its upload limit')
        with zipfile.ZipFile(data_zip) as archive:
            if archive.testzip() is not None:raise ValueError('Capture ZIP failed its integrity check')
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        target=output_root/f'local-weapon-resources-{stamp}-{secrets.token_hex(4)}.zip'
        data_zip.replace(target)
    return prepare_uploads(target),report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir',type=Path)
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'reports')
    args=parser.parse_args(argv)
    print('Reading copied local game assets from disk. Choose your PlanetSide 2 Local folder.')
    try:uploads,report=capture(args.game_dir,args.output_dir)
    except (OSError,ValueError,zipfile.BadZipFile) as error:
        print('Capture stopped: '+(str(error) if isinstance(error,ValueError) else type(error).__name__));return 1
    if report['capture_complete']:print(f'Collected {len(report["tables"])} candidate tables and {len(report["packs"])} pack indexes.')
    else:print('Capture stopped at '+report['error_stage']+': '+report['error'])
    print('Upload every file INSIDE this folder separately:');print(uploads)
    print('If parts were created, include every .part file and manifest.json. Upload the small ZIP on failure.')
    try:subprocess.Popen(['explorer.exe',str(uploads)])
    except OSError:pass
    return 0 if report['capture_complete'] else 1


if __name__=='__main__':raise SystemExit(main())

"""Isolated current-build VS profile activation, preserving the observed model0.

The active-profile record is distinct from saved/current loadout records. Its
102-byte minimal layout and the138-byte envelope execute in the matching native
reader/dispatcher. Other profile data remains incomplete constructor defaults.
"""
import hashlib
import struct
from presets import VS_TEST_PRESET

VERSION = 'vs-profile-activation-probe-v1'
PROFILE_ID = 19
PRESERVED_MODEL_ID = 0
# Native 9B9320 outer reader (matching sections, marker packet 11111111/22222222/
# 33333333/44444444): the third raw scalar after the attachments count lands in
# outer+48, the model ID passed to B9D0E0 -> engine+B098 lookup -> actor
# virtual+530 (first-person arms path); the first lands in +44 (component key).
MODEL_WORD_OFFSET = 3 + 4 + 102 + 4 + 8


def profile_body():
    body = bytearray(102)
    # Native98A3D0: first word -> active-profile+4 -> BDFB70 actor+7D8.
    struct.pack_into('<I', body, 0, PROFILE_ID)
    # BA4F20's actual constructor default at+84; wire cursor57.
    struct.pack_into('<I', body, 57, 0x3EB33333)
    return bytes(body)


def attachment_entry(model_name, slot_key):
    """One attachment-array element (native 986E20 reader, 0x170-byte entry).

    Four u32-length strings then four u32 words. BE8BC0 keys the actor's
    attachment map by the third word (+168) and copies the first three
    strings and every word. Only model_name and slot_key carry data here; the
    other strings and words stay empty/zero because their meaning is not traced.
    """
    name = model_name.encode('ascii')
    strings = struct.pack('<I', len(name))+name+bytes(4*3)
    return strings+struct.pack('<IIII', 0, 0, slot_key, 0)


def activation_packet(model_id=PRESERVED_MODEL_ID, attachments=()):
    body = profile_body()
    entries = b''.join(attachment_entry(*row) for row in attachments)
    # 11/u16(15hex), counted active profile, attachment array, four raw
    # scalars (the third is the model ID), two empty strings, final bool.
    packet = bytearray(b'\x11\x15\0'+struct.pack('<I',len(body))+body+struct.pack('<I', len(attachments))
                       +entries+bytes(16+8+1))
    struct.pack_into('<I', packet, MODEL_WORD_OFFSET+len(entries), model_id)
    return bytes(packet)


def description(model_id=PRESERVED_MODEL_ID, attachments=()):
    packet = activation_packet(model_id, attachments)
    entries = sum(len(attachment_entry(*row)) for row in attachments)
    extra = dict(candidate_model_id=model_id, model_word_offset=MODEL_WORD_OFFSET+entries) if model_id != PRESERVED_MODEL_ID else {}
    if attachments:
        extra['attachment_candidates'] = [dict(model_name=name, slot_key=key) for name, key in attachments]
        extra['attachment_semantics_verified'] = False
    return dict(version=VERSION, enabled=True, target_character_guid=VS_TEST_PRESET['character_id'],
                profile_id=PROFILE_ID, preserved_model_id=PRESERVED_MODEL_ID, **extra,
                profile_body_bytes=len(profile_body()), profile_body_sha256=hashlib.sha256(profile_body()).hexdigest(),
                packet_bytes=len(packet), packet_sha256=hashlib.sha256(packet).hexdigest(),
                model_mapping_assigned=False, incremental_items_sent=False,
                complete_profile_data=False, appearance_verified=False, playable_character_verified=False)

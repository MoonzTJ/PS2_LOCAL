"""Opt-in attachment-array candidates for the VS LA profile activation.

The activation's attachment array is read by native 986E20 (four strings, four
u32 words per 0x170-byte entry) and applied by BE8BC0, which keys the actor's
attachment map by the third word. H1Z1's server (same engine lineage, used only
as a reference) fills this array with armour/gear models keyed by slot. The
model names and slot IDs here are the pinned VS starter armour/helmet rows that
cosmetic_inventory validates against the client's own tables; the client's
template text (<gender>) is sent unchanged. Slot-ID-as-key, the other strings
and words, and any rendering effect are unverified.
"""
import cosmetic_inventory

VERSION = 'vs-activation-attachments-candidate-v1'


def starter_attachments():
    cosmetic_inventory._state_bytes()  # raises unless the pinned catalog rows still match
    return tuple((cosmetic_inventory.MODELS[item], slot) for slot, item, _ in cosmetic_inventory.ITEMS)

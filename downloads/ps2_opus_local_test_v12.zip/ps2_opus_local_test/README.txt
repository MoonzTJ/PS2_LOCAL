# Opus Local Test v12 — activation with armour/helmet attachments

v10.2 and v11 built the VS LA arms after the placement, but the camera never
attached: the actor's arms ready bit stayed clear for the whole 90-second
watch. H1Z1's open-source server (same engine family, used only as a
reference) sends the profile activation with an attachment array of armour and
gear models; we have always sent it empty.

v12 keeps everything from v11 and fills that array with two entries: the VS
starter armour and helmet from the client's own tables
(`Armor_VS_<gender>_LightAssault_Look001.adr` in slot 10 and
`Helmet_VS_<gender>_LightAssault_Look001.adr` in slot 11). The entry layout was
checked in the client's own activation reader. The names are sent exactly as the
client's tables write them; whether the client fills in `<gender>` itself is
one of the things this run shows.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Run **Watch Arms.cmd** and leave its window open.
4. Select **LocalVSTest** and press **Play**. You move to the warpgate after
   about 5 seconds; the body and attachments arrive about 8 seconds later.
   Look around and walk until Watch Arms gives three beeps.
5. Optionally run **Capture Camera.cmd** afterwards (hold W and turn between
   the beeps).
6. Note whether the armour or helmet looks different, whether arms appear and
   whether the view follows the mouse. Then upload the new `reports` files and
   the copied game's `Logs/FirstPersonArms.log` and `Logs/FailedLoadAssets.log`.
   If it crashes, include the newest Logs files.

No bootstrap button is needed; do not use Advanced → Existing bootstrap
diagnostic. Reports show what was sent and read, not that anything rendered;
that needs your view of the game plus the logs.

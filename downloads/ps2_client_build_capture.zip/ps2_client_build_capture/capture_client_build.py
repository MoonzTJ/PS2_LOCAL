"""Copy the running game's on-disk executable for offline build comparison.

Only the process image path is queried. No process memory, command line,
configuration, account data or adjacent game files are read.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import zipfile

from capture_class_definitions import discover_client
from native_image_capture import PART_BYTES, split_archive
import win_reader as win


REPORTED_ONLINE_SHA256 = '6538c6cf5b7964974df70d12f5f78f6a97e5f104c4819995d5cf3ea45983bf4b'
MAX_EXECUTABLE_BYTES = 128*1024*1024


def archive_executable(exe, output_root):
    """Copy one bounded PE file, verify stable bytes, and publish a complete ZIP."""
    win.require(exe.name.casefold() == 'planetside2_x64.exe', 'Select the running PlanetSide2_x64 executable')
    size = exe.stat().st_size
    win.require(4096 <= size <= MAX_EXECUTABLE_BYTES, 'Game executable size exceeds the capture limits')
    with exe.open('rb') as source:
        layout = win.pe_layout(source.read(4096))
    original_sha = win.file_sha(exe)
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    name = f'local-client-build-{stamp}-{secrets.token_hex(8)}.zip'
    with tempfile.TemporaryDirectory(prefix='build-copy-', dir=output_root) as folder:
        staging = Path(folder)
        copied = staging/'PlanetSide2_x64.exe'
        digest = hashlib.sha256();total = 0
        with exe.open('rb') as source, copied.open('xb') as target:
            while block := source.read(win.CHUNK):
                total += len(block)
                win.require(total <= MAX_EXECUTABLE_BYTES, 'Game executable grew beyond the capture limit')
                target.write(block);digest.update(block)
        win.require(total == size and digest.hexdigest() == original_sha
                    and win.file_sha(exe) == original_sha,
                    'Game executable changed during copying; wait for the launcher to finish and retry')
        build = dict(format='ps2-on-disk-client-build-v1', captured_at_utc=datetime.now(timezone.utc).isoformat(),
                     source_exe_sha256=original_sha, source_exe_bytes=total,
                     local_reference_exe_sha256=win.EXPECTED_SHA256,
                     matches_local_reference_build=(original_sha == win.EXPECTED_SHA256),
                     matches_reported_online_build=(original_sha == REPORTED_ONLINE_SHA256),
                     pe_layout=layout, process_memory_read=False, command_line_read=False,
                     static_class_values_exported=False, new_build_layout_verified=False)
        payload=(json.dumps(build, indent=2)+'\n').encode()
        manifest=dict(format=build['format'], files={
            'PlanetSide2_x64.exe':dict(bytes=total,sha256=original_sha),
            'build.json':dict(bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())})
        archive=staging/name
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
            z.write(copied,'PlanetSide2_x64.exe')
            z.writestr('build.json',payload)
            z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
        with zipfile.ZipFile(archive) as z:
            win.require(z.testzip() is None, 'Build ZIP failed its integrity check')
            verified=hashlib.sha256()
            with z.open('PlanetSide2_x64.exe') as source:
                while block := source.read(win.CHUNK):verified.update(block)
            win.require(verified.hexdigest() == original_sha, 'Build ZIP executable checksum differs')
        destination=output_root/name
        win.require(not destination.exists(), 'Build ZIP already exists')
        archive.rename(destination)
    return destination


def prepare_uploads(archive, part_bytes=PART_BYTES):
    win.require(type(part_bytes) is int and 0 < part_bytes <= PART_BYTES, 'Invalid upload part size')
    uploads=archive.with_name(archive.name+'.upload')
    if archive.stat().st_size > part_bytes:
        split_archive(archive,uploads,part_bytes=part_bytes)
    else:
        uploads.mkdir()
        shutil.copyfile(archive,uploads/archive.name)
        win.require(win.file_sha(archive) == win.file_sha(uploads/archive.name), 'Upload ZIP checksum differs')
    return uploads


def capture(output_root, pid=None):
    win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8,
                'Run this helper with 64-bit Python on the Windows game PC')
    _,exe=discover_client(pid)
    print('Copying PlanetSide2_x64.exe from disk. No process memory is read.')
    archive=archive_executable(exe,output_root.resolve())
    return prepare_uploads(archive)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid',type=int)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'reports')
    args=parser.parse_args(argv)
    try:
        uploads=capture(args.output,args.pid)
    except (OSError,ValueError,subprocess.SubprocessError,zipfile.BadZipFile) as error:
        # OS exceptions may contain personal installation paths; omit their text.
        message=str(error) if isinstance(error,ValueError) else type(error).__name__
        code=getattr(error,'winerror',None) or getattr(error,'errno',None)
        if type(code) is int:message+=f' (OS error {code})'
        print('Build copy stopped: '+message)
        return 1
    print('\nUpload ALL files from this folder:')
    print(uploads)
    print('If there are parts, include every .part file and manifest.json.')
    try:subprocess.Popen(['explorer.exe',str(uploads)])
    except OSError:pass
    return 0


if __name__=='__main__':raise SystemExit(main())

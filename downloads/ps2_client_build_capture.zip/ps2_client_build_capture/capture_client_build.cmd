@echo off
cd /d "%~dp0"
py -3 capture_client_build.py
echo.
pause

"""Read only the matching client's six static VS class definitions.

No command line, login wrapper, character list, inventory or player data is read.
The helper does not start, modify or call functions in the game process.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import struct
import subprocess
import zipfile

import creator_capture as cc
from native_rows import ACCESSOR_SIGNATURE, CHAR_ACCESSOR_RVA, COUNTER_RVA, TABLE_RVA, LimitedReader
import win_reader as win


def snapshot(read_function, base):
    read = LimitedReader(read_function)
    win.require(read.exact(base+CHAR_ACCESSOR_RVA, len(ACCESSOR_SIGNATURE)) == ACCESSOR_SIGNATURE,
                'The loaded engine accessor differs from the matching build')
    raw_index = read.u32(base+COUNTER_RVA)
    index = (~raw_index) & 0xFFFFFFFF
    win.require(index < 64, 'The engine singleton index differs from the matching build')
    alternate = (index-15) & 63
    first = read.u64(base+TABLE_RVA+alternate*8)
    second = read.u64(base+TABLE_RVA+index*8)
    engine = first ^ second
    win.require(engine != 0, 'The game engine is not initialized')
    definitions = cc.class_definition_state(read, base, engine)
    win.require(read.u32(base+COUNTER_RVA) == raw_index
                and read.u64(base+TABLE_RVA+alternate*8) == first
                and read.u64(base+TABLE_RVA+index*8) == second,
                'The engine changed during export; run the helper again')
    rows = definitions.get('local_vs_definitions', [])
    complete = (len(rows) == len(cc.VS_PROFILE_IDS)
                and all(row['record_present'] and row['search_complete']
                        and row.get('complete_wire_record_available') for row in rows))
    for row in rows:
        if row.get('complete_wire_record_available'):
            wire = bytes.fromhex(row['wire_record_hex'])
            win.require(len(wire) == 90+12*row['nested_map_count']+4*row['nested_u32_tree_count'],
                        'The exported record length differs from the verified layout')
            row['wire_record_sha256'] = hashlib.sha256(wire).hexdigest()
    return dict(class_definitions=definitions, all_six_records_exported=complete,
                process_read_bytes=read.bytes, process_read_budget=16384,
                class_values_applied_to_backend=False, class_usability_verified=False,
                inventory_exported=False, account_or_character_data_exported=False)


def query_client_image(pid):
    """Ask Windows for the image path without enumerating modules or reading memory.

    Get-Process.Path can be null even when its process ID is available. Limited
    query access is sufficient for this API; memory access is requested later,
    only after the on-disk executable hash has passed.
    """
    from ctypes import wintypes as w
    win.require(type(pid) is int and 0 < pid <= 0xFFFFFFFF, 'The process ID is invalid')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
    kernel.OpenProcess.restype = w.HANDLE
    kernel.CloseHandle.argtypes = [w.HANDLE]
    kernel.CloseHandle.restype = w.BOOL
    kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
    kernel.QueryFullProcessImageNameW.restype = w.BOOL
    handle = kernel.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION only
    if not handle:
        raise OSError(ctypes.get_last_error(), 'Cannot query the running game executable')
    try:
        buffer = ctypes.create_unicode_buffer(32768)
        length = w.DWORD(len(buffer))
        if not kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
            raise OSError(ctypes.get_last_error(), 'Cannot locate the running game executable')
        win.require(0 < length.value < len(buffer) and len(buffer.value) == length.value,
                    'Windows returned an invalid game executable path')
        return Path(buffer.value).resolve(strict=True)
    finally:
        kernel.CloseHandle(handle)


def discover_client(pid=None):
    executable = (Path(os.environ.get('SystemRoot', r'C:\Windows')) /
                  'System32/WindowsPowerShell/v1.0/powershell.exe')
    win.require(executable.is_file(), 'Windows PowerShell is required to identify the client')
    if pid is not None:
        win.require(type(pid) is int and 0 < pid <= 0xFFFFFFFF, 'The process ID is invalid')
        command = (f"$ErrorActionPreference='Stop'; @(Get-Process -Id {pid} "
                   "-ErrorAction Stop | Select-Object Id,ProcessName) | ConvertTo-Json -Compress")
    else:
        command = ("$ErrorActionPreference='Stop'; @(Get-Process -Name PlanetSide2_x64 "
                   "-ErrorAction SilentlyContinue | Select-Object Id,ProcessName) | ConvertTo-Json -Compress")
    result = subprocess.run([str(executable), '-NoProfile', '-NonInteractive', '-Command', command],
                            capture_output=True, text=True, timeout=20)
    win.require(result.returncode == 0, 'Could not identify the running game client')
    data = json.loads(result.stdout.lstrip('\ufeff').strip() or '[]')
    rows = data if isinstance(data, list) else [data]
    win.require(len(rows) == 1, 'Leave exactly one PlanetSide2_x64 game window open, then run again')
    row = rows[0]
    win.require(isinstance(row, dict) and type(row.get('Id')) is int
                and 0 < row['Id'] <= 0xFFFFFFFF
                and row.get('ProcessName') == 'PlanetSide2_x64',
                'Could not identify the selected game executable')
    exe = query_client_image(row['Id'])
    win.require(exe.name.casefold() == 'planetside2_x64.exe', 'The selected process is not PlanetSide2_x64')
    return row['Id'], exe


def capture(output_root, pid=None):
    win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8,
                'Run this helper with 64-bit Python on the Windows game PC')
    report = dict(format='ps2-static-class-export-v1', helper_revision=2,
                  expected_exe_sha256=win.EXPECTED_SHA256,
                  captured_at_utc=datetime.now(timezone.utc).isoformat(),
                  source_exe_sha256=None, source_build_verified=False, all_six_records_exported=False)
    stage = 'client_detection'
    try:
        selected, exe = discover_client(pid)
        stage = 'executable_hash'
        report['source_exe_sha256'] = win.file_sha(exe)
        win.require(report['source_exe_sha256'] == win.EXPECTED_SHA256,
                    'Client build differs; no process memory was read. Upload this report so we can check the version')
        report['source_build_verified'] = True
        stage = 'open_readonly_process'
        reader = win.WindowsReader(selected, exe)
        try:
            stage = 'class_snapshot'
            report.update(snapshot(reader.read, reader.base))
        finally:
            reader.close()
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        # Discard all partial memory observations. Do not serialize executable
        # paths, process arguments, account identifiers or arbitrary memory.
        report['error_stage'] = stage
        report['error'] = str(exc) if isinstance(exc, ValueError) else type(exc).__name__
        code = getattr(exc, 'winerror', None) or getattr(exc, 'errno', None)
        if type(code) is int and 0 <= code <= 0xFFFFFFFF:
            report['os_error_code'] = code
            report['error'] += f' during {stage} (Windows error {code})'
            if code == 5:
                report['error'] += '; Windows denied access. Upload this report for diagnosis.'
    payload = (json.dumps(report, indent=2)+'\n').encode()
    manifest = dict(format=report['format'], files={'class-definitions.json':
                    dict(bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())},
                    all_six_records_exported=report['all_six_records_exported'],
                    source_build_verified=report['source_build_verified'])
    output_root = output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    path = output_root/f'local-class-definitions-{stamp}-{secrets.token_hex(4)}.zip'
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('class-definitions.json', payload)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
    with zipfile.ZipFile(path) as archive:
        win.require(archive.testzip() is None, 'Class export ZIP failed its integrity check')
    return path, report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid', type=int, help='Select a process if more than one game window is running')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'reports')
    args = parser.parse_args(argv)
    print('Read-only class exporter revision 2: locating the running game...')
    path, report = capture(args.output, args.pid)
    print(f'Upload this report ZIP: {path}')
    if report['all_six_records_exported']:
        print('All six static VS class records exported. No game or backend data was changed.')
        return 0
    print(report.get('error', 'Class export incomplete. Enter the normal game world, spawn once, and run again.'))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())

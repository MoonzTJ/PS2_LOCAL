@echo off
cd /d "%~dp0"
py -3 "%~dp0capture_local_state.py"
pause

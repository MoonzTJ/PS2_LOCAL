"""Read the already-running, matching offline client's bounded local state."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import zipfile

import native_rows
from native_image_capture import discover_pid
import win_reader as win

ROOT = Path(__file__).resolve().parent
SERVICE = 'ps2-local-console-v31'
SCENE_VERSION = 'active-actor-and-graphics-location-v1'


def read_input(root=ROOT):
    row = json.loads((root / 'local-state-input.json').read_text(encoding='utf-8'))
    win.require(row['format'] == 'ps2-local-state-input-v1'
                and row['source_exe_sha256'] == win.EXPECTED_SHA256
                and row.get('scene_observer') in (None, SCENE_VERSION),
                'Local-state helper input differs from the matching build')
    return row


def server_health(expected, instance=None):
    nonce = secrets.token_hex(16)
    request = dict(service=SERVICE, command='health', nonce=nonce)
    if instance is not None:
        request['instance_id'] = instance
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.connect(('127.0.0.1', 20043))
        sock.settimeout(2)
        sock.send(json.dumps(request).encode('ascii'))
        row = json.loads(sock.recv(16384))
    win.require(isinstance(row, dict), 'Invalid local server response')
    win.require(row.get('ok') is True and row.get('service') == SERVICE
                and row.get('command') == 'health' and row.get('nonce') == nonce
                and row.get('login_host') == '127.0.0.1' and row.get('login_port') == 20042
                and row.get('gateway_host') == '127.0.0.1' and row.get('gateway_port') == 20044
                and row.get('listener_ready') is True and row.get('gateway_transport_ready') is True
                and row.get('profile_sha256') == expected['server_profile_sha256'],
                'The matching local probe server did not answer')
    identifier = row.get('instance_id')
    win.require(isinstance(identifier, str) and re.fullmatch('[0-9a-f]{16}', identifier)
                and (instance is None or identifier == instance),
                'Local server instance changed; no snapshot is exported')
    probe = row.get('class_delivery_probe', {})
    win.require(probe.get('enabled') is True and probe.get('version') == expected['probe_version']
                and probe.get('packet_sha256') == expected['probe_packet_sha256']
                and probe.get('identity_count') == 24,
                'Run this capture with the existing class delivery probe server')
    return dict(instance_id=identifier, class_probe_packet_sha256=probe['packet_sha256'],
                server_profile_sha256=row['profile_sha256'])


def collect(game, output, expected, *, health=server_health, locate_pid=discover_pid,
            capture=None):
    stage = 'server_health'
    started = datetime.now(timezone.utc).isoformat()
    try:
        before = health(expected)
        stage = 'matching_local_process'
        pid = locate_pid()
        stage = 'bounded_native_snapshot'
        if capture is None:
            snapshot = native_rows.capture_selected(pid, Path(game),
                include_scene=expected.get('scene_observer') == SCENE_VERSION)
        else:
            snapshot = capture(pid, Path(game))
        win.require(snapshot.get('dummy_launch_verified') is True,
                    'Snapshot did not verify the local dummy-session launch')
        stage = 'server_recheck'
        after = health(expected, instance=before['instance_id'])
        win.require(after == before, 'Local server changed during capture')
        result = dict(kind='local_state_capture', format_version=1, ok=True,
            started_utc=started, source_exe_sha256=win.EXPECTED_SHA256,
            server_instance_id=before['instance_id'], server_health_before=before,
            server_health_after=after, native_snapshot=snapshot,
            game_files_changed=False, server_files_changed=False, process_suspended=False,
            limitation='Decoded record vectors are not a verified live camera or valid spawn; server identity is checked separately from process identity.')
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        # Do not retain a partial snapshot or local install paths on failure.
        result = dict(kind='local_state_capture_failed', format_version=1, ok=False,
            started_utc=started, stage=stage, error_type=type(error).__name__,
            windows_error=getattr(error, 'winerror', None), partial_snapshot_exported=False,
            reason='The bounded local capture stopped; no game/server changes were made.')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    destination = output / ('local-state-' + stamp + '-' + secrets.token_hex(4) + '.zip')
    raw = (json.dumps(result, indent=2, allow_nan=False) + '\n').encode()
    win.require(len(raw) <= 512 * 1024, 'Local state report exceeds the export bound')
    manifest = dict(format='ps2-local-state-report-v1', files={'local-state.json':
                    dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())})
    with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('local-state.json', raw)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(destination) as archive:
        win.require(archive.testzip() is None, 'Local state ZIP integrity check failed')
    return destination, result['ok']


def choose_game():
    try:
        import tkinter as tk
    except ImportError:
        return input('Copied PlanetSide 2 Local game folder: ').strip().strip('"')
    from tkinter import filedialog
    try:
        window = tk.Tk()
        window.withdraw()
        window.attributes('-topmost', True)
        try:
            return filedialog.askdirectory(parent=window,
                title='Choose the running PlanetSide 2 Local game folder (contains PlanetSide2_x64.exe)')
        finally:
            window.destroy()
    except tk.TclError:
        return input('Copied PlanetSide 2 Local game folder: ').strip().strip('"')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'reports')
    args = parser.parse_args(argv)
    try:
        win.require(os.name == 'nt' and win.ctypes.sizeof(win.ctypes.c_void_p) == 8,
                    'Run this helper with 64-bit Python on Windows')
        selected = args.game_dir or choose_game()
        if not selected:
            print('No folder selected. No capture made.')
            return 0
        game = Path(selected).expanduser().resolve(strict=True)
        win.require(not args.output_dir.resolve().is_relative_to(game),
                    'Extract this helper and keep its reports outside the game folder')
        destination, ok = collect(game, args.output_dir, read_input())
        print('Local state captured.' if ok else 'Capture stopped; upload the small failure report too.')
        print('Upload this ZIP:', destination)
        try:
            subprocess.Popen(['explorer.exe', str(destination.parent)])
        except OSError:
            pass
        return 0 if ok else 1
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('Local state capture could not start:', type(error).__name__)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

"""Bounded observations of GetPlayerLoc's actor and graphics fallback paths."""
import math
import struct

import win_reader as win


ACTOR_SIGNATURES = {
    # Registered GetPlayerLoc calls the engine's active-world-actor getter.
    0x142F94F: bytes.fromhex('e891f1cafe84c0752b'),
    0xA44696: bytes.fromhex('488b8910b00000488bdae8fab25fff'),
    0xA446AA: bytes.fromhex('4c8b00488bc841ff9010020000'),
    0xC08AD0: bytes.fromhex('488b8150240000c3'),
}
GRAPHICS_SIGNATURES = {
    # No active actor: GetPlayerLoc selects the graphics singleton's location.
    0x142F958: bytes.fromhex('8b058209c102f7d08d48f183e13f'),
    0x142F966: bytes.fromhex('488b8ccfc0c0170448338cc7c0c01704'),
    0x142F976: bytes.fromhex('e8461dc3fe0f28000f29442420'),
    0xB5E690: bytes.fromhex('488b8180050000480580010000c3'),
}
GRAPHICS_COUNTER_RVA = 0x40402E0
GRAPHICS_TABLE_RVA = 0x417C0C0


def require_signatures(read, base, signatures):
    for rva, expected in signatures.items():
        win.require(read.exact(base + rva, len(expected)) == expected,
                    'Native scene-location accessor differs from the matching build')


def require_player(read, engine, database, player, guid):
    win.require(read.u64(engine + 0xA2E0) == database
                and read.u64(database + 0xD68) == player
                and read.u64(player + 0x18) == guid,
                'Local player changed during scene observation')


def active_actor_state(read, base, engine, database, player, guid):
    require_signatures(read, base, ACTOR_SIGNATURES)
    require_player(read, engine, database, player, guid)
    manager = read.u64(engine + 0xB010)
    win.require(manager != 0, 'Active-world-actor manager is not initialized')
    actor = read.u64(manager + 0x2450)
    win.require(read.u64(engine + 0xB010) == manager
                and read.u64(manager + 0x2450) == actor,
                'Active world actor changed during scene observation')
    require_player(read, engine, database, player, guid)
    # A nonzero actor can be a vehicle/another controlled entity. Do not call its
    # virtual position getter or read a guessed actor layout.
    return dict(available=True, active_world_actor_present=bool(actor),
                ui_player_location_branch='active_world_actor' if actor else 'graphics_fallback',
                actor_matches_local_character='unverified', actor_position_observed=False,
                interpretation='The actor pointer selected by native GetPlayerLoc; no actor memory or virtual functions are inspected.')


def graphics_location_state(read, base, engine, database, player, guid):
    require_signatures(read, base, GRAPHICS_SIGNATURES)
    require_player(read, engine, database, player, guid)
    counter = read.u32(base + GRAPHICS_COUNTER_RVA)
    index = (~counter) & 0xFFFFFFFF
    win.require(index < 64, 'Graphics singleton index differs from the matching build')
    alternate = (index - 15) & 63
    table = base + GRAPHICS_TABLE_RVA
    first = read.u64(table + index * 8)
    second = read.u64(table + alternate * 8)
    graphics = first ^ second
    win.require(graphics != 0 and read.u64(engine + 0xB028) == graphics,
                'Graphics singleton does not match the local engine')
    camera = read.u64(graphics + 0x580)
    win.require(camera != 0, 'Graphics location object is not initialized')
    raw = read.exact(camera + 0x180, 16)
    values = struct.unpack('<4f', raw)
    win.require(all(math.isfinite(value) for value in values),
                'Graphics fallback location is nonfinite')
    win.require(read.exact(camera + 0x180, 16) == raw
                and read.u64(graphics + 0x580) == camera
                and read.u64(engine + 0xB028) == graphics
                and read.u32(base + GRAPHICS_COUNTER_RVA) == counter
                and read.u64(table + index * 8) == first
                and read.u64(table + alternate * 8) == second,
                'Graphics fallback location changed during scene observation')
    require_player(read, engine, database, player, guid)
    return dict(available=True, position_f32=list(values),
                position_raw_u32=list(struct.unpack('<4I', raw)), stable_reread=True,
                source='GetPlayerLoc graphics fallback accessor',
                actual_view_camera_association_verified=False, valid_spawn_verified=False,
                interpretation='Position exposed by the graphics fallback; not proof of local actor placement, an active camera association or safe ground.')


def scene_state(read, base, engine, database, player, guid):
    result = dict(interpretation='Independent sequential observations of GetPlayerLoc paths; neither enumerates terrain/collision.',
                  valid_spawn_verified=False, collision_verified=False)
    for name, observe in (('active_actor', active_actor_state),
                          ('graphics_location', graphics_location_state)):
        try:
            result[name] = observe(read, base, engine, database, player, guid)
        except ValueError as error:
            result[name] = dict(available=False, reason=str(error))
    result['available'] = any(result[name]['available'] for name in ('active_actor', 'graphics_location'))
    return result

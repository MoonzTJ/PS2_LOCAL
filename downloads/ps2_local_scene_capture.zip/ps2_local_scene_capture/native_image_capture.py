"""Capture three version-locked loaded sections of the local V31 client.

Uses read-only process access. Does not launch, suspend, modify or call into
the game. Captures code/constants, excluding writable data and the heap.
"""
from __future__ import annotations

import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import zipfile

import win_reader as win

SECTION_LAYOUT = {
    0: ('.text', 0x1000, 53178368, 'section-00-text.bin'),
    1: ('.rdata', 0x32B8000, 14185472, 'section-01-rdata.bin'),
    9: ('_RDATA', 0x48D0000, 54784, 'section-09-_RDATA.bin'),
}
PRIOR_HASHES = {
    'section-00-text.bin': '499d2bb87b715c56cd5bcfb0487782df586cdcae44dd3463c257e3b82ae16838',
    'section-01-rdata.bin': '9b77a95d916825c10ca31421e42d76b9d284b5ef68b3a24a7e03666648e73d7b',
}
SIGNATURES = {
    0xAE7240: bytes.fromhex('4038aeaeaf0000743a4038aeafaf00007431'),
    0xAE7267: bytes.fromhex('4038aeb0af000075134038ae38a30000740a'),
    0x207EFB0: bytes.fromhex('40534883ec300fb64210488bd9888138170000'),
}
PREFERRED_BASE = 0x140000000
PART_BYTES = 28 * 1024 * 1024


def exact(read, address, size):
    data = read(address, size)
    win.require(data is not None and len(data) == size,
                'A selected code section is unreadable. Keep the local game open and retry.')
    return data


def selected_sections(header):
    layout = win.pe_layout(header)
    nt = struct.unpack_from('<I', header, 0x3C)[0]
    win.require(struct.unpack_from('<Q', header, nt + 48)[0] == PREFERRED_BASE,
                'Unexpected preferred image base')
    selected = []
    for index, (name, rva, size, filename) in SECTION_LAYOUT.items():
        matches = [s for s in layout['sections'] if s['index'] == index]
        win.require(len(matches) == 1, 'A required native section is absent')
        section = matches[0]
        win.require((section['name'], section['rva'], section['size']) == (name, rva, size),
                    'Native section layout differs from the matching build')
        selected.append(dict(section, file=filename))
    return selected


def snapshot_sections(read, base, disk_header, output):
    """Bounded, double-read capture; reject holes, layout changes and packed code."""
    win.require(base == PREFERRED_BASE, 'Loaded image base differs from the native validation tools')
    selected = selected_sections(disk_header)
    header = exact(read, base, len(disk_header))
    win.require(selected_sections(header) == selected, 'Loaded and on-disk section layouts differ')
    for rva, signature in SIGNATURES.items():
        win.require(exact(read, base + rva, len(signature)) == signature,
                    'The expected code is not loaded yet. Wait for the character menu, then retry.')
    records = []
    for section in selected:
        digest = hashlib.sha256()
        with (output / section['file']).open('xb') as stream:
            for offset in range(0, section['size'], win.CHUNK):
                data = exact(read, base + section['rva'] + offset,
                             min(win.CHUNK, section['size'] - offset))
                stream.write(data)
                digest.update(data)
        verification = hashlib.sha256()
        for offset in range(0, section['size'], win.CHUNK):
            verification.update(exact(read, base + section['rva'] + offset,
                                      min(win.CHUNK, section['size'] - offset)))
        sha = digest.hexdigest()
        win.require(verification.hexdigest() == sha,
                    'A selected code section changed during capture; retry at the character menu.')
        records.append(dict(index=section['index'], name=section['name'], rva=section['rva'],
                            file=section['file'], size=section['size'], sha256=sha,
                            missing_bytes=0, second_read_matches=True,
                            prior_capture_sha256=PRIOR_HASHES.get(section['file']),
                            matches_prior_capture=(sha == PRIOR_HASHES[section['file']])
                            if section['file'] in PRIOR_HASHES else None))
        print(f"Captured {section['name']}: {section['size']:,} bytes")
    win.require(exact(read, base, len(disk_header)) == header,
                'Loaded image header changed during capture')
    return records


def split_archive(source, destination, part_bytes=PART_BYTES):
    """Create upload-sized files and a checksum manifest, preserving the ZIP."""
    win.require(type(part_bytes) is int and 0 < part_bytes <= PART_BYTES,
                'Invalid upload part size')
    destination.mkdir()
    parts, digest, total = [], hashlib.sha256(), 0
    with source.open('rb') as stream:
        while data := stream.read(part_bytes):
            name = f'{source.name}.part{len(parts) + 1:03d}'
            with (destination / name).open('xb') as target:
                target.write(data)
            digest.update(data)
            total += len(data)
            parts.append(dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    manifest = dict(format_version=1, original_name=source.name, original_bytes=total,
                    original_sha256=digest.hexdigest(), parts=parts)
    with (destination / 'manifest.json').open('x', encoding='utf-8') as target:
        json.dump(manifest, target, indent=2)
        target.write('\n')
    return manifest


def powershell(command):
    executable = (Path(os.environ.get('SystemRoot', r'C:\Windows')) /
                  'System32/WindowsPowerShell/v1.0/powershell.exe')
    win.require(executable.is_file(), 'Windows PowerShell is required to identify the local client')
    result = subprocess.run([str(executable), '-NoProfile', '-NonInteractive', '-Command', command],
                            capture_output=True, text=True, timeout=20)
    win.require(result.returncode == 0, 'Could not identify the running client')
    text = result.stdout.lstrip('\ufeff').strip()
    return json.loads(text) if text else None


def discover_pid():
    result = powershell("$ErrorActionPreference='Stop'; @(Get-Process -Name PlanetSide2_x64 "
                        "-ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id) "
                        "| ConvertTo-Json -Compress")
    pids = [] if result is None else result if isinstance(result, list) else [result]
    win.require(len(pids) == 1 and type(pids[0]) is int and 0 < pids[0] <= 0xFFFFFFFF,
                'Leave exactly one local PlanetSide2_x64 window open, then run this helper again.')
    return pids[0]


def capture(game, output_root, pid=None):
    win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8,
                'Run this helper with 64-bit Python on the Windows test PC')
    game = game.resolve(strict=True)
    exe = game / 'PlanetSide2_x64.exe'
    win.require(win.file_sha(exe) == win.EXPECTED_SHA256,
                'The copied executable differs from the matching V31 build')
    with exe.open('rb') as stream:
        header = stream.read(4096)
    selected_sections(header)
    config = game / win.CONFIG
    win.require(config.stat().st_size <= 128 * 1024, 'Unexpected local config size')
    win.check_local_config(config.read_bytes())
    pid = discover_pid() if pid is None else pid
    win.require(type(pid) is int and 0 < pid <= 0xFFFFFFFF, 'Invalid local client PID')
    arguments = win.process_arguments(pid)
    win.check_arguments(arguments)
    win.require(Path(arguments[0]).samefile(exe), 'The running game is not from the copied local folder')
    output_root.mkdir(parents=True, exist_ok=True)
    reader = None
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    archive = output_root / f'local-client-image-{stamp}.zip'
    try:
        reader = win.WindowsReader(pid, exe)
        with tempfile.TemporaryDirectory(prefix='native-sections-', dir=output_root) as temporary:
            staging = Path(temporary)
            records = snapshot_sections(reader.read, reader.base, header, staging)
            # Recheck identity after reading, without saving the command line.
            final_arguments = win.process_arguments(pid)
            win.check_arguments(final_arguments)
            win.require(Path(final_arguments[0]).samefile(exe),
                        'Client identity changed during capture')
            win.require(win.file_sha(exe) == win.EXPECTED_SHA256,
                        'Executable changed during capture')
            manifest = dict(format_version=1, kind='matching_loaded_native_sections',
                            source_exe_sha256=win.EXPECTED_SHA256, base=reader.base,
                            captured_utc=datetime.now(timezone.utc).isoformat(),
                            dummy_launch_verified=True, local_config_verified=True,
                            process_access='QUERY_INFORMATION | VM_READ',
                            consistency='Sequential capture and second hash read; process not suspended',
                            sections=records)
            (staging / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
            with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
                for name in ['manifest.json'] + [row['file'] for row in records]:
                    zipped.write(staging / name, name)
        with zipfile.ZipFile(archive) as zipped:
            win.require(zipped.testzip() is None, 'Capture ZIP integrity check failed')
    finally:
        if reader is not None:
            reader.close()
    if archive.stat().st_size > PART_BYTES:
        uploads = archive.with_name(archive.name + '.parts')
        split_archive(archive, uploads)
        print('\nUpload every .part file and manifest.json from:')
        print(uploads)
    else:
        uploads = output_root
        print('\nUpload this ZIP:')
        print(archive)
    return uploads


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path, default=Path(win.DEFAULT_GAME))
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent / 'captures')
    parser.add_argument('--pid', type=int)
    args = parser.parse_args(argv)
    try:
        output = capture(args.game_dir, args.output_dir, args.pid)
        try:
            subprocess.Popen(['explorer.exe', str(output)])
        except OSError:
            pass
    except (OSError, ValueError, subprocess.SubprocessError, zipfile.BadZipFile) as error:
        print(f'Capture stopped: {error}')
        return 1
    print('\nCapture complete. The files to upload are in the folder that just opened.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

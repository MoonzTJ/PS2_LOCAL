# Next Windows test: loading timeline

The uploaded loaded-code image has been verified. The current confirmation
packet passes the native opcode registry and sets the preload flag in a bounded
fixture. The game also contains a separate loading path that clears that flag.
This test records the actual Windows handler registration and flag timing.

1. Extract `ps2_loading_observer.zip` into its own folder.
2. Start your existing V31 local server and client. Select **LocalVS** in the
   character menu; wait before clicking Play.
3. Double-click **capture_loading_timeline.cmd** in the extracted helper folder.
4. Press **Enter** when prompted, switch to the game, and click **Play once**.
5. Leave the game open for **90 seconds**. Upload the
   **local-loading-timeline-....zip** from the folder that opens.
6. Export and upload the usual console report from the same run so its packet
   sends and acknowledgments can be compared with the timeline.

The helper uses your installed 64-bit Python and the same matching executable,
local V31 configuration, and dummy-session checks as the prior capture helper.
It records loading flags, class count, profile-loader presence, and bounded
checks of the fallback, ClientUpdate, and ReferenceData listeners. The ZIP
contains observations, with no memory addresses or process command line.

It samples nominally every 50 milliseconds for the first 15 seconds, then every
250 milliseconds. It opens the process for reading; it does not launch, patch,
suspend, or call functions in the game. Shorter transitions may be missed and
handler registration alone does not prove the handler ran. No native readiness
flags or application packets are changed by this helper.

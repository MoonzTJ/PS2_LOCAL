@echo off
setlocal
cd /d "%~dp0"
title PS2 local loading timeline
echo Start your existing V31 local server and game. Select LocalVS in the menu.
echo This records the loading transition and prepares one small ZIP to upload.
echo.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 (
    py -3 loading_capture.py %*
    goto done
)
python loading_capture.py %*
:done
echo.
pause

@echo off
setlocal
cd /d "%~dp0"
title MoonSol Profile Resource Capture
echo Reads matching tables and actor files from your separate local game copy.
echo Game and backend files are read only. No game launch or network connection.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 (
    py -3 collect_profile_resources.py %*
    goto done
)
python collect_profile_resources.py %*
:done
echo.
pause

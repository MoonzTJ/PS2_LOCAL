# Next Windows capture

Keep the installed V31.2 package. This capture gathers missing source inputs;
it does not install a game patch or launch a loading-screen trial.

1. Extract `ps2_profile_resource_capture.zip` into its own folder anywhere.
2. Double-click `collect_profile_resources.cmd`. Python 3.10 or newer is needed;
   your installed Python 3.14 is suitable.
3. Wait for the pack-index messages to finish.
4. Open the `captures` folder beside the collector.
5. Upload the new `local-profile-resources-....zip` here. If capture fails, send
   the displayed error instead.

The default game folder is:

```text
C:\Users\Public\Daybreak Game Company\Installed Games\PlanetSide 2 Local
```

For a different game folder, run this from Command Prompt in the extracted
collector folder (replace the example path):

```cmd
collect_profile_resources.cmd --game-dir "D:\Games\PlanetSide 2 Local"
```

The collector verifies the exact client executable and the two previously
verified item/model table hashes, checks PACK2 record bounds and CRC32C, and
exports candidate profile/loadout/item tables plus starter/class actor files.
It reads game files and writes only a research ZIP in its own `captures` folder.
It does not copy the executable or entire packs and does not use the network.
Reports are bounded to 30 MiB. Existing game/backend files stay untouched.

Some resources may be absent. The manifest records them explicitly. Male/female
expansions are discovery candidates; finding them does not validate native
appearance substitution. These inputs do not themselves establish complete
server class definitions, owned inventory or successful asset streaming.

Why this is next: matching native checks show that metadata cached before the
profile loader is constructed produces model requests. A late reply clears an
item wait and queues its filename, but the tested pump does not submit a new
asset request. Complete matching metadata and class/loadout inputs must be
established before packaging the next game-loading change.

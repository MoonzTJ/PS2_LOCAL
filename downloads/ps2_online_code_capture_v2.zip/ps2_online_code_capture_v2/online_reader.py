"""Documented read-only Windows access for the revision-2 online collector.

VM_READ and executable identity use separate handles. Toolhelp supplies the
main module address. Denied access is reported without privilege changes.
"""
import ctypes
import os
from pathlib import Path

from win_reader import CHUNK, MAX_IMAGE, require

VM_READ = 0x0010
QUERY_LIMITED_INFORMATION = 0x1000
SNAPMODULE = 0x00000008
ERROR_NO_MORE_FILES = 18
ERROR_BAD_LENGTH = 24
MAX_MODULES = 4096


class ReaderAccessError(OSError):
    def __init__(self,stage,message,code=None,requested_access=None):
        super().__init__(code,message)
        self.stage=stage
        self.message=message
        self.requested_access=requested_access


class MODULEENTRY32W(ctypes.Structure):
    # Fixed-width Windows types also let Linux tests verify the x64 ABI.
    _fields_=[('dwSize',ctypes.c_uint32),('th32ModuleID',ctypes.c_uint32),
              ('th32ProcessID',ctypes.c_uint32),('GlblcntUsage',ctypes.c_uint32),
              ('ProccntUsage',ctypes.c_uint32),('modBaseAddr',ctypes.c_void_p),
              ('modBaseSize',ctypes.c_uint32),('hModule',ctypes.c_void_p),
              ('szModule',ctypes.c_uint16*256),('szExePath',ctypes.c_uint16*260)]


class _WindowsAPI:
    def __init__(self):
        require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,
                'Use 64-bit Python on Windows')
        self.k=ctypes.WinDLL('kernel32',use_last_error=True)
        signatures={
            'OpenProcess':([ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32],ctypes.c_void_p),
            'CloseHandle':([ctypes.c_void_p],ctypes.c_int),
            'QueryFullProcessImageNameW':([ctypes.c_void_p,ctypes.c_uint32,
                ctypes.POINTER(ctypes.c_wchar),ctypes.POINTER(ctypes.c_uint32)],ctypes.c_int),
            'CreateToolhelp32Snapshot':([ctypes.c_uint32,ctypes.c_uint32],ctypes.c_void_p),
            'Module32FirstW':([ctypes.c_void_p,ctypes.POINTER(MODULEENTRY32W)],ctypes.c_int),
            'Module32NextW':([ctypes.c_void_p,ctypes.POINTER(MODULEENTRY32W)],ctypes.c_int),
            'ReadProcessMemory':([ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,
                ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)],ctypes.c_int),
        }
        for name,(arguments,result) in signatures.items():
            fn=getattr(self.k,name);fn.argtypes=arguments;fn.restype=result
        require(ctypes.sizeof(MODULEENTRY32W)==1080,'Unexpected Windows module-entry ABI')

    def open_process(self,access,pid,stage):
        handle=self.k.OpenProcess(access,False,pid)
        if not handle:raise ReaderAccessError(stage,'Windows denied the requested process handle',
                                               ctypes.get_last_error(),access)
        return handle

    def close(self,handle):
        self.k.CloseHandle(handle)

    def query_path(self,handle):
        buffer=ctypes.create_unicode_buffer(32768);length=ctypes.c_uint32(len(buffer))
        if not self.k.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(length)):
            raise ReaderAccessError('query_executable_identity','Executable identity query failed',
                                    ctypes.get_last_error())
        return buffer.value

    def snapshot(self,pid):
        # Windows documents transient ERROR_BAD_LENGTH during loader changes.
        for _ in range(3):
            handle=self.k.CreateToolhelp32Snapshot(SNAPMODULE,pid)
            if handle not in (None,0,ctypes.c_void_p(-1).value):return handle
            code=ctypes.get_last_error()
            if code!=ERROR_BAD_LENGTH:break
        raise ReaderAccessError('module_snapshot','Module snapshot failed',code)

    def module(self,snapshot,first):
        row=MODULEENTRY32W();row.dwSize=ctypes.sizeof(row)
        fn=self.k.Module32FirstW if first else self.k.Module32NextW
        if not fn(snapshot,ctypes.byref(row)):
            code=ctypes.get_last_error()
            if code==ERROR_NO_MORE_FILES:return None
            raise ReaderAccessError('module_first' if first else 'module_next',
                                    'Module enumeration failed',code)
        path=bytes(row.szExePath).decode('utf-16-le').split('\0',1)[0]
        return row.th32ProcessID,path,row.modBaseAddr,row.modBaseSize

    def read(self,handle,address,size):
        buffer=ctypes.create_string_buffer(size);done=ctypes.c_size_t()
        if not self.k.ReadProcessMemory(handle,ctypes.c_void_p(address),buffer,size,ctypes.byref(done)):
            raise ReaderAccessError('read_process_memory','Selected code/constants could not be read',
                                    ctypes.get_last_error())
        if done.value!=size:
            raise ReaderAccessError('read_process_memory_partial','Selected read was incomplete')
        return buffer.raw


class OnlineReader:
    def __init__(self,pid,expected_exe,*,_api=None):
        require(type(pid) is int and 0<pid<=0xFFFFFFFF,'Invalid selected process ID')
        self.api=_api if _api is not None else _WindowsAPI()
        self.handle=None;identity=None;snapshot=None
        try:
            self.handle=self.api.open_process(VM_READ,pid,'open_memory_read')
            identity=self.api.open_process(QUERY_LIMITED_INFORMATION,pid,'open_identity_query')
            self._same_file(self.api.query_path(identity),expected_exe,'verify_executable_identity')
            snapshot=self.api.snapshot(pid)
            self.base=None
            for index in range(MAX_MODULES):
                row=self.api.module(snapshot,index==0)
                if row is None:break
                module_pid,path,base,size=row
                if module_pid!=pid:
                    raise ReaderAccessError('verify_module_identity','Module snapshot has a different process ID')
                if Path(path).name.casefold()!=Path(expected_exe).name.casefold():continue
                self._same_file(path,expected_exe,'verify_module_identity')
                if not (type(base) is int and 0<base<2**47 and base%4096==0
                        and 0<size<=MAX_IMAGE and base+size<2**47):
                    raise ReaderAccessError('verify_module_bounds','Main module has invalid bounds')
                self.base=base;self.module_size=size;break
            if self.base is None:
                raise ReaderAccessError('find_main_module','Verified main module was not found within the module limit')
        except BaseException:
            self.close();raise
        finally:
            if snapshot is not None:self.api.close(snapshot)
            if identity is not None:self.api.close(identity)

    @staticmethod
    def _same_file(path,expected,stage):
        try:matches=Path(path).samefile(expected)
        except OSError as error:
            raise ReaderAccessError(stage,'Executable identity could not be verified',error.errno) from None
        if not matches:raise ReaderAccessError(stage,'Selected process/module is a different executable')

    def read(self,address,size):
        require(self.handle is not None,'Reader is closed')
        require(type(address) is int and type(size) is int and 0<size<=CHUNK
                and self.base<=address and address+size<=self.base+self.module_size,
                'Read exceeds the verified main module')
        return self.api.read(self.handle,address,size)

    def close(self):
        if self.handle is not None:
            self.api.close(self.handle);self.handle=None

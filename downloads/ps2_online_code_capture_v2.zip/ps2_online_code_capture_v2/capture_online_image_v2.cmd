@echo off
cd /d "%~dp0"
py -3 capture_online_image_v2.py
echo.
pause

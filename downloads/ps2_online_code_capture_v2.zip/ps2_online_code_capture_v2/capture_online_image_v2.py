"""Revision-2 entry point for the bounded, read-only online code collector."""
from capture_online_image import main
from online_reader import OnlineReader


if __name__=='__main__':
    raise SystemExit(main(reader_factory=OnlineReader,collector_revision=2))

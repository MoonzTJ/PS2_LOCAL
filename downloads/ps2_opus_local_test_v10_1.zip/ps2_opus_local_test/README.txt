# Opus Local Test v10.1 — change the model after placement to rebuild the arms

The client's own `Logs/FirstPersonArms.log` shows the model-165 activation
creating the VS LA first-person arms ("ready for attachments"), then the
placement detaching the camera from them. v10 resent the same activation after
placement; the client received it but ignored it, because it only rebuilds when
the model changes. In this version, after the placement the server sends the
original model-0 activation (about 3 s), then the model-165 one (about 4.5 s),
once each. The body may flicker for a moment. No new message type, no forced flags.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Select **LocalVSTest**, press **Play**, and run **Advanced → Existing bootstrap
   diagnostic (once)**. Wait for THREE beeps. If the diagnostic stops with a
   message after the placement, that is fine; the two activations still go out.
4. Look around and walk. Note whether the view now moves with the character,
   and whether arms appear.
5. Run **Capture Camera.cmd**. Return to the game within five seconds. At TWO
   beeps, hold W and turn with the mouse until THREE beeps.
6. Upload the new `reports/local-camera-….json`, the bootstrap ZIP and the
   copied game's `Logs/FirstPersonArms.log`. If it crashes, include the newest
   Logs files.

The server status records `post_placement_model_toggle` (each step's name,
model, packet hash and time after placement). Whether the arms were rebuilt or
the camera attached is only established by the Windows capture and log.

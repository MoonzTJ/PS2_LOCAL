# Capture the loaded native sections

The uploaded executable matches SHA-256
`e32f897cd52e5f24e8000901ab8a18814c691eb8aeb21049b943fb1320bfe957`.
Its on-disk code is packed: the native profile/preload function bytes and the
text/rdata hashes differ from the retained loaded-image capture. Extracting PE
sections from that file does not produce inputs for the native oracles.

1. Start the existing V31 server and client as usual. Leave the game open at
   the character menu or INDAR loading screen.
2. Extract `ps2_native_capture.zip` into its own folder, then double-click
   `capture_loaded_image.cmd` inside it. It uses the existing default game
   folder: `C:\Users\Public\Daybreak Game Company\Installed Games\PlanetSide 2 Local`.
3. When the helper opens an output folder, upload the ZIP it names. If it
   creates parts, upload every `.part` file and that folder's `manifest.json`.

No Python command entry or further gameplay waiting test is needed. A custom
game folder can be supplied with `--game-dir "C:\path\to\local game"`.

The helper verifies the executable hash, local V31 config, dummy launch,
process path, image base, section layout and loaded-code signatures. It reads
only section indexes 0 (`.text`), 1 (`.rdata`) and 9 (`_RDATA`), totaling
67,418,624 bytes. A second read checks section stability. Unreadable or changing
sections fail instead of filling holes with zeros. Original game files are
read only, and the process is not suspended. The exported manifest records
whether the sections match the earlier capture; unknown hashes are preserved
as new evidence rather than silently substituted for the pinned ones.

The standalone download contains the capture script and a generated copy of
`win_reader.py` with the V31 config name embedded, removing its backend import.
Keep it in its own folder so the existing V31 files remain intact. Linux tests
exercise the bounded read/export guards with synthetic sections; running the
helper against the actual game still requires the Windows PC.

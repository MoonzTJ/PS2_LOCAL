@echo off
setlocal
cd /d "%~dp0"
title PS2 local loaded-code capture
echo Leave your V31 local game open at the character menu or INDAR loading screen.
echo This reads the matching game's loaded code sections and prepares upload files.
echo.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 (
    py -3 native_image_capture.py %*
    goto done
)
python native_image_capture.py %*
:done
echo.
pause

"""Read-only samples of the local actor position next to the graphics camera position.

Capture 215523 showed the actor walking ~23 units after placement while the view
stayed at the placement point. Each sample pairs the actor's clean transform
position (actor_loading_observer) with the graphics singleton camera object's
location (scene_observer), so a frozen camera and a moving actor can be told
apart. Nothing is written to the game and no native function is called.
"""
import ctypes
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import secrets

import actor_loading_observer
from character_observer import StableFields
import native_rows as nr
from presets import VS_TEST_PRESET
from scene_observer import active_actor_state, graphics_location_state, require_player
import win_reader as win

VERSION = 'camera-vs-actor-samples-v2'
# Native camera factory AD57E0 (jump table AD5EBC): constructor vtable RVA per
# camera type, from the matching loaded sections. Types sharing one class share
# a vtable. 21/22 use the timed transition camera (E61290) whose update E62490
# picks first person (19, "SetAliveInfantryGameState") or spawn selection.
CAMERA_VTABLES = {
    0x342EFE0: (1, 2), 0x3434370: (3,), 0x3438B10: (4, 5, 7, 14, 17, 18), 0x3430898: (6,),
    0x34348F8: (8,), 0x343F778: (9,), 0x3434FE0: (10,), 0x34300F8: (11,), 0x3439A18: (12,),
    0x3439098: (13,), 0x3439F28: (15,), 0x3438480: (16,), 0x3436CD8: (19,), 0x34E5C10: (20,),
    0x3433A48: (21, 22), 0x3439678: (23,), 0x343F0B0: (24,), 0x342F738: (25,), 0x3437D18: (26,),
}
FIRST_PERSON_TYPE, TRANSITION_VTABLE = 19, 0x3433A48
SAMPLES = 6
INTERVAL = 1.5
LEAD_IN = 5.0


def active_camera_state(read, base, engine):
    camera = read.u64(engine+0xB040)
    if not camera:
        return dict(available=True, present=False)
    vtable = read.u64(camera) - base
    types = CAMERA_VTABLES.get(vtable)
    result = dict(available=True, present=True, vtable_rva=hex(vtable), camera_types=list(types or ()),
                  is_first_person=types == (FIRST_PERSON_TYPE,), known_class=types is not None)
    if vtable == TRANSITION_VTABLE:
        # E61D50 "finished": +178 == 0 and +180 != 0 and +170 == 0; +16C counts down.
        result['transition'] = dict(timer_16c=read.u32(camera+0x16C), field_170=read.u32(camera+0x170),
                                    flag_178=read.exact(camera+0x178, 1)[0], flag_180=read.exact(camera+0x180, 1)[0])
    win.require(read.u64(engine+0xB040) == camera, 'Active camera changed during capture')
    return result


def sample(read_function, base):
    budget = nr.LimitedReader(read_function)
    win.require(budget.exact(base+nr.CHAR_ACCESSOR_RVA, len(nr.ACCESSOR_SIGNATURE)) == nr.ACCESSOR_SIGNATURE,
                'Camera capture engine accessor differs')
    engine = nr.locate(budget, base)[1]; fields = StableFields(budget, 512)
    database = fields.u64(engine+0xA2E0); player = fields.u64(database+0xD68); guid = fields.u64(player+0x18)
    win.require(guid == VS_TEST_PRESET['character_id'], 'Select LocalVSTest for the camera capture')
    result = dict(character_guid=guid)
    try: result['active_camera'] = active_camera_state(budget, base, engine)
    except ValueError as error: result['active_camera'] = dict(available=False, reason=str(error))
    for name, observe in (('actor_loading', actor_loading_observer.actor_loading_state),
                          ('active_actor', active_actor_state), ('camera', graphics_location_state)):
        try: result[name] = observe(budget, base, engine, database, player, guid)
        except ValueError as error: result[name] = dict(available=False, reason=str(error))
    fields.verify(); require_player(budget, engine, database, player, guid)
    win.require(nr.locate(budget, base)[1] == engine, 'Engine changed during camera capture')
    actor = result['actor_loading'].get('motion', {}).get('position_f32')
    camera = result['camera'].get('position_f32')
    result.update(actor_position=actor, camera_position=camera, read_bytes=budget.bytes,
                  camera_actor_distance=(math.dist(actor[:3], camera[:3]) if actor and camera else None))
    return result


def summarize(samples):
    actors = [s['actor_position'] for s in samples if s.get('actor_position')]
    cameras = [s['camera_position'] for s in samples if s.get('camera_position')]
    span = lambda rows: max(math.dist(a[:3], b[:3]) for a in rows for b in rows) if len(rows) > 1 else None
    actor_span, camera_span = span(actors), span(cameras)
    verdict = ('incomplete' if actor_span is None or camera_span is None else
               'camera_frozen_while_actor_moved' if actor_span > 1.0 and camera_span < 0.05 else
               'camera_moved_with_actor' if actor_span > 1.0 and camera_span > 0.5 * actor_span else
               'actor_did_not_move' if actor_span <= 1.0 else 'camera_moved_partially')
    types = sorted({tuple(s.get('active_camera', {}).get('camera_types', ())) for s in samples})
    return dict(actor_span=actor_span, camera_span=camera_span, verdict=verdict, active_camera_types=[list(t) for t in types],
                interpretation='Spans are the largest distance between samples. Movement needs W held during sampling.')


def collect(game, output, *, locate_pid=None, sleep=None, beep=None, open_reader=None):
    import time
    sleep = sleep or time.sleep
    if locate_pid is None:
        from native_image_capture import discover_pid as locate_pid
    if beep is None:
        def beep(count):
            import winsound
            for _ in range(count): winsound.Beep(880, 180)
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    result = dict(kind='local-camera-capture', version=VERSION, ok=False, samples=[],
                  native_calls_performed=False, gameplay_state_changed=False)
    reader = None
    try:
        win.require(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8 or open_reader is not None,
                    'Use 64-bit Python on Windows')
        pid = locate_pid(); win.require(type(pid) is int and 0 < pid <= 0xffffffff, 'Invalid PID')
        if open_reader is None:
            game = Path(game).resolve(strict=True); exe = game/'PlanetSide2_x64.exe'
            win.require(win.file_sha(exe) == win.EXPECTED_SHA256, 'Copied executable differs from captured build')
            config = game/win.CONFIG; win.require(config.stat().st_size <= 128*1024, 'Unexpected config size')
            win.check_local_config(config.read_bytes()); argv = win.process_arguments(pid); win.check_arguments(argv)
            win.require(Path(argv[0]).samefile(exe), 'Command-line executable differs from copied game')
            reader = win.WindowsReader(pid, exe)
        else:
            reader = open_reader(pid)
        print(f'Return to the game now. Sampling starts in {LEAD_IN:.0f} seconds: hold W and turn with the mouse.')
        sleep(LEAD_IN); beep(2)
        for index in range(SAMPLES):
            if index: sleep(INTERVAL)
            row = sample(reader.read, reader.base)
            row.update(index=index, captured_utc=datetime.now(timezone.utc).isoformat())
            result['samples'].append(row)
        result.update(ok=True, summary=summarize(result['samples']))
    except (OSError, ValueError) as error:
        result.update(reason=str(error))
    finally:
        if reader is not None: reader.close()
        try: beep(3)
        except (OSError, ImportError): pass
    target = output/('local-camera-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'-'+secrets.token_hex(4)+'.json')
    target.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print('Upload this file:', target)
    if result['ok']: print('Result:', result['summary']['verdict'])
    else: print('Capture stopped:', result.get('reason'))
    return target, result

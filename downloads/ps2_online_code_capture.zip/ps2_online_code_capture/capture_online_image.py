"""Capture only the verified online build's loaded code and readonly constants.

No writable sections, heap, account data, command line, or class records are
read. No process write, native call, launch or protection change is performed.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import tempfile
import zipfile

from capture_class_definitions import discover_client
from capture_client_build import prepare_uploads
import win_reader as win


EXPECTED_SHA256 = '6538c6cf5b7964974df70d12f5f78f6a97e5f104c4819995d5cf3ea45983bf4b'
SECTION_LAYOUT = {
    0: ('.text', 0x1000, 53187072, 0x60000020, 'section-00-text.bin'),
    1: ('.rdata', 0x32BB000, 14187520, 0x40000040, 'section-01-rdata.bin'),
    9: ('_RDATA', 0x48D3000, 54784, 0x40000040, 'section-09-_RDATA.bin'),
}
CLASS_NAMES = (b'TargetHasProfileClassification\0', b'SourceHasProfileClassification\0',
               b'GetProfileCost\0', b'CanPurchaseProfile\0')


def selected_sections(header):
    layout=win.pe_layout(header)
    selected=[]
    for index,(name,rva,size,flags,filename) in SECTION_LAYOUT.items():
        rows=[s for s in layout['sections'] if s['index']==index]
        win.require(len(rows)==1 and (rows[0]['name'],rows[0]['rva'],rows[0]['size'],rows[0]['flags'])
                    == (name,rva,size,flags), 'Online code/constant section layout differs from the verified disk image')
        win.require(not flags & 0x80000000, 'Writable sections are excluded from this capture')
        selected.append(dict(rows[0],file=filename))
    return selected


def snapshot_sections(read,base,disk_header,output,disk_hashes):
    selected=selected_sections(disk_header)
    budget=2*sum(s['size'] for s in selected)+2*len(disk_header)
    used=0
    def exact(address,size):
        nonlocal used
        ranges=[(base,base+len(disk_header))]+[(base+s['rva'],base+s['rva']+s['size']) for s in selected]
        win.require(0<size<=win.CHUNK and any(start<=address and address+size<=end for start,end in ranges),
                    'Read falls outside the selected code/constant sections')
        win.require(used+size<=budget, 'Code capture exceeded its read budget')
        used+=size
        data=read(address,size)
        win.require(data is not None and len(data)==size,
                    'A selected code/constant region is unreadable; upload the failure report')
        return data
    header=exact(base,len(disk_header))
    win.require(selected_sections(header)==selected, 'Loaded section layout differs from disk')
    records=[]
    for section in selected:
        digest=hashlib.sha256()
        with (output/section['file']).open('xb') as target:
            for offset in range(0,section['size'],win.CHUNK):
                block=exact(base+section['rva']+offset,min(win.CHUNK,section['size']-offset))
                target.write(block);digest.update(block)
        verified=hashlib.sha256()
        for offset in range(0,section['size'],win.CHUNK):
            verified.update(exact(base+section['rva']+offset,min(win.CHUNK,section['size']-offset)))
        win.require(digest.hexdigest()==verified.hexdigest(), 'Code/constants changed during capture; retry at the character menu')
        records.append(dict(index=section['index'],name=section['name'],rva=section['rva'],file=section['file'],
                            bytes=section['size'],sha256=digest.hexdigest(),second_read_matches=True,
                            disk_section_sha256=disk_hashes[section['index']],
                            differs_from_disk=(digest.hexdigest()!=disk_hashes[section['index']])))
        print(f"Captured {section['name']}: {section['size']:,} bytes")
    constants=(output/'section-01-rdata.bin').read_bytes()
    win.require(all(name in constants for name in CLASS_NAMES),
                'Expected class names are not loaded; retry after reaching the character menu')
    win.require(records[0]['differs_from_disk'], 'The main code section is still in its on-disk form')
    win.require(exact(base,len(disk_header))==header, 'Loaded image header changed during capture')
    return dict(sections=records,process_read_bytes=used,process_read_budget=budget,
                named_class_constants_present=True,class_layout_compatibility_verified=False)


def capture(output_root,pid=None):
    win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,
                'Run this helper with 64-bit Python on the Windows game PC')
    output_root=output_root.resolve();output_root.mkdir(parents=True,exist_ok=True)
    report=dict(format='ps2-online-loaded-code-v1',expected_exe_sha256=EXPECTED_SHA256,
                local_reference_exe_sha256=win.EXPECTED_SHA256,
                captured_at_utc=datetime.now(timezone.utc).isoformat(),source_exe_sha256=None,
                source_build_verified=False,capture_complete=False,class_values_exported=False,
                class_layout_compatibility_verified=False,account_or_character_data_exported=False)
    stage='client_detection'
    with tempfile.TemporaryDirectory(prefix='online-code-',dir=output_root) as folder:
        staging=Path(folder)
        try:
            selected,exe=discover_client(pid)
            stage='executable_hash';report['source_exe_sha256']=win.file_sha(exe)
            win.require(report['source_exe_sha256']==EXPECTED_SHA256,
                        'Online build differs from the supplied executable; no process memory was read')
            report['source_build_verified']=True
            stage='disk_section_layout'
            with exe.open('rb') as source:
                header=source.read(4096);sections=selected_sections(header);disk_hashes={}
                for section in sections:
                    source.seek(section['raw_offset']);digest=hashlib.sha256();left=section['raw_size']
                    while left:
                        block=source.read(min(win.CHUNK,left))
                        win.require(bool(block),'On-disk section is truncated');digest.update(block);left-=len(block)
                    disk_hashes[section['index']]=digest.hexdigest()
            stage='open_readonly_process';reader=win.WindowsReader(selected,exe)
            try:
                stage='loaded_code_snapshot'
                snapshot=snapshot_sections(reader.read,reader.base,header,staging,disk_hashes)
                stage='final_executable_hash'
                win.require(win.file_sha(exe)==EXPECTED_SHA256,'On-disk executable changed during capture')
                report.update(snapshot);report['module_base']=reader.base;report['capture_complete']=True
            finally:reader.close()
        except (OSError,ValueError,subprocess.SubprocessError) as error:
            report['error_stage']=stage
            report['error']=str(error) if isinstance(error,ValueError) else type(error).__name__
            code=getattr(error,'winerror',None) or getattr(error,'errno',None)
            if type(code) is int:
                report['os_error_code']=code
                report['error']+=f' (OS error {code})'
        payload=(json.dumps(report,indent=2)+'\n').encode()
        files={'capture.json':dict(bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())}
        if report['capture_complete']:
            files.update({row['file']:dict(bytes=row['bytes'],sha256=row['sha256']) for row in report['sections']})
        manifest=dict(format=report['format'],capture_complete=report['capture_complete'],files=files)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        archive=output_root/f'online-loaded-code-{stamp}-{secrets.token_hex(8)}.zip'
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('capture.json',payload);z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
            if report['capture_complete']:
                for row in report['sections']:z.write(staging/row['file'],row['file'])
        with zipfile.ZipFile(archive) as z:win.require(z.testzip() is None,'Online code ZIP failed its integrity check')
    return prepare_uploads(archive),report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid',type=int)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'reports')
    args=parser.parse_args(argv)
    print('Reading only the verified online build\'s code and readonly constants.')
    try:uploads,report=capture(args.output,args.pid)
    except (OSError,ValueError,zipfile.BadZipFile) as error:
        print('Capture stopped: '+(str(error) if isinstance(error,ValueError) else type(error).__name__))
        return 1
    print('Upload every file INSIDE this folder separately:');print(uploads)
    print('Include all .part files and manifest.json if parts were created.')
    if report.get('error'):print(report['error'])
    try:subprocess.Popen(['explorer.exe',str(uploads)])
    except OSError:pass
    return 0 if report['capture_complete'] else 1


if __name__=='__main__':raise SystemExit(main())

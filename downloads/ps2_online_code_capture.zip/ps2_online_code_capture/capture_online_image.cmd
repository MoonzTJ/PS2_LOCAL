@echo off
cd /d "%~dp0"
py -3 capture_online_image.py
echo.
pause

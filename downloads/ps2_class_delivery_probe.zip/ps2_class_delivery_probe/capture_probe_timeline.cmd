@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_class_probe.py" --mode timeline
pause

"""Quiet local buttons for the offline test service; no game-memory access."""
import os
from pathlib import Path
import queue
import threading

from console_common import CONTROL_PORT, LOGIN_PORT, control_request


def request_action(action, request=control_request):
    if action not in ('capture_creator', 'capture_profiles', 'export_report'):
        raise ValueError('Unsupported local test action')
    ready = request(CONTROL_PORT, LOGIN_PORT)
    return request(CONTROL_PORT, LOGIN_PORT, action, instance=ready['instance_id'])


def main():
    if os.name != 'nt':
        print('These test controls require Windows.')
        return 1
    try:
        import tkinter as tk
    except ImportError:
        print('Tkinter is unavailable. Use creator/report in the server console.')
        return 1
    window = tk.Tk()
    window.title('MoonSol V31 test controls')
    window.geometry('420x345')
    window.resizable(False, False)
    status = tk.StringVar(value='Capture LocalVS before Play. Wait 70 seconds on the loading screen, capture again, then save the report.')
    tk.Label(window, text='LocalVS class and loading test', font=('Segoe UI', 14, 'bold')).pack(pady=(16, 10))
    tk.Label(window, textvariable=status, font=('Segoe UI', 10), wraplength=380,
             justify='left', anchor='w').pack(fill='x', padx=20, pady=(0, 10))
    results = queue.Queue()
    buttons = []

    def worker(action):
        try:
            results.put((action, request_action(action), None))
        except (OSError, ValueError) as exc:
            results.put((action, None, str(exc)))

    def clicked(action):
        for button in buttons:
            button.config(state='disabled')
        status.set('Requesting the local test service…')
        threading.Thread(target=worker, args=(action,), daemon=True).start()

    capture = tk.Button(window, text='Capture selected head / gender', font=('Segoe UI', 11),
                        command=lambda: clicked('capture_creator'))
    capture.pack(fill='x', padx=20, pady=4)
    profiles = tk.Button(window, text='Capture class / loading state', font=('Segoe UI', 11),
                         command=lambda: clicked('capture_profiles'))
    profiles.pack(fill='x', padx=20, pady=4)
    export = tk.Button(window, text='Save report ZIP', font=('Segoe UI', 11),
                       command=lambda: clicked('export_report'))
    export.pack(fill='x', padx=20, pady=4)
    buttons.extend((capture, profiles, export))
    tk.Label(window, text='Hold each selection for five seconds after capture.\nKeep the client launcher open.',
             font=('Segoe UI', 9)).pack(pady=10)

    def receive():
        try:
            action, result, error = results.get_nowait()
        except queue.Empty:
            window.after(100, receive)
            return
        if error:
            status.set('Request failed: '+error+' Check that V31 is running.')
        elif action == 'capture_creator':
            status.set(f"Capture #{result['capture_request']} queued. Return to the game and hold the selection for five seconds.")
        elif action == 'capture_profiles':
            status.set(f"Class/loading capture #{result['capture_request']} queued. Keep the game and launcher open for five seconds.")
        else:
            path = result['report_path']
            status.set('Saved '+Path(path).name+' in the server logs folder.')
            from tkinter import messagebox
            messagebox.showinfo('Report saved', path, parent=window)
        for button in buttons:
            button.config(state='normal')
        window.after(100, receive)

    window.after(100, receive)
    window.mainloop()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

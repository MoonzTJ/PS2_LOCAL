"""Local control channel, separate from the native game's UDP protocol."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import socket
import time

from login import candidate_server_list, load_environment_candidate, minimal_login_reply
from presets import candidate_character_list
from handoff import profile_fixture
from gateway_protocol import profile_fixture as gateway_fixture
from name_validation import profile_fixture as name_fixture
from player_world import profile_fixture as player_fixture
from world_confirmation import profile_fixture as confirmation_fixture
from zone_backend import dataset_fixture
from profile_catalog import MANIFEST_SHA256 as PROFILE_CATALOG_SHA256

HOST = "127.0.0.1"
SERVICE = "ps2-local-console-v31"
LOGIN_PORT = 20042
CONTROL_PORT = 20043
DEFAULT_GAME_DIR = r"C:\Users\Public\Daybreak Game Company\Installed Games\PlanetSide 2 Local"
CONFIG_NAME = "ClientConfig.local-console-v31.ini"


def profile_digest():
    # Identify the corrected initial login and slot payload alongside the
    # unchanged character, handoff and gateway profile.
    return hashlib.sha256(minimal_login_reply(load_environment_candidate())
                          + candidate_character_list(True, 1)
                          + candidate_server_list(True, 0) + profile_fixture() + gateway_fixture()
                          + name_fixture() + player_fixture() + confirmation_fixture()
                          + dataset_fixture() + PROFILE_CATALOG_SHA256.encode('ascii')).hexdigest()


def timestamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f")


def encode(row):
    return json.dumps(row, ensure_ascii=True, separators=(",", ":")).encode("ascii")


def control_request(control_port, login_port, command="health", *, instance=None, pid=None, timeout=0.6):
    nonce = secrets.token_hex(16)
    request = dict(service=SERVICE, command=command, nonce=nonce)
    if instance is not None:
        request["instance_id"] = instance
    if pid is not None:
        request["client_pid"] = pid
    expected_profile = profile_digest()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.connect((HOST, control_port))
        sock.settimeout(timeout)
        sock.send(encode(request))
        response = json.loads(sock.recv(16384))
    if not isinstance(response, dict) or not response.get("ok"):
        raise ValueError("Local server refused the control request")
    if (response.get("service") != SERVICE or response.get("nonce") != nonce
            or response.get("command") != command or response.get("login_host") != HOST
            or response.get("login_port") != login_port or response.get("profile_sha256") != expected_profile
            or response.get("listener_ready") is not True or response.get("gateway_transport_ready") is not True
            or response.get("gateway_host") != HOST or type(response.get("gateway_port")) is not int
            or not 1 <= response["gateway_port"] <= 65535):
        raise ValueError("Server identity, listener or reply profile does not match V31")
    identifier = response.get("instance_id")
    if not isinstance(identifier, str) or len(identifier) != 16 or any(c not in "0123456789abcdef" for c in identifier):
        raise ValueError("Invalid local server instance ID")
    if instance is not None and identifier != instance:
        raise ValueError("Server restarted; start this client again")
    return response


def wait_ready(control_port, login_port, wait_seconds=15):
    deadline = time.monotonic() + wait_seconds
    while True:
        try:
            return control_request(control_port, login_port)
        except (OSError, ValueError):
            if time.monotonic() >= deadline:
                raise ValueError("No matching V31 server is ready. Run start_local_server.cmd first.") from None
            time.sleep(0.1)


class EventLog:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open("x", encoding="utf-8")

    def event(self, event, **fields):
        row = dict(time=datetime.now(timezone.utc).isoformat(), event=event, **fields)
        self.stream.write(json.dumps(row, ensure_ascii=True) + "\n")
        self.stream.flush()
        print(event + ": " + json.dumps(fields, ensure_ascii=True), flush=True)

    def close(self):
        self.stream.close()

"""Minimal current-build SendSelfToClient experiment for known local presets.

The complete empty-collection layout is checked against captured decoder
988940. It is a synthetic player record, not a playable character inventory.
See PLAYER_WORLD_TRACE.md for native validation and unverified gameplay fields.
"""
from __future__ import annotations

import struct

from presets import PRESETS, SERVER_ID, string

EMPTY_BODY_BYTES = 796
NAME_LENGTH_OFFSET = 121
SEND_SELF_OPCODE = 3


def player_body(selection: dict) -> bytes:
    row = next((row for row in PRESETS
                if row['character_id'] == selection.get('character_guid')), None)
    if (row is None or selection.get('server_id') != SERVER_ID
            or selection.get('character_name') != row['name']):
        raise ValueError('Player record requires a matching local preset handoff')
    # Empty collection counts and zero scalar candidates throughout the
    # current decoder's complete layout. These bytes are generated locally;
    # no captured account, inventory or historical player packet is reused.
    body = bytearray(EMPTY_BODY_BYTES)
    struct.pack_into('<QQ', body, 0, row['character_id'], row['character_id'])
    # Native 966990: low two bits encode additional-byte count, value >> 2.
    body[16] = row['faction_id'] << 2
    # Two finite four-float vectors. Position is a placeholder, not a proven
    # Indar spawn; the second is an identity quaternion candidate.
    struct.pack_into('<4f', body, 77, 0.0, 0.0, 0.0, 1.0)
    struct.pack_into('<4f', body, 93, 0.0, 0.0, 0.0, 1.0)
    body[NAME_LENGTH_OFFSET:NAME_LENGTH_OFFSET + 4] = string(row['name'])
    return bytes(body)


def send_self_to_client(selection: dict) -> bytes:
    body = player_body(selection)
    # Native 9BAF50 validates opcode + counted body and exact outer length.
    return bytes([SEND_SELF_OPCODE]) + struct.pack('<I', len(body)) + body


def profile_fixture() -> bytes:
    return b'V26:synthetic-empty-inventory-player:' + b''.join(
        send_self_to_client(dict(character_guid=row['character_id'],
                                 character_name=row['name'], server_id=SERVER_ID))
        for row in PRESETS)

"""SOE transport and local dummy-login experiment; no playable zone server.

Python 3.10+, standard library only. Always binds to IPv4 loopback.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import secrets
import socket
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from transport import Receiver, Sender, application_members, read_group, unwrap, wrap
from presets import candidate_character_list, PRESETS, TARGET_WORLD, SERVER_NAME, ACCOUNT_CHARACTER_SLOTS
from login import LocalLogin, load_environment_candidate, validate_environment_candidate, candidate_server_list
from test_console import Console, ConsoleInput

HOST = "127.0.0.1"
CONFIG_NAME = "ClientConfig.local-test-v13.ini"
OP_NAMES = {
    1: "SessionRequest", 2: "SessionResponse", 3: "MultiPacket",
    5: "Disconnect", 6: "Heartbeat", 7: "NetStatusRequest",
    8: "NetStatusResponse", 9: "ReliableData", 13: "ReliableDataFragment",
    17: "Ack", 21: "AckAll", 29: "UnknownSender", 30: "Remap",
}


def parse_request(packet: bytes) -> dict:
    if len(packet) < 15:
        raise ValueError("SessionRequest is shorter than 15 bytes")
    opcode, version, session_id, udp_length = struct.unpack_from(">HIII", packet)
    if opcode != 1:
        raise ValueError("Not a SessionRequest")
    if packet[-1:] != b"\0" or b"\0" in packet[14:-1]:
        raise ValueError("Application protocol must have one final null terminator")
    try:
        application = packet[14:-1].decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("Application protocol is not ASCII") from exc
    if not application or len(application) > 128 or not application.isprintable():
        raise ValueError("Invalid application protocol descriptor")
    if not 21 <= udp_length <= 65507:
        raise ValueError("Advertised UDP size is outside supported bounds")
    return dict(protocol_version=version, session_id=session_id,
                udp_length=udp_length, application_protocol=application)


def make_response(request: dict, seed: int) -> bytes:
    if request["protocol_version"] != 3:
        raise ValueError("Only documented SOE transport version 3 is implemented")
    # Network byte order. CRC length 2, compression false, unknown byte 0.
    # SessionResponse itself has no CRC; subsequent contextual packets do.
    return struct.pack(">HIIBBBII", 2, request["session_id"], seed,
                       2, 0, 0, min(512, request["udp_length"]), 3)


def local_config(original: bytes, port: int, diagnostic_logging: bool = False) -> bytes:
    """Replace root Server only; preserve other bytes and section settings."""
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    data = original[len(bom):]
    ending = b"\r\n" if b"\r\n" in data else b"\n"
    lines = data.splitlines(keepends=True)
    in_root, found = True, False
    for i, line in enumerate(lines):
        if line.lstrip().startswith(b"["):
            in_root = False
        if in_root and re.match(rb"(?i)^[ \t]*Server[ \t]*=", line):
            suffix = b"\r\n" if line.endswith(b"\r\n") else (b"\n" if line.endswith(b"\n") else b"")
            lines[i] = f"Server={HOST}:{port}".encode("ascii") + suffix
            found = True
    if not found:
        lines.insert(0, f"Server={HOST}:{port}".encode("ascii") + ending)
    result = bom + b"".join(lines)
    if diagnostic_logging:
        result = logging_config(result)
    return result


def logging_config(data: bytes) -> bytes:
    """Set logging only in the separate test config, preserving unrelated bytes."""
    ending = b"\r\n" if b"\r\n" in data else b"\n"
    settings = {b"address": b"Address=", b"localdirectory": b"LocalDirectory=./Logs",
                b"fileloglevel": b"FileLogLevel=5", b"localloglevel": b"LocalLogLevel=5"}
    out, seen = [], set()
    active = found = False
    for line in data.splitlines(keepends=True):
        stripped = line.strip()
        if stripped.startswith(b"["):
            if active:
                for key, value in settings.items():
                    if key not in seen:
                        if out and not out[-1].endswith(b"\n"):
                            out[-1] += ending
                        out.append(value + ending)
            active = stripped.lower() == b"[logging]"
            if active:
                found = True
                seen = set()
        if active and b"=" in stripped:
            key = stripped.split(b"=", 1)[0].strip().lower()
            if key in settings:
                suffix = b"\r\n" if line.endswith(b"\r\n") else (b"\n" if line.endswith(b"\n") else b"")
                line = settings[key] + suffix
                seen.add(key)
        out.append(line)
    if active:
        for key, value in settings.items():
            if key not in seen:
                if out and not out[-1].endswith(b"\n"):
                    out[-1] += ending
                out.append(value + ending)
    if not found:
        if out and not out[-1].endswith(b"\n"):
            out[-1] += ending
        out.append(b"[Logging]" + ending)
        out.extend(value + ending for value in settings.values())
    return b"".join(out)


def client_status(game_dir: Path, started: float) -> dict:
    """Read only the small status marker; never copy arbitrary XML values to logs."""
    path = game_dir / "ClientStatus.xml"
    if not path.is_file():
        return dict(available=False)
    stat = path.stat()
    if stat.st_size > 4096:
        return dict(available=False, reason="status file exceeds diagnostic limit")
    try:
        root = ET.fromstring(path.read_bytes())
    except ET.ParseError:
        return dict(available=False, reason="status file is not complete XML")
    name, number = root.get("statusName", ""), root.get("status", "")
    if root.tag != "Run" or not re.fullmatch(r"cClientRunState[A-Za-z0-9_]{1,100}", name) or not re.fullmatch(r"[0-9]{1,10}", number):
        return dict(available=False, reason="unrecognized status marker")
    return dict(available=True, status_name=name, status=int(number),
                file_modified_during_test=stat.st_mtime >= started)


def prepare(game_dir: Path, port: int, diagnostic_logging: bool = False, ui_diagnostics: bool = False) -> Path:
    for name in ("PlanetSide2_x64.exe", "ClientConfig.ini"):
        if not (game_dir / name).is_file():
            raise ValueError(f"Missing {name} in {game_dir}")
    source = game_dir / "ClientConfig.ini"
    target = game_dir / CONFIG_NAME
    wanted = local_config(source.read_bytes(), port, diagnostic_logging)
    if ui_diagnostics:
        from ui_diagnostics import overlay_config
        wanted = overlay_config(wanted)
    if target.exists():
        if target.read_bytes() != wanted:
            raise ValueError(f"{target} already exists with different contents. Rename it before retrying.")
    else:
        # Exclusive creation protects existing files even if another process creates it.
        with target.open("xb") as out:
            out.write(wanted)
    return target


def launch(game_dir: Path) -> subprocess.Popen:
    if os.name != "nt":
        raise ValueError("Launching the game is supported on Windows only")
    return subprocess.Popen([
        str(game_dir / "PlanetSide2_x64.exe"),
        f"inifile={CONFIG_NAME}", "sessionid=0", "Internationalization:Locale=en_US",
    ], cwd=str(game_dir))


class Probe:
    def __init__(self, log_path: Path, port: int = 20042, capture_payloads: bool = False,
                 enable_login: bool = False, push_empty_lists: bool = False,
                 local_server_list: bool = False, environment_payload: bytes = b"",
                 preset_characters: bool = False, character_record_status: int = 0, server_state: int = 0,
                 character_handoff=None, allowed_protocol=None, application_factory=None):
        if server_state not in (0,1) or (server_state and not local_server_list):
            raise ValueError("Nonzero server state candidate requires a local server list")
        if character_record_status not in (0, 1) or (character_record_status and not preset_characters):
            raise ValueError("Status 1 candidate requires the preset experiment; only statuses 0 and 1 are supported")
        if preset_characters and not (enable_login and local_server_list and environment_payload):
            raise ValueError("Preset experiment requires login, local server, and environment experiments")
        if environment_payload:
            if not (enable_login and local_server_list):
                raise ValueError("Environment experiment requires dummy login and local server listing")
            validate_environment_candidate(environment_payload)
        if local_server_list and not enable_login:
            raise ValueError("Local server listing requires dummy login")
        if push_empty_lists and not enable_login:
            raise ValueError("List delivery experiment requires dummy login mode")
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.log = None
        try:
            self.sock.bind((HOST, port))
            self.sock.settimeout(0.25)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            self.log = log_path.open("x", encoding="utf-8")
        except BaseException:
            self.sock.close()
            raise
        self.address = self.sock.getsockname()
        self.log_path = log_path.resolve()
        self.last_manual_refresh = None
        self.counts = Counter()
        self.sessions = {}
        self.peers = {}
        self.requests = self.responses = self.followups = 0
        self.acks = self.messages = self.crc_failures = 0
        self.reply_count = self.server_retries = self.server_acks = 0
        self.enable_login = enable_login
        self.push_empty_lists = push_empty_lists
        self.local_server_list = local_server_list
        self.environment_payload = environment_payload
        self.preset_characters = preset_characters
        self.character_record_status = character_record_status
        self.server_state = server_state
        self.character_handoff = character_handoff
        self.allowed_protocol = allowed_protocol
        self.application_factory = application_factory
        # Login mode logs only parsed metadata, even if raw capture was requested.
        self.capture_payloads = capture_payloads and not enable_login
        self.captured_messages = self.captured_rejections = 0
        self.event("listening", host=HOST, port=self.address[1],
                   version="0.13", server_state_candidate=server_state,
                   character_record_status_candidate=character_record_status,
                   preset_characters_experiment=preset_characters,
                   configured_characters=len(PRESETS) if preset_characters else 0,
                   requested_world=TARGET_WORLD, world_loading_implemented=False,
                   capture_local_payloads=self.capture_payloads,
                   login_reply_experiment=enable_login,
                   push_empty_lists_experiment=push_empty_lists,
                   local_server_list_experiment=local_server_list,
                   environment_payload_experiment=bool(environment_payload),
                   environment_payload_bytes=len(environment_payload),
                   scope="transport + optional historical login reply candidates; no zone server")

    def event(self, event: str, **fields):
        row = dict(time=datetime.now(timezone.utc).isoformat(), event=event, **fields)
        self.log.write(json.dumps(row, ensure_ascii=True) + "\n")
        self.log.flush()
        if event not in ("packet", "application_data", "rejected_packet_capture"):
            # Log packet samples to the file; keep the console readable.
            print(event + ": " + json.dumps(fields, ensure_ascii=True), flush=True)

    def contextual(self, opcode: int, body: bytes, peer: tuple, state: dict, depth: int = 0):
        if opcode == 3:
            if depth >= 2:
                raise ValueError("Nested MultiPacket exceeds supported depth")
            for child in read_group(body, transport_packets=True):
                child_op = struct.unpack_from(">H", child)[0]
                self.contextual(child_op, child[2:], peer, state, depth + 1)
        elif opcode in (9, 13):
            if len(body) < 3:
                raise ValueError("Reliable data is shorter than sequence + data")
            sequence = struct.unpack_from(">H", body)[0]
            status, messages = state["receiver"].accept(opcode, sequence, body[2:])
            if status == "outside_window":
                self.event("sequence_rejected", sequence=sequence, expected=state["receiver"].expected)
                return
            ack = wrap(17, struct.pack(">H", sequence), state["seed"])
            self.sock.sendto(ack, peer)
            self.acks += 1
            if self.acks <= 10 or self.acks % 100 == 0:
                self.event("ack_sent", sequence=sequence, receive_status=status,
                           bytes=len(ack), wire_hex=ack.hex())
            for message in messages:
                for member in application_members(message):
                    self.messages += 1
                    application = state.get("application") or state.get("login")
                    if application is not None:
                        try:
                            metadata, replies = application.handle(member)
                        except ValueError as exc:
                            self.event("application_data_rejected" if state.get("application") else "login_data_rejected",
                                       bytes=len(member), reason=str(exc))
                            continue
                        self.event("application_packet_decoded", **metadata)
                        for name, plain in replies:
                            self.send_candidate(peer, state, name, plain)
                        continue
                    fields = dict(message_number=self.messages, bytes=len(member),
                                  application_protocol=state["application_protocol"],
                                  interpretation="raw application buffer; encryption not decoded")
                    if self.capture_payloads and self.captured_messages < 16:
                        self.captured_messages += 1
                        fields.update(payload_hex=member[:4096].hex(), truncated=len(member) > 4096)
                    self.event("application_data", **fields)
                    print(f"Received application buffer {self.messages}: {len(member)} bytes", flush=True)
        elif opcode == 6:
            if body:
                raise ValueError("Unexpected heartbeat payload")
            self.sock.sendto(wrap(6, b"", state["seed"]), peer)
            self.event("heartbeat_replied")
        elif opcode == 5:
            if len(body) < 6:
                raise ValueError("Truncated disconnect")
            session_id, reason = struct.unpack_from(">IH", body)
            self.event("client_disconnect", session_id=session_id, reason=reason)
            self.peers.pop(peer, None)
        elif opcode in (17, 21):
            if len(body) != 2:
                raise ValueError("Acknowledgment requires a two-byte sequence")
            sequence = struct.unpack_from(">H", body)[0]
            count = state["sender"].acknowledge(sequence, cumulative=opcode == 21) if "sender" in state else 0
            self.server_acks += count
            self.event("client_ack", opcode=opcode, sequence=sequence,
                       acknowledged_server_packets=count)
        else:
            self.event("unhandled_transport_packet", opcode=opcode, bytes=len(body))

    def poll(self):
        try:
            packet, peer = self.sock.recvfrom(65535)
        except socket.timeout:
            return
        opcode = struct.unpack_from(">H", packet)[0] if len(packet) >= 2 else None
        if peer[0] != HOST:
            return
        self.counts[opcode] += 1
        # Metadata for all traffic. Optional application samples are bounded below.
        if self.counts[opcode] <= 10 or self.counts[opcode] % 100 == 0:
            self.event("packet", peer_port=peer[1], bytes=len(packet),
                       opcode=opcode, name=OP_NAMES.get(opcode, "unrecognized"),
                       count=self.counts[opcode])
        if opcode == 1:
            self.requests += 1
            try:
                request = parse_request(packet)
            except ValueError as exc:
                self.event("request_rejected", reason=str(exc))
                return
            self.event("session_request", **request)
            if self.allowed_protocol is not None and request["application_protocol"] != self.allowed_protocol:
                self.event("request_rejected", reason="Unsupported application protocol")
                return
            if request["protocol_version"] != 3:
                self.event("unsupported_version", version=request["protocol_version"])
                return
            key = (peer, request["session_id"], request["application_protocol"])
            if key not in self.sessions and len(self.sessions) >= 32:
                self.event("request_rejected", reason="Transport session limit reached")
                return
            seed = self.sessions.setdefault(key, secrets.randbits(32))
            if peer not in self.peers or self.peers[peer]["key"] != key:
                self.peers[peer] = dict(key=key, seed=seed, receiver=Receiver(),
                                        udp_length=min(512, request["udp_length"]),
                                        application_protocol=request["application_protocol"],
                                        sender=Sender(seed, min(512, request["udp_length"])),
                                        login=LocalLogin(self.push_empty_lists, self.local_server_list, self.environment_payload, self.preset_characters, self.character_record_status, self.server_state, self.character_handoff) if self.enable_login and request["application_protocol"] == "LoginUdp_18" else None)
                if self.application_factory is not None:
                    self.peers[peer]["application"] = self.application_factory(peer, request)
            response = make_response(request, seed)
            self.sock.sendto(response, peer)
            self.responses += 1
            self.event("session_response_sent", session_id=request["session_id"],
                       bytes=len(response), crc_seed=seed, crc_length=2, compression=False)
        elif peer in self.peers:
            self.followups += 1
            if self.followups == 1:
                self.event("followup_received", opcode=opcode,
                           note="Client sent more data; login compatibility is still unproven")
            state = self.peers[peer]
            try:
                if len(packet) > state["udp_length"]:
                    raise ValueError("Datagram exceeds negotiated receive size")
                op, body = unwrap(packet, state["seed"])
                self.contextual(op, body, peer, state)
            except ValueError as exc:
                if str(exc) == "CRC mismatch":
                    self.crc_failures += 1
                self.event("transport_rejected", opcode=opcode, reason=str(exc))
                if self.capture_payloads and self.captured_rejections < 4:
                    self.captured_rejections += 1
                    self.event("rejected_packet_capture", wire_hex=packet[:512].hex(),
                               truncated=len(packet) > 512)

    def send_candidate(self, peer, state, name, plain):
        application = state.get("application") or state["login"]
        encrypted = application.encrypt_reply(plain)
        packets = state["sender"].queue(encrypted, time.monotonic())
        for sequence, wire in packets:
            self.sock.sendto(wire, peer)
        self.reply_count += 1
        self.event("candidate_reply_sent", name=name,
                   plain_bytes=len(plain), transport_packets=len(packets),
                   sequences=[seq for seq, _ in packets],
                   schema=("captured gateway crypto route and zone decoder validated; live acceptance unverified"
                           if name in ("GatewayLoginReply", "IndarZoneDetails") else
                           "captured binary + XML decoder validated; V19 live handoff confirmed"
                           if name == "CharacterLoginReply" else
                           "captured full login tunnel/API/name UI callback validated; Windows name check pending"
                           if name == "CharacterNameValidationReply" else
                           "captured native LoginReply validated; V22 slots and V23 faction clicks live confirmed"
                           if name == "LoginReply" else "existing V18.1 reply profile"))
        return len(packets)

    def console_status(self):
        accepted = sum(bool(state.get("login") and state["login"].accepted_dummy)
                       for state in self.peers.values())
        pending = sum(len(state["sender"].pending) for state in self.peers.values())
        return dict(server_state_candidate=self.server_state, character_record_status_candidate=self.character_record_status,
                    configured_presets=list(PRESETS) if self.preset_characters else [],
                    native_preset_recognition="unverified", requested_world=TARGET_WORLD,
                    server_label=SERVER_NAME if self.local_server_list else None,
                    configured_character_slots=ACCOUNT_CHARACTER_SLOTS if self.environment_payload else None,
                    configured_free_slots=ACCOUNT_CHARACTER_SLOTS-len(PRESETS) if self.preset_characters else None,
                    native_slot_capacity="unverified", character_creation_saving_implemented=False,
                    accepted_dummy_sessions=accepted, pending_reliable_packets=pending,
                    application_buffers=self.messages, candidate_replies=self.reply_count,
                    server_packets_acknowledged=self.server_acks, crc_failures=self.crc_failures,
                    server_packet_retries=self.server_retries, native_login_complete="unverified",
                    capabilities=dict(list_refresh=True, native_faction_selection=False,
                                      map_load=False, zone_service=False))

    def refresh_lists(self):
        eligible = [(peer, state) for peer, state in self.peers.items()
                    if state.get("login") and state["login"].accepted_dummy]
        now = time.monotonic()
        if (len(eligible) != 1 or eligible[0][1]["sender"].pending or
                (self.last_manual_refresh is not None and now - self.last_manual_refresh < 5)):
            raise ValueError("Manual list refresh is not ready")
        peer, state = eligible[0]
        self.last_manual_refresh = now
        packets = self.send_candidate(peer, state, "CharacterSelectInfoReply",
                                      candidate_character_list(self.preset_characters, self.character_record_status))
        packets += self.send_candidate(peer, state, "ServerListReply",
                                       candidate_server_list(self.local_server_list, self.server_state))
        return dict(candidate_replies_sent=2, transport_packets_sent=packets)

    def tick(self):
        now = time.monotonic()
        for peer, state in self.peers.items():
            packets, expired = state["sender"].retries(now)
            for sequence, wire in packets:
                self.sock.sendto(wire, peer)
                self.server_retries += 1
                self.event("server_packet_retry", sequence=sequence, bytes=len(wire))
            for sequence in expired:
                self.event("server_packet_expired", sequence=sequence,
                           note="No transport acknowledgment within the bounded retry schedule")

    def close(self):
        self.event("summary", packets=sum(self.counts.values()),
                   session_requests=self.requests, session_responses_sent=self.responses,
                   followup_packets=self.followups,
                   acknowledgments_sent=self.acks, application_buffers=self.messages,
                   crc_failures=self.crc_failures,
                   candidate_application_replies=self.reply_count,
                   server_packets_acknowledged=self.server_acks,
                   server_packet_retries=self.server_retries,
                   opcode_counts={str(k): v for k, v in self.counts.items()})
        self.sock.close()
        self.log.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-dir", type=Path)
    parser.add_argument("--prompt-game-dir", action="store_true")
    parser.add_argument("--serve-only", action="store_true")
    parser.add_argument("--console", action="store_true",
                        help="Enable commands in this terminal; native faction/map control is unavailable")
    parser.add_argument("--ui-diagnostics", action="store_true",
                        help="Use a separate display-only UI asset overlay in the copied Phase 7 game folder")
    parser.add_argument("--login-reply-experiment", action="store_true",
                        help="Decode LoginUdp_18 dummy requests and send historical reply candidates")
    parser.add_argument("--push-empty-lists-experiment", action="store_true",
                        help="Send candidate empty character/server lists immediately after the login reply")
    parser.add_argument("--local-server-list-experiment", action="store_true",
                        help="Replace the empty server list with one historical candidate local listing")
    parser.add_argument("--environment-payload-experiment", action="store_true",
                        help="Add the bundled historical environment candidate with redirected URL fields")
    parser.add_argument("--preset-characters-experiment", action="store_true",
                        help="Send four synthetic characters in an unverified historical record layout")
    parser.add_argument("--character-record-status", type=int, choices=(0,1), default=0,
                        help="Unverified outer character status candidate; Phase 9 used 0")
    parser.add_argument("--server-state", type=int, choices=(0,1), default=0,
                        help="Server flags candidate; V13 tests 0 against the V12 value 1")
    parser.add_argument("--capture-local-payloads", action="store_true",
                        help="Save at most 16 application buffers (4096 bytes each) from the local test")
    parser.add_argument("--port", type=int, default=20042)
    parser.add_argument("--seconds", type=float, default=120)
    args = parser.parse_args()
    if args.server_state and not args.local_server_list_experiment:
        parser.error("Nonzero server state candidate requires --local-server-list-experiment")
    if args.character_record_status and not args.preset_characters_experiment:
        parser.error("Status 1 candidate requires --preset-characters-experiment")
    if args.preset_characters_experiment and not (args.login_reply_experiment and args.push_empty_lists_experiment and args.local_server_list_experiment and args.environment_payload_experiment):
        parser.error("Preset experiment requires login, pushed-list, local-server, and environment experiments")
    if args.ui_diagnostics and args.serve_only:
        parser.error("UI diagnostics require launching the copied client")
    if args.environment_payload_experiment and not (args.login_reply_experiment and args.push_empty_lists_experiment and args.local_server_list_experiment):
        parser.error("--environment-payload-experiment requires login, pushed-list, and local-server experiments")
    environment_payload = b""
    if args.environment_payload_experiment:
        try:
            environment_payload = load_environment_candidate()
        except (OSError, ValueError) as exc:
            parser.error(str(exc))
    if args.local_server_list_experiment and not (args.login_reply_experiment and args.push_empty_lists_experiment):
        parser.error("--local-server-list-experiment requires both login and pushed-list experiments")
    if args.push_empty_lists_experiment and not args.login_reply_experiment:
        parser.error("--push-empty-lists-experiment requires --login-reply-experiment")
    if not 1 <= args.port <= 65535 or not 0 < args.seconds <= 3600:
        parser.error("Port must be 1..65535; duration must be greater than 0 and at most 3600 seconds")
    print("PS2 LOCAL CONNECTION TEST 0.13 — four preset characters, no playable world.")
    print("Loopback service only. Internet disconnection is optional; other game services may use it.")
    if args.login_reply_experiment:
        print("Login mode accepts only sessionid=0 and saves parsed metadata without fingerprint values.")
        print("Reply layouts are experimental; character/server metadata contains no playable zone.")
        if args.push_empty_lists_experiment:
            print("Sending candidate lists after login without waiting for list requests.")
        if args.local_server_list_experiment:
            print(f"Advertising {SERVER_NAME}, server state candidate {args.server_state}; wire-to-native mapping is unverified.")
        if args.preset_characters_experiment:
            print("Configured LocalVS, LocalNC, LocalTR, LocalNSO. Native recognition is unverified; appearance IDs are unspecified.")
            print(f"Outer character-record status candidate: {args.character_record_status}; current wire-to-native mapping is unverified.")
        if args.environment_payload_experiment:
            print("Sending 14 base slots and four empire permissions in the 7333-byte login payload; environment URLs point to loopback.")
            print("Current client compatibility and full binary schema are unverified.")
    elif args.capture_local_payloads:
        print("This test log includes bounded local packet data; the launch uses sessionid=0.")
    game_dir = args.game_dir
    if not args.serve_only:
        if os.name != "nt":
            parser.error("Use Windows to launch the client, or --serve-only to test the listener")
        if args.prompt_game_dir and game_dir is None:
            game_dir = Path(input("Folder containing PlanetSide2_x64.exe: ").strip().strip('"'))
        if game_dir is None:
            parser.error("Supply --game-dir or --prompt-game-dir")
        game_dir = game_dir.expanduser().resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    log_path = Path(__file__).resolve().parent / "logs" / f"local-test-{stamp}-{secrets.token_hex(2)}.jsonl"
    probe = None
    try:
        # Bind before creating configuration or launching the game.
        probe = Probe(log_path, args.port, args.capture_local_payloads, args.login_reply_experiment,
                      args.push_empty_lists_experiment, args.local_server_list_experiment, environment_payload, args.preset_characters_experiment, args.character_record_status, args.server_state)
        started = time.time()
        if not args.serve_only:
            if args.ui_diagnostics:
                from ui_diagnostics import prepare_overlay
                print("Preparing separate D12 UI assets; use only the copied offline game folder.")
                overlay, details = prepare_overlay(game_dir)
                probe.event("ui_overlay_verified", patched_gfx_sha256=details["patched_gfx_sha256"],
                            patched_pack_sha256=details["patched_pack_sha256"], native_validation="pending")
                print(f"Verified {overlay}. Look for the D12 native rows panel on character selection; [D08] remains on faction names.")
            target = prepare(game_dir, args.port, diagnostic_logging=True, ui_diagnostics=args.ui_diagnostics)
            print(f"Created/verified {target}; original ClientConfig.ini retained.")
            game = launch(game_dir)
            probe.event("client_started", pid=game.pid)
        print(f"Log: {log_path}")
        print(f"Listening for {args.seconds:g} seconds. Ctrl+C stops the test; close the game yourself.")
        console = Console(probe) if args.console else None
        console_input = ConsoleInput() if args.console else None
        if console:
            console.execute("help")
            print("Type commands in this CMD window, then press Enter. Return to the game to observe results.")
        deadline = time.monotonic() + args.seconds
        stop_requested = False
        while time.monotonic() < deadline:
            probe.poll()
            probe.tick()
            if console:
                for line in console_input.poll():
                    if console.execute(line).get("stop"):
                        stop_requested = True
                        break
            if stop_requested:
                break
        if not args.serve_only:
            probe.event("client_status_snapshot", **client_status(game_dir, started))
            print("After closing the game, send fresh game Logs files if any were created.")
        if probe.responses == 0:
            print("No supported session request answered. Check the client window and this log.")
        elif probe.followups == 0:
            print("A session response was sent, but no follow-up was observed. Acceptance is unproven.")
        else:
            print(f"Received {probe.messages} application buffers; sent {probe.acks} acknowledgments.")
            if args.login_reply_experiment:
                print(f"Sent {probe.reply_count} candidate application replies; {probe.server_acks} server packets acknowledged.")
            print("Send the new JSONL log and describe any change in the game window.")
    except KeyboardInterrupt:
        print("Test stopped. Close the game window if it is still open.")
    except (OSError, ValueError) as exc:
        print(f"Test failed: {exc}", file=sys.stderr)
        return 1
    finally:
        if probe is not None:
            probe.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

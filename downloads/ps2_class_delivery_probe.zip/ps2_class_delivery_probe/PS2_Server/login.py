"""Synthetic local LoginUdp_18 replies checked against the captured decoder.

V22 slots and V23 faction interaction are live-confirmed; V24 adds name checks.
"""
from presets import candidate_character_list, SERVER_ID, SERVER_NAME
from handoff import parse_character_login
from name_validation import name_check_reply
import base64
import hashlib
from pathlib import Path
import re
import struct

# Public fixed protocol key from psemu/ps2-emu, not a user's account credential.
LOGIN_KEY = base64.b64decode("F70IaxuU8C/w7FPXY1ibXw==")


class RC4:
    def __init__(self, key: bytes):
        if not key:
            raise ValueError("Empty cipher key")
        self.state = list(range(256))
        j = 0
        for i in range(256):
            j = (j + self.state[i] + key[i % len(key)]) & 255
            self.state[i], self.state[j] = self.state[j], self.state[i]
        self.i = self.j = 0

    def transform(self, data: bytes) -> bytes:
        out = bytearray()
        s = self.state
        for value in data:
            self.i = (self.i + 1) & 255
            self.j = (self.j + s[self.i]) & 255
            s[self.i], s[self.j] = s[self.j], s[self.i]
            out.append(value ^ s[(s[self.i] + s[self.j]) & 255])
        return bytes(out)


def parse_dummy_login(data: bytes) -> dict:
    """Validate request shape; return metadata without credential/fingerprint values."""
    if not data or data[0] != 1:
        raise ValueError("Not a login request")
    offset = 1
    values = []
    for _ in range(2):
        if offset + 4 > len(data):
            raise ValueError("Truncated login string length")
        size = struct.unpack_from("<I", data, offset)[0]
        offset += 4
        if size > 4096 or offset + size > len(data):
            raise ValueError("Login string exceeds supported bounds")
        value = data[offset:offset + size]
        try:
            value.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("Login string is not UTF-8") from exc
        values.append(value)
        offset += size
    if len(data) - offset != 16:
        raise ValueError("Login request does not match the observed 16-byte tail")
    if values[0] != b"0":
        raise ValueError("Refusing a non-dummy login session")
    return dict(session_is_dummy_zero=True, fingerprint_bytes=len(values[1]),
                reserved_fields_all_zero=not any(struct.unpack_from("<4I", data, offset)))


ENVIRONMENT_SHA256 = "41fd7e4a3aedcf522873b19d56bbd10e9dc501a2c334a1093ff0427f90f17e75"


def validate_environment_candidate(data: bytes) -> bytes:
    """Accept the bundled complete payload: 14 base slots, four empire permissions, 58 loopback URLs."""
    if len(data) != 7333 or hashlib.sha256(data).hexdigest() != ENVIRONMENT_SHA256:
        raise ValueError("Environment candidate is missing, changed, or unsupported")
    fields = list(re.finditer(rb"https?://", data))
    if len(fields) != 58:
        raise ValueError("Unexpected environment URL count")
    prefix = b"http://127.0.0.1:9/"
    for match in fields:
        pos = match.start()
        if pos < 4:
            raise ValueError("Invalid environment URL field")
        size = struct.unpack_from("<I", data, pos - 4)[0]
        if size < len(prefix) or pos + size > len(data):
            raise ValueError("Invalid environment URL length")
        if data[pos:pos + size] != prefix + b"/" * (size - len(prefix)):
            raise ValueError("Environment URL is not the expected loopback placeholder")
    return data


def load_environment_candidate() -> bytes:
    return validate_environment_candidate(
        Path(__file__).with_name("environment_candidate.bin").read_bytes())


def minimal_login_reply(payload: bytes = b"") -> bytes:
    # Captured LoginUdp_18 decoder RVA 1744190: the old reply omitted
    # ResultCode, AccountFeatures, ErrorDetails and IpCountryCode. Its
    # environment bytes were read as Namespace and the callback never ran.
    return (b"\x02\x01" + struct.pack("<II", 1, 0) + b"\0\0"
            + struct.pack("<III", 0, 0, len(payload)) + payload
            + struct.pack("<II", 0, 0))


def candidate_server_list(one_local_server: bool = False, server_state: int = 0) -> bytes:
    """Captured server-list decoder: uint64 ID, byte state and full entry tail.

    Native RVAs 1746440/17439E0 accept this layout. Live registration and
    character-to-world progression still require the Windows client test.
    """
    if server_state not in (0, 1):
        raise ValueError("Server state candidate must be 0 or 1")
    if not one_local_server:
        return b"\x0e" + struct.pack("<I", 0)

    def string(value: str) -> bytes:
        data = value.encode("utf-8")
        return struct.pack("<I", len(data)) + data

    # Based on psemu's serverlist.json. Ping is metadata only; no ping/zone service.
    server_info = '<ServerInfo Region="CharacterCreate.RegionUs" Subregion="UI.SubregionUSEast" IsRecommended="1" />'
    population = ('<Population ServerCapacity="0" PingAddress="127.0.0.1:60000">'
                  '<factionlist IsList="1">'
                  '<faction Id="1" Percent="0" TargetPopPct="0" RewardBuff="52" XPBuff="52" PercentAvg="0"/>'
                  '<faction Id="2" Percent="0" TargetPopPct="1" RewardBuff="0" XPBuff="0" PercentAvg="0"/>'
                  '<faction Id="3" Percent="0" TargetPopPct="1" RewardBuff="0" XPBuff="0" PercentAvg="1"/>'
                  '</factionlist></Population>')
    entry = (struct.pack("<QB", SERVER_ID, server_state) + string(SERVER_NAME) + struct.pack("<I", 0)
             + string("MoonSol local server") + struct.pack("<II", 0, 0)
             + string(server_info) + struct.pack("<I", 1) + string(population)
             + string("") + b"\x00\x01")  # AccessExpression, IsDbProcessor, AllowedAccess.
    return b"\x0e" + struct.pack("<I", 1) + entry


class LocalLogin:
    def __init__(self, push_empty_lists: bool = False, local_server_list: bool = False,
                 environment_payload: bytes = b"", preset_characters: bool = False, character_record_status: int = 0, server_state: int = 0,
                 character_handoff=None):
        if server_state not in (0,1) or (server_state and not local_server_list):
            raise ValueError("Nonzero server state candidate requires a local server list")
        if character_record_status not in (0, 1):
            raise ValueError("Character record status candidate must be 0 or 1")
        if environment_payload:
            validate_environment_candidate(environment_payload)
        self.incoming = RC4(LOGIN_KEY)
        self.outgoing = RC4(LOGIN_KEY)
        self.accepted_dummy = False
        self.push_empty_lists = push_empty_lists
        self.local_server_list = local_server_list
        self.environment_payload = environment_payload
        self.preset_characters = preset_characters
        self.character_record_status = character_record_status
        self.server_state = server_state
        self.character_handoff = character_handoff

    def handle(self, encrypted: bytes) -> tuple[dict, list[tuple[str, bytes]]]:
        if len(encrypted) > 1 and encrypted[0] == 0:
            encrypted = encrypted[1:]
        data = self.incoming.transform(encrypted)
        if not data:
            raise ValueError("Empty decrypted application buffer")
        opcode = data[0]
        metadata = dict(opcode=opcode, decoded_bytes=len(data))
        replies = []
        if opcode == 1:
            if self.accepted_dummy:
                raise ValueError("Repeated application-level login is unsupported")
            metadata.update(parse_dummy_login(data))
            self.accepted_dummy = True
            metadata["name"] = "LoginRequest"
            replies.append(("LoginReply", minimal_login_reply(self.environment_payload)))
            if self.push_empty_lists:
                # Controlled delivery-order experiment, not verified LoginUdp_18 behavior.
                replies.extend([
                    ("CharacterSelectInfoReply", candidate_character_list(self.preset_characters, self.character_record_status)),
                    ("ServerListReply", candidate_server_list(self.local_server_list, self.server_state)),
                ])
        elif not self.accepted_dummy:
            raise ValueError("Application data received before a valid dummy login")
        elif opcode == 11 and len(data) == 1:
            metadata["name"] = "CharacterSelectInfoRequest"
            # Character fields were observed correctly in the V17 live test.
            replies.append(("CharacterSelectInfoReply", candidate_character_list(self.preset_characters, self.character_record_status)))
        elif opcode == 13 and len(data) == 1:
            metadata["name"] = "ServerListRequest"
            # Captured-build list layout; no character-to-zone endpoint is served.
            replies.append(("ServerListReply", candidate_server_list(self.local_server_list, self.server_state)))
        elif opcode == 7 and self.character_handoff is not None:
            selection = parse_character_login(data)
            plain = self.character_handoff(selection)
            metadata.update(selection, name="CharacterLoginRequest", local_selection_validated=True)
            replies.append(("CharacterLoginReply", plain))
        elif opcode == 16:
            checked = name_check_reply(data)
            if checked is None:
                metadata.update(name="UnhandledApplicationPacket",
                                historical_candidate_name="TunnelAppPacketClientToServer",
                                inner_opcode=data[13])
            else:
                details, plain = checked
                metadata.update(details)
                replies.append(("CharacterNameValidationReply", plain))
        else:
            metadata["name"] = "UnhandledApplicationPacket"
            if opcode == 5:
                metadata["historical_candidate_name"] = "CharacterCreateRequest"
            elif opcode == 7:
                metadata["historical_candidate_name"] = "CharacterLoginRequest"
            elif opcode == 16:
                metadata["historical_candidate_name"] = "TunnelAppPacketClientToServer"
        return metadata, replies

    def encrypt_reply(self, data: bytes) -> bytes:
        encrypted = self.outgoing.transform(data)
        return b"\0" + encrypted if encrypted.startswith(b"\0") else encrypted

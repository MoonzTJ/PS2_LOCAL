"""Read matching local game packs and export profile/metadata research inputs.

Uses only Python's standard library. Never edits game or backend files, sends
packets, or contacts a service. Resource discovery does not establish complete
class definitions, appearance mappings, successful loading or owned inventory.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import struct
import tempfile
import zipfile
import zlib


EXPECTED_CLIENT = 'e32f897cd52e5f24e8000901ab8a18814c691eb8aeb21049b943fb1320bfe957'
ANCHORS = {
    'ClientItemDefinitions.txt': '2bcf5ba2a9e0d5e63b19ed4b5179c9b294562d5a53833efd96cb8e4a10d8845f',
    'Models.txt': '1b2e0faf90da00486a268d823ecac49ec3789977e7e90e813284a8770996bd29',
}
# These names occur in the matching client's captured read-only data. They are
# candidate inputs, not a claim that a table supplies a specific wire field.
TABLE_NAMES = (
    'ClientItemDefinitions.txt', 'Models.txt', 'GenderDefinitions.txt', 'RaceDefinitions.txt',
    'Requirements.txt', 'RequirementExpressions.txt', 'ProfileTypes.txt', 'ProfileSkillSets.txt',
    'ProfileAbilityLines.txt', 'ItemProfiles.txt', 'ItemClasses.txt', 'ItemClassSets.txt',
    'ItemGroups.txt', 'ItemGroupMappings.txt', 'ItemCategories.txt', 'ItemCategoryGroups.txt',
    'ItemLines.txt', 'ItemLineMembers.txt', 'Implants.txt', 'ImplantSlots.txt',
    'Loadouts.txt', 'LoadoutInstances.txt', 'LoadoutSlots.txt', 'LoadoutSlotInstances.txt',
    'LoadoutSlotItemClasses.txt', 'LoadoutSlotTintItemClasses.txt', 'LoadoutBodyTintItemClasses.txt',
    'LoadoutItemAttachments.txt', 'LoadoutAttachments.txt', 'LoadoutAttachmentClasses.txt',
    'LoadoutAttachmentGroupMap.txt', 'ClientItemDatasheetData.txt',
)
STARTER_IDS = frozenset((44, 21, 802768, 19, 804621, 25, 44705, 6002573,
                         108, 7644, 7, 6003475, 6002619, 6015553))
# 165/166 are the supplied class-model candidates. The earlier native hash
# collision fixture also uses 7141, an AGR; it is unrelated to this capture.
MODEL_IDS = frozenset((165, 166))
MAX_RESOURCE = 16 * 1024 * 1024
MAX_REPORT = 30 * 1024 * 1024
DEFAULT_GAME = Path(r'C:\Users\Public\Daybreak Game Company\Installed Games\PlanetSide 2 Local')


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def name_hash(name):
    value = 0xffffffffffffffff
    for byte in name.upper().encode('ascii'):
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0x95ac9329ac4bc9b5 if value & 1 else 0)
    return value ^ 0xffffffffffffffff


def crc32c(data, seed=0):
    value = seed ^ 0xffffffff
    for byte in data:
        value = CRC32C_TABLE[(value ^ byte) & 255] ^ (value >> 8)
    return value ^ 0xffffffff


def _crc_table():
    result = []
    for byte in range(256):
        value = byte
        for _ in range(8):
            value = (value >> 1) ^ (0x82f63b78 if value & 1 else 0)
        result.append(value)
    return tuple(result)


CRC32C_TABLE = _crc_table()


def safe_name(name):
    if not name or len(name) > 127 or any(ord(c) < 32 or ord(c) > 126 for c in name):
        raise ValueError('Unsupported resource name')
    if any(c in name for c in '/\\:< >"|?*') or name in ('.', '..'):
        raise ValueError('Resource name must be a plain filename')
    return name


def read_index(path):
    size = path.stat().st_size
    with path.open('rb') as stream:
        header = stream.read(160)
        if len(header) != 160 or header[:4] != b'PAK\x01':
            raise ValueError(f'Unsupported pack header: {path.name}')
        count = struct.unpack_from('<I', header, 4)[0]
        length, index = struct.unpack_from('<QQ', header, 8)
        if length != size or not 0 < count <= 100000 or index < 256 or index + count * 32 != size:
            raise ValueError(f'Invalid pack index: {path.name}')
        stream.seek(index)
        raw = stream.read(count * 32)
        if len(raw) != count * 32:
            raise ValueError(f'Truncated pack index: {path.name}')
    entries = {}
    for key, offset, stored, flags, checksum in struct.iter_unpack('<QQQII', raw):
        if not 256 <= offset <= index or stored > index - offset or key in entries:
            raise ValueError(f'Invalid/duplicate pack entry: {path.name}')
        entries[key] = (offset, stored, flags, checksum)
    return entries, dict(name=path.name, bytes=size, entries=count,
                        index_sha256=hashlib.sha256(raw).hexdigest(), full_pack_sha256_computed=False)


def read_resource(path, key, entry):
    offset, stored, flags, checksum = entry
    if flags not in (16, 17) or not 0 < stored <= MAX_RESOURCE:
        raise ValueError(f'Unsupported or oversized resource in {path.name}: {key:016x}')
    with path.open('rb') as stream:
        stream.seek(offset)
        data = stream.read(stored)
    if len(data) != stored or crc32c(data, crc32c(struct.pack('<Q', key))) != checksum:
        raise ValueError(f'Resource CRC mismatch in {path.name}: {key:016x}')
    if flags == 16:
        return data
    if len(data) < 8 or data[:4] != bytes.fromhex('a1b2c3d4'):
        raise ValueError('Invalid resource compression header')
    expected = struct.unpack_from('>I', data, 4)[0]
    if not 0 < expected <= MAX_RESOURCE:
        raise ValueError('Resource decompression limit exceeded')
    decoder = zlib.decompressobj()
    raw = decoder.decompress(data[8:], expected + 1)
    if len(raw) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
        raise ValueError('Resource decompressed length or stream does not match')
    return raw


def extract_named(packs, names):
    wanted = {name_hash(safe_name(name)): name for name in names}
    if len(wanted) != len(names):
        raise ValueError('Duplicate or colliding requested names')
    found = {}
    for path, entries in packs:
        for key in wanted.keys() & entries.keys():
            name = wanted[key]
            raw = read_resource(path, key, entries[key])
            if name in found:
                if found[name][0] != raw:
                    raise ValueError(f'Different versions of {name} in these packs; select one matching game folder')
                found[name][1]['source_packs'].append(path.name)
                continue
            found[name] = (raw, dict(name=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                asset_hash=f'{key:016x}', source_packs=[path.name], stored_crc_verified=True))
    return found


def table_rows(raw):
    lines = raw.decode('utf-8-sig').splitlines()
    if not lines:
        raise ValueError('Empty resource table')
    columns = [column.lstrip('*') for column in lines[0].removeprefix('#').removesuffix('^').split('^')]
    if len(columns) != len(set(columns)) or 'ID' not in columns:
        raise ValueError('Invalid resource table columns')
    result = []
    for line in lines[1:]:
        if not line:
            continue
        values = line.removesuffix('^').split('^')
        if len(values) != len(columns):
            raise ValueError('Unexpected resource table row width')
        result.append(dict(zip(columns, values)))
    return result


def discover_model_names(found):
    names, templates = set(), set()
    items = [row for row in table_rows(found['ClientItemDefinitions.txt'][0]) if int(row['ID']) in STARTER_IDS]
    if {int(row['ID']) for row in items} != STARTER_IDS or len(items) != len(STARTER_IDS):
        raise ValueError('Starter item rows do not match the verified catalog')
    for row in items:
        name = row.get('MODEL_NAME', '')
        if not name:
            continue
        if '<gender>' in name:
            templates.add(name)
            # Discovery candidates only. Native appearance substitution remains
            # unverified and the manifest keeps the original template explicit.
            names.update(safe_name(name.replace('<gender>', gender)) for gender in ('Male', 'Female'))
        else:
            names.add(safe_name(name))
    for row in table_rows(found['Models.txt'][0]):
        if int(row['ID']) in MODEL_IDS:
            names.add(safe_name(row['MODEL_FILE_NAME']))
    if any(not name.lower().endswith('.adr') for name in names):
        raise ValueError('Expected actor-definition discovery candidates')
    return sorted(names), sorted(templates)


def collect(game_dir, output_root):
    game_dir, output_root = Path(game_dir), Path(output_root)
    client = game_dir / 'PlanetSide2_x64.exe'
    if file_sha256(client) != EXPECTED_CLIENT:
        raise ValueError('This game executable does not match the verified V31.2 client; no report was written')
    paths = sorted((game_dir / 'Resources/Assets').glob('*.pack2'), key=lambda p: p.name.casefold())
    if not paths:
        raise ValueError('No .pack2 files found in the selected game Resources/Assets folder')
    packs, pack_records = [], []
    for index, path in enumerate(paths):
        print(f'Reading pack index {index + 1}/{len(paths)}: {path.name}', flush=True)
        entries, record = read_index(path)
        packs.append((path, entries))
        pack_records.append(record)
    tables = extract_named(packs, TABLE_NAMES)
    for name, expected in ANCHORS.items():
        if name not in tables or tables[name][1]['sha256'] != expected:
            raise ValueError(f'Missing or different matching anchor: {name}; no report was written')
    model_names, templates = discover_model_names(tables)
    actors = extract_named(packs, model_names)
    manifest = dict(format_version=1, purpose='matching profile/item/actor research inputs',
        client_sha256=EXPECTED_CLIENT, anchor_tables_verified=True,
        packs=pack_records, tables=[tables[name][1] for name in sorted(tables)],
        missing_candidate_tables=sorted(set(TABLE_NAMES) - tables.keys()),
        actor_candidates=model_names, actor_templates=templates,
        actors=[actors[name][1] for name in sorted(actors)], missing_actor_candidates=sorted(set(model_names) - actors.keys()),
        appearance_substitution_verified=False, complete_class_values_verified=False,
        complete_item_values_verified=False, successful_native_assets_verified=False,
        game_or_backend_files_modified=False)
    output_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='profile-capture-', dir=output_root) as directory:
        temporary = Path(directory) / 'report.zip'
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
            for category, resources in (('tables', tables), ('actors', actors)):
                for name, (raw, _) in sorted(resources.items()):
                    archive.writestr(f'{category}/{name}', raw)
        if temporary.stat().st_size > MAX_REPORT:
            raise ValueError('Report exceeds the 30 MiB upload bound; keep the game files unchanged')
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError('Report ZIP verification failed')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        report = output_root / f'local-profile-resources-{stamp}.zip'
        temporary.replace(report)
    return manifest, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path, default=Path(os.environ.get('PS2_LOCAL_GAME_DIR', DEFAULT_GAME)))
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent / 'captures')
    args = parser.parse_args()
    try:
        manifest, report = collect(args.game_dir, args.output_dir)
        print(f'Collected {len(manifest["tables"])} candidate tables and {len(manifest["actors"])} actor definitions.')
        print(f'Game and backend files were read only. Upload this report: {report}')
        if manifest['missing_actor_candidates']:
            print('Missing actor candidates: ' + ', '.join(manifest['missing_actor_candidates']))
    except (OSError, ValueError, zlib.error) as exc:
        parser.exit(1, f'Profile resource capture failed: {exc}\n')


if __name__ == '__main__':
    main()

"""Report which candidate actor/preview assets exist in the matching game packs.

Uses only Python's standard library. Reads the executable hash, pack indexes and
three pinned tables; it never edits game or backend files, launches the game,
sends packets or decompresses actor payloads. Presence of a name in an index
does not establish that the asset, its dependencies or a callback load/succeed.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile

from collect_profile_resources import (DEFAULT_GAME, EXPECTED_CLIENT, extract_named, file_sha256,
                                       name_hash, read_index, safe_name, table_rows)

VERSION = 'actor-asset-presence-v1'
PINNED_TABLES = {
    'Models.txt': '1b2e0faf90da00486a268d823ecac49ec3789977e7e90e813284a8770996bd29',
    'HeadTypes.txt': 'fad57d9b1a0bceb923d915e46bc3cb63a384259887aef3a7d11a4ae437a097b6',
}
# Optional: pinned from the October shared-pack capture; columns are not assumed.
OPTIONAL_TABLES = {
    'FirstPersonArms.txt': '6c866f5f4a9df309e970a7a8141b8d6962bca8f68f76230288b580a657391585',
}
# Native 196CAFD uses this explicit fallback when class/menu model lookup fails;
# the GUI then requests its _UI variant. It is the observed positive control.
NATIVE_FALLBACK = 'Armor_NC_Male_Base.adr'
GENDER_TOKENS = ('Male', 'Female')
MAX_REPORT = 1024 * 1024


def ui_variant(name):
    # Native GUI preview replaces the .adr suffix with _UI.adr.
    return name[:-4] + '_UI.adr'


def adr_rows(raw):
    """Generic rows for a table whose key column is not assumed to be named ID."""
    lines = raw.decode('utf-8-sig').splitlines()
    if not lines:
        raise ValueError('Empty resource table')
    columns = [column.lstrip('*') for column in lines[0].removeprefix('#').removesuffix('^').split('^')]
    if len(columns) != len(set(columns)):
        raise ValueError('Invalid resource table columns')
    rows = []
    for line in lines[1:]:
        if line:
            values = line.removesuffix('^').split('^')
            if len(values) != len(columns):
                raise ValueError('Unexpected resource table row width')
            rows.append(dict(zip(columns, values)))
    return rows


def candidate_names(models, heads, arms=None):
    """Return {name: sorted reasons}; every name is a plain .adr filename."""
    reasons = {}

    def add(name, reason):
        reasons.setdefault(safe_name(name), set()).add(reason)

    for row in models:
        name = row['MODEL_FILE_NAME']
        if row['IS_VALID_FOR_PC'] == '1' and name.lower().endswith('.adr'):
            add(name, 'model_' + row['ID'])
            add(ui_variant(name), 'model_' + row['ID'] + '_ui')
    for row in heads:
        for token in GENDER_TOKENS:
            # Native substitution of <gender> is not executed here; both
            # expansions are presence candidates only.
            name = row['FILENAME'].replace('<gender>', token)
            add(name, 'head_' + row['ID'])
            add(ui_variant(name), 'head_' + row['ID'] + '_ui')
    for row in arms or ():
        for column, value in row.items():
            if value.lower().endswith('.adr'):
                add(value, 'first_person_arms_' + column.lower())
    add(NATIVE_FALLBACK, 'native_fallback')
    add(ui_variant(NATIVE_FALLBACK), 'native_fallback_ui')
    return {name: sorted(values) for name, values in sorted(reasons.items())}


def presence(packs, names):
    wanted = {}
    for name in names:
        key = name_hash(name)
        if key in wanted and wanted[key] != name:
            raise ValueError('Colliding candidate name hashes')
        wanted[key] = name
    found = {}
    for path, entries in packs:
        for key in wanted.keys() & entries.keys():
            _, stored, flags, _ = entries[key]
            found.setdefault(wanted[key], dict(asset_hash=f'{key:016x}', packs=[], stored_bytes=[], flags=[]))
            row = found[wanted[key]]
            row['packs'].append(path.name)
            row['stored_bytes'].append(stored)
            row['flags'].append(flags)
    return found


def model_summary(models, found):
    result = []
    for row in models:
        name = row['MODEL_FILE_NAME']
        if row['IS_VALID_FOR_PC'] != '1' or not name.lower().endswith('.adr'):
            continue
        result.append(dict(model_id=int(row['ID']), file=name, gender=int(row['GENDER']),
                           race_id=int(row['RACE_ID']), adr_present=name in found,
                           ui_adr_present=ui_variant(name) in found))
    return result


def check(game_dir, output_root, expected_client=EXPECTED_CLIENT):
    game_dir, output_root = Path(game_dir), Path(output_root)
    if file_sha256(game_dir / 'PlanetSide2_x64.exe') != expected_client:
        raise ValueError('This game executable does not match the verified client; no report was written')
    paths = sorted((game_dir / 'Resources/Assets').glob('*.pack2'), key=lambda p: p.name.casefold())
    if not paths:
        raise ValueError('No .pack2 files found in the selected game Resources/Assets folder')
    packs, pack_records = [], []
    for index, path in enumerate(paths):
        print(f'Reading pack index {index + 1}/{len(paths)}: {path.name}', flush=True)
        entries, record = read_index(path)
        packs.append((path, entries))
        pack_records.append(record)
    tables = extract_named(packs, tuple(PINNED_TABLES) + tuple(OPTIONAL_TABLES))
    for name, expected in {**PINNED_TABLES, **OPTIONAL_TABLES}.items():
        if name in tables and tables[name][1]['sha256'] != expected:
            raise ValueError(f'Different {name} from the pinned client data; no report was written')
    missing = sorted(set(PINNED_TABLES) - tables.keys())
    if missing:
        raise ValueError('Missing pinned tables: ' + ', '.join(missing))
    models = table_rows(tables['Models.txt'][0])
    heads = table_rows(tables['HeadTypes.txt'][0])
    arms, arms_error = None, None
    if 'FirstPersonArms.txt' in tables:
        try:
            arms = adr_rows(tables['FirstPersonArms.txt'][0])
        except (UnicodeDecodeError, ValueError) as exc:
            # Optional input: record why its names were skipped and continue.
            arms_error = str(exc)
    reasons = candidate_names(models, heads, arms)
    found = presence(packs, reasons)
    report = dict(format_version=1, version=VERSION, client_sha256=expected_client,
        packs=pack_records, tables=[tables[name][1] for name in sorted(tables)],
        first_person_arms_table_present='FirstPersonArms.txt' in tables,
        first_person_arms_names_used=arms is not None, first_person_arms_parse_error=arms_error,
        candidates=[dict(name=name, reasons=reasons[name], present=name in found, **found.get(name, {}))
                    for name in reasons],
        models=model_summary(models, found),
        native_fallback=dict(adr_present=NATIVE_FALLBACK in found,
                             ui_adr_present=ui_variant(NATIVE_FALLBACK) in found),
        index_presence_only=True, actor_payloads_read=False, dependencies_checked=False,
        successful_native_assets_verified=False, game_or_backend_files_modified=False)
    encoded = (json.dumps(report, indent=2) + '\n').encode('utf-8')
    if len(encoded) > MAX_REPORT:
        raise ValueError('Report exceeds its 1 MiB bound')
    output_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    destination = output_root / f'local-actor-assets-{stamp}.json'
    with tempfile.NamedTemporaryFile('wb', dir=output_root, delete=False, suffix='.tmp') as stream:
        stream.write(encoded)
    Path(stream.name).replace(destination)
    return report, destination


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path, default=Path(os.environ.get('PS2_LOCAL_GAME_DIR', DEFAULT_GAME)))
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent / 'captures')
    args = parser.parse_args(argv)
    try:
        report, destination = check(args.game_dir, args.output_dir)
    except (OSError, ValueError) as exc:
        parser.exit(1, f'Actor asset check failed: {exc}\n')
    present = sum(row['present'] for row in report['candidates'])
    print(f'{present} of {len(report["candidates"])} candidate actor names are present in the pack indexes.')
    for row in report['models']:
        if row['model_id'] in (1, 25, 26, 97, 165, 166, 7430, 7431):
            print(f'  model {row["model_id"]:>5} {row["file"]}: adr={row["adr_present"]} ui={row["ui_adr_present"]}')
    print(f'Game and backend files were read only. Upload this report: {destination}')


if __name__ == '__main__':
    main()

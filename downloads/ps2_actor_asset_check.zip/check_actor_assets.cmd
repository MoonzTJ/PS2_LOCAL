@echo off
setlocal
cd /d "%~dp0"
title MoonSol Actor Asset Check
echo Checks which actor and preview files exist in your separate local game copy.
echo Game and backend files are read only. No game launch or network connection.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 (
    py -3 check_actor_assets.py %*
    goto done
)
python check_actor_assets.py %*
:done
echo.
pause

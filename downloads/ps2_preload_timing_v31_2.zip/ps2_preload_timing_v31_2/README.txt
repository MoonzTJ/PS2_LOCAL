V31.2 PRELOAD TIMING TEST

1. Close the game, client launcher, controls window, and local server.
2. Extract All from this ZIP.
3. Double-click apply_preload_patch.cmd.
4. In the folder picker, select your existing V31 TEST folder: the folder
   containing start_local_server.cmd and start_local_client.cmd.
   This is the test/scripts folder you already launch, not the game Assets folder.
5. Wait for "V31.2 patch installed." Original files are backed up automatically.
6. From that same V31 test folder, run start_local_server.cmd,
   start_local_client.cmd, and open_test_controls.cmd.
7. Select LocalVS and wait before clicking Play.
8. In your existing ps2_loading_observer folder, run capture_loading_timeline.cmd.
   Press Enter when prompted, switch to the game and click Play once.
9. Keep the game open for 90 seconds. Upload the timeline ZIP, then save
   and upload the normal console report from this same run.

The console status identifies V31.2. This patch delays PreloadDone until
client opcode 04, emitted after the native loading flag reset.
The packet bytes and other V31 controls remain the same.
The next check is whether the preload flag stays true. Class definitions
are still missing, so world entry is not yet established.

Only gateway.py, local_server.py, and world_confirmation.py are replaced.
A different original build is rejected before any file is changed.
Rollback: close the game/server and copy the three files from the new
preload_backup_... folder back into the V31 test folder.

No game executable, assets, account credentials, or logs are included.

"""Persistent localhost login candidate service; no playable zone server."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import select
import socket
import sys
import time
import zipfile

from console_common import (CONTROL_PORT, HOST, LOGIN_PORT, SERVICE, encode,
                            profile_digest, timestamp)
from local_test import Probe
from login import load_environment_candidate
from test_console import Console, ConsoleInput
from availability import AvailabilityObserver
from gateway import Gateway
from handoff import GATEWAY_PORT
from presets import SERVER_NAME, PREVIEW_APPEARANCE_MODE, character_presets
from zone_backend import IndarZone
from profile_catalog import ProfileCatalog
from starter_character import seed_states, persist_seeds, test_description
from player_world import send_self_to_client
import starter_loadout
import starter_inventory
from presets import VS_TEST_PRESET


class ServerProbe(Probe):
    def __init__(self, log_path, port, instance_id, push_lists=False, gateway_port=GATEWAY_PORT,
                 send_zone_details=True, send_player_record=True, send_world_confirmation=True,
                 class_delivery_probe=False, location_delivery_probe=False,
                 vs_test_character=False, character_state_dir=None, starter_loadout_references=False,
                 owned_inventory_probe=False, cosmetic_inventory_probe=False, profile_activation_probe=False,
                 profile_placement_probe=False):
        self.instance_id = instance_id
        self.zone = IndarZone()
        self.profile_catalog = ProfileCatalog()
        if vs_test_character and (not class_delivery_probe or location_delivery_probe):
            raise ValueError('VS test character requires class probe and a separate run from location probe')
        if starter_loadout_references and not vs_test_character:
            raise ValueError('Starter loadout references require the isolated VS test character mode')
        if profile_activation_probe and not (cosmetic_inventory_probe and starter_loadout_references):
            raise ValueError('Profile activation requires the isolated cosmetic starter-reference mode')
        if profile_placement_probe and not profile_activation_probe:
            raise ValueError('Profile placement requires profile activation mode')
        if owned_inventory_probe and cosmetic_inventory_probe:
            raise ValueError('Cosmetic and original ownership probes require separate runs')
        ownership_enabled = owned_inventory_probe or cosmetic_inventory_probe
        inventory_provider = starter_inventory
        if cosmetic_inventory_probe:
            import cosmetic_inventory
            inventory_provider = cosmetic_inventory
        if ownership_enabled and not starter_loadout_references:
            raise ValueError('Ownership probe requires isolated starter loadout references')
        self.character_states = seed_states(self.profile_catalog) if vs_test_character else []
        self.character_test = test_description(self.character_states) if vs_test_character else None
        if vs_test_character:
            if character_state_dir is None:
                raise ValueError('VS test character requires a separate character-state directory')
            persist_seeds(character_state_dir, self.character_states)
            if ownership_enabled:
                inventory_provider.persist(character_state_dir)
        characters = character_presets(vs_test_character)
        starter_states = [state for state in self.character_states
                          if state['identity'] == VS_TEST_PRESET] if starter_loadout_references else []
        self.starter_loadout = starter_loadout.description(starter_states[0]) if starter_states else None
        if starter_states:
            identity = starter_states[0]['identity']
            packet = send_self_to_client(dict(character_guid=identity['character_id'],
                character_name=identity['name'], server_id=identity['server_id']),
                characters=characters, starter_state=starter_states[0], owned_probe=ownership_enabled,
                cosmetic_probe=cosmetic_inventory_probe)
            digest = hashlib.sha256(packet).hexdigest()
            self.starter_loadout.update(send_self_bytes=len(packet), send_self_sha256=digest)
            # The old helper must reject this changed packet mode. Retain the
            # seed fingerprint; its native_* flags describe the persisted seed.
            self.character_test['send_self_sha256'] = digest
        self.creator_capture_requests = 0
        self.profile_capture_requests = 0
        self.character_creation_requests = 0
        self.stage = dict(transport_request=False, dummy_login_received=False,
                          character_list_requested=False, server_list_requested=False,
                          character_login_candidate_received=False,
                          character_login_request_validated=False, character_login_reply_sent=False,
                          character_name_validation_requested=False, character_name_validation_reply_sent=False,
                          gateway_session_request=False, gateway_session_response_sent=False,
                          gateway_application_data=False, gateway_login_request_validated=False,
                          gateway_login_reply_sent=False, indar_zone_details_sent=False,
                          player_record_sent=False, initial_data_done_sent=False,
                          preload_done_sent=False, client_startup_signal_observed=False,
                          client_ready_signal_observed=False)
        self.last_peer_port = None
        self.login_request_count = 0
        self.availability = None
        self.push_lists = push_lists
        self.gateway = None
        super().__init__(log_path, port=port, enable_login=True, push_empty_lists=push_lists,
                         local_server_list=True, environment_payload=load_environment_candidate(),
                         preset_characters=True, character_record_status=1, server_state=0,
                         character_handoff=self.issue_handoff, allowed_protocol="LoginUdp_18",
                         characters=characters)
        try:
            gateway_log = self.log_path.with_name("gateway-" + self.log_path.name[len("server-"):])
            self.gateway = Gateway(gateway_log, self.event, gateway_port, send_zone_details,
                                   send_player_record, send_world_confirmation, zone=self.zone,
                                   class_delivery_probe=class_delivery_probe,
                                   location_delivery_probe=location_delivery_probe, characters=characters,
                                   starter_states=starter_states, owned_inventory_probe=owned_inventory_probe,
                                   cosmetic_inventory_probe=cosmetic_inventory_probe,
                                   profile_activation_probe=profile_activation_probe,
                                   profile_placement_probe=profile_placement_probe)
            self.event("backend_indar_data_loaded", **self.zone.status())
            self.event('backend_profile_data_loaded', **self.profile_catalog.status())
        except BaseException:
            self.close()
            raise

    def issue_handoff(self, selection):
        if self.gateway is None:
            raise ValueError("Local gateway is not ready")
        return self.gateway.issue(selection)

    def request_creator_capture(self):
        if self.creator_capture_requests >= 32:
            result = dict(ok=False, message='Creator capture limit reached; start a fresh test run.')
        else:
            self.creator_capture_requests += 1
            result = dict(ok=True, capture_request=self.creator_capture_requests,
                          message='Capture queued. Hold the selection for five seconds; keep the client launcher open.',
                          applied_to_client=False)
        self.event('creator_capture_requested', **result)
        return result

    def request_profile_capture(self):
        if self.profile_capture_requests >= 32:
            result = dict(ok=False, message='Class/loading capture limit reached; start a fresh test run.')
        else:
            self.profile_capture_requests += 1
            result = dict(ok=True, capture_request=self.profile_capture_requests,
                          message='Class/loading capture queued. Keep the game and client launcher open for five seconds.',
                          applied_to_client=False)
        self.event('profile_capture_requested', **result)
        return result

    def event(self, event, **fields):
        if event == "session_request":
            self.stage["transport_request"] = True
        elif event == "application_packet_decoded":
            name = fields.get("name")
            if fields.get('opcode') == 5:
                self.character_creation_requests += 1
            if name == "LoginRequest":
                self.stage["dummy_login_received"] = True
                self.login_request_count += 1
            elif name == "CharacterSelectInfoRequest":
                self.stage["character_list_requested"] = True
            elif name == "ServerListRequest":
                self.stage["server_list_requested"] = True
            elif name == "CharacterNameValidationRequest":
                self.stage["character_name_validation_requested"] = True
            elif name == "CharacterLoginRequest":
                self.stage["character_login_candidate_received"] = True
                self.stage["character_login_request_validated"] = True
            elif fields.get("historical_candidate_name") == "CharacterLoginRequest":
                self.stage["character_login_candidate_received"] = True
        elif event == "packet":
            self.last_peer_port = fields.get("peer_port")
        elif event == "candidate_reply_sent" and fields.get("name") == "CharacterLoginReply":
            self.stage["character_login_reply_sent"] = True
        elif event == "candidate_reply_sent" and fields.get("name") == "CharacterNameValidationReply":
            self.stage["character_name_validation_reply_sent"] = True
        elif event in ("gateway_session_request", "gateway_session_response_sent", "gateway_application_data"):
            self.stage[event] = True
        elif event in ("gateway_application_packet_decoded", "gateway_application_data_rejected"):
            self.stage["gateway_application_data"] = True
            if fields.get("name") == "GatewayLoginRequest":
                self.stage["gateway_login_request_validated"] = True
            if event == "gateway_application_packet_decoded" and fields.get("client_startup_signal_observed"):
                self.stage["client_startup_signal_observed"] = True
            if event == "gateway_application_packet_decoded" and fields.get("client_ready_signal_observed"):
                self.stage["client_ready_signal_observed"] = True
        elif event == "gateway_candidate_reply_sent":
            if fields.get("name") == "GatewayLoginReply":
                self.stage["gateway_login_reply_sent"] = True
            elif fields.get("name") == "IndarZoneDetails":
                self.stage["indar_zone_details_sent"] = True
            elif fields.get("name") == "SendSelfToClient":
                self.stage["player_record_sent"] = True
            elif fields.get("name") == "ZoneDoneSendingInitialData":
                self.stage["initial_data_done_sent"] = True
            elif fields.get("name") == "PreloadDone":
                self.stage["preload_done_sent"] = True
        super().event(event, **fields)

    def console_status(self):
        result = super().console_status()
        result.update(instance_id=self.instance_id, backend_profile="V31.2 preload confirmation after native readiness; verified starter equipment and separate class/item diagnostics; V30.1 native packets preserved",
                      preview_appearance_mode=PREVIEW_APPEARANCE_MODE,
                      configured_faction_permissions=[1, 2, 3, 4],
                      native_faction_permissions="unverified",
                      list_delivery="unsolicited_comparison" if self.push_lists else "requested_only",
                      initial_authentication_acceptance="unverified",
                      observed_since_start=dict(self.stage), active_transport_peers=len(self.peers),
                      login_listener=dict(host=HOST, port=self.address[1]),
                      character_login_reply_implemented=True,
                      character_name_validation_reply_implemented=True,
                      world_loading_implemented=False,
                      session_requests=self.requests, session_responses_sent=self.responses,
                      acknowledgments_sent=self.acks,
                      login_request_count=self.login_request_count,
                      note="ACKs and configured presets do not prove native client acceptance.")
        result["availability_observer"] = self.availability.status() if self.availability else dict(enabled=False)
        result["gateway"] = self.gateway.gateway_status() if self.gateway else dict(transport_ready=False)
        result["backend_zone"] = self.zone.status()
        if self.character_test is not None:
            result['vs_test_character'] = dict(self.character_test)
        if self.starter_loadout is not None:
            result['starter_loadout'] = dict(self.starter_loadout)
        if self.gateway and self.gateway.location_probe_enabled:
            result['location_probe'] = self.gateway.location_probe_status()
        if self.gateway and self.gateway.owned_probe_enabled:
            result['owned_inventory_probe'] = self.gateway.owned_probe_status()
        if self.gateway and self.gateway.profile_activation_enabled:
            result['profile_activation_probe'] = self.gateway.profile_activation_status()
        if self.gateway and self.gateway.profile_placement_enabled:
            result['profile_placement_probe'] = self.gateway.profile_placement_status()
        result['backend_profiles'] = self.profile_catalog.status()
        if self.gateway and self.gateway.class_probe_packet is not None:
            result['backend_profiles']['active_packet_profile_unchanged'] = False
            result['backend_profiles']['experimental_class_delivery_probe'] = True
        result['creator_capture_requests'] = self.creator_capture_requests
        result['profile_capture_requests'] = self.profile_capture_requests
        result['character_creation_requests'] = self.character_creation_requests
        result['character_creation_reply_implemented'] = False
        result["capabilities"]["independent_indar_static_data"] = True
        result["capabilities"]["gateway_transport"] = self.gateway is not None
        result["capabilities"]["gateway_local_login"] = self.gateway is not None
        result["capabilities"]["zone_details"] = bool(self.gateway and self.gateway.send_zone_details)
        result["capabilities"]["synthetic_player_record"] = bool(self.gateway and self.gateway.send_player_record)
        result["capabilities"]["world_confirmation_messages"] = bool(self.gateway and self.gateway.send_world_confirmation)
        return result

    def close(self):
        if self.gateway is not None:
            self.gateway.close()
            self.gateway = None
        super().close()


class ServerControl:
    def __init__(self, probe, port):
        self.probe = probe
        self.profile = profile_digest()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            if os.name == "nt":
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            self.sock.bind((HOST, port))
            self.sock.setblocking(False)
        except BaseException:
            self.sock.close()
            raise

    def base(self, command, nonce):
        result = dict(ok=True, service=SERVICE, command=command, nonce=nonce,
                    instance_id=self.probe.instance_id, server_pid=os.getpid(),
                    login_host=HOST, login_port=self.probe.address[1],
                    listener_ready=True, profile_sha256=self.profile,
                    list_delivery="unsolicited_comparison" if self.probe.push_lists else "requested_only",
                    gateway_host=HOST, gateway_port=self.probe.gateway.address[1], gateway_transport_ready=True,
                    backend_zone_data_ready=True, backend_zone_name=self.probe.zone.name,
                    backend_zone_id=self.probe.zone.zone_id,
                    backend_zone_dataset_sha256=self.probe.zone.dataset_sha256,
                    class_delivery_probe=self.probe.gateway.gateway_status()['class_delivery_probe'],
                    zone_service_ready=False, native_login_complete="unverified")
        if self.probe.gateway.location_probe_enabled:
            result['location_probe'] = self.probe.gateway.location_probe_status()
        if self.probe.gateway.owned_probe_enabled:
            result['owned_inventory_probe'] = self.probe.gateway.owned_probe_status()
        if self.probe.gateway.profile_activation_enabled:
            result['profile_activation_probe'] = self.probe.gateway.profile_activation_status()
        if self.probe.gateway.profile_placement_enabled:
            result['profile_placement_probe'] = self.probe.gateway.profile_placement_status()
        if self.probe.character_test is not None:
            result['vs_test_character'] = dict(self.probe.character_test)
        if self.probe.starter_loadout is not None:
            result['starter_loadout'] = dict(self.probe.starter_loadout)
        return result

    def poll(self):
        try:
            data, peer = self.sock.recvfrom(2049)
        except BlockingIOError:
            return
        if peer[0] != HOST or len(data) > 2048:
            return
        try:
            row = json.loads(data)
        except (ValueError, UnicodeError):
            return
        if not isinstance(row, dict) or row.get("service") != SERVICE:
            return
        nonce = row.get("nonce")
        if not isinstance(nonce, str) or len(nonce) != 32 or any(c not in "0123456789abcdef" for c in nonce):
            return
        command = row.get("command")
        if command not in ("health", "status", "client_started", "client_exited", 'capture_creator', 'capture_profiles', 'export_report', 'apply_location_probe', 'apply_owned_probe', 'apply_profile_activation', 'apply_profile_placement'):
            return
        require_instance = command in ('capture_creator', 'capture_profiles', 'export_report', 'apply_location_probe', 'apply_owned_probe', 'apply_profile_activation', 'apply_profile_placement')
        if row.get("instance_id", None if require_instance else self.probe.instance_id) != self.probe.instance_id:
            self.sock.sendto(encode(dict(ok=False, service=SERVICE, nonce=nonce)), peer)
            return
        reply = self.base(command, nonce)
        if command in ("client_started", "client_exited"):
            pid = row.get("client_pid")
            if type(pid) is not int or not 0 < pid <= 0xFFFFFFFF:
                return
            self.probe.event(command + "_reported", client_pid=pid,
                             source="local_client_launcher_control_channel")
        elif command == "status":
            reply["status"] = self.probe.console_status()
        elif command == 'capture_creator':
            reply.update(self.probe.request_creator_capture())
        elif command == 'capture_profiles':
            reply.update(self.probe.request_profile_capture())
        elif command == 'apply_location_probe':
            reply.update(self.probe.gateway.request_location_probe())
        elif command == 'apply_owned_probe':
            reply.update(self.probe.gateway.request_owned_probe())
        elif command == 'apply_profile_activation':
            reply.update(self.probe.gateway.request_profile_activation())
        elif command == 'apply_profile_placement':
            reply.update(self.probe.gateway.request_profile_placement())
        elif command == 'export_report':
            try:
                reply['report_path'] = str(export_report(self.probe))
            except OSError:
                reply.update(ok=False, message='Report export failed; check the server console.')
        self.sock.sendto(encode(reply), peer)

    def close(self):
        self.sock.close()


def export_report(probe):
    probe.log.flush()
    logs = probe.log_path.parent
    destination = logs / f"local-console-report-{timestamp()}-{probe.instance_id}.zip"
    if probe.gateway is not None:
        probe.gateway.log.flush()
    paths = [probe.log_path] + sorted(logs.glob(f"gateway-*-{probe.instance_id}.jsonl"))
    paths += sorted(logs.glob(f"client-*-{probe.instance_id}.jsonl"))
    paths += sorted(logs.glob(f"native-*-{probe.instance_id}.json"))
    status = json.dumps(probe.console_status(), indent=2)
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("status.json", status)
        archive.writestr("backend-zone.json", json.dumps(probe.zone.status(), indent=2))
        archive.writestr('backend-profiles.json', json.dumps(probe.console_status()['backend_profiles'], indent=2))
        archive.writestr('local-vs-starter.json', json.dumps(probe.profile_catalog.starter(), indent=2))
        if probe.character_states:
            archive.writestr('starter-characters.json', json.dumps(probe.character_states, indent=2))
        for path in paths:
            archive.write(path, path.name)
    probe.event("report_created", path=str(destination), files=len(paths) + 4 + bool(probe.character_states))
    return destination


class ServerConsole(Console):
    def execute(self, line):
        words = [word.lower() for word in line.strip().split()] if isinstance(line, str) else []
        if words == ['creator']:
            return self.probe.request_creator_capture()
        if words == ['capture', 'profiles']:
            return self.probe.request_profile_capture()
        if words == ['profile', 'starter']:
            result = dict(ok=True, backend_profiles=self.probe.profile_catalog.starter())
            self.probe.event('backend_profile_console', **result)
            return result
        if words == ['profiles'] or len(words) == 3 and words[:2] == ['profile', 'loadout']:
            try:
                result = dict(ok=True, backend_profiles=self.probe.profile_catalog.status()
                              if words == ['profiles'] else self.probe.profile_catalog.loadout(int(words[2])))
            except ValueError as exc:
                result = dict(ok=False, reason=str(exc))
            self.probe.event('backend_profile_console', **result)
            return result
        if isinstance(line, str) and line.strip().startswith("zone"):
            words = line.strip().split()
            if words == ["zone", "status"]:
                result = dict(ok=True, backend_zone=self.probe.zone.status())
            elif words == ["zone", "verify"]:
                try:
                    result = dict(ok=True, backend_zone=self.probe.zone.verify())
                except (OSError, ValueError) as exc:
                    result = dict(ok=False, reason=str(exc))
            elif len(words) == 3 and words[:2] == ["zone", "area"]:
                try:
                    area = self.probe.zone.areas[int(words[2], 0)]
                    result = dict(ok=True, area=area.summary())
                except (KeyError, ValueError):
                    result = dict(ok=False, reason="Use an existing Indar area ID")
            elif len(words) == 4 and words[:2] == ['zone', 'object']:
                try:
                    if self.probe.zone.scene is None:
                        raise ValueError('No parsed Indar.zone is loaded')
                    result = dict(ok=True, object=self.probe.zone.scene.object(int(words[2]), int(words[3])))
                except ValueError as exc:
                    result = dict(ok=False, reason=str(exc))
            else:
                return super().execute(line)
            self.probe.event("backend_zone_console", **result)
            return result
        if isinstance(line, str) and line.strip().split() == ["lists", "send"] and not self.probe.push_lists:
            result = dict(ok=False, applied_to_client=False, code="isolated_test",
                          message="V31 waits for native list requests. Manual list delivery is disabled in this mode.")
            self.probe.event("console_result", command="lists", **result)
            return result
        if isinstance(line, str) and line.strip() in ("health", "clients"):
            return super().execute("status")
        if isinstance(line, str) and line.strip() == "report":
            try:
                path = export_report(self.probe)
            except OSError as exc:
                self.probe.event("report_failed", error_type=type(exc).__name__)
                return dict(ok=False)
            return dict(ok=True, path=str(path))
        result = super().execute(line)
        if isinstance(line, str) and line.strip() == "help":
            print("Also: health | clients | report (ZIP of this server run and attached client launch logs).")
            print("Indar backend: zone status | zone verify | zone area <ID> | zone object <group> <instance>.")
            print('Creator diagnostic: creator (hold a selection for five seconds; launcher required).')
            print('Profile metadata: profiles | profile loadout <ID>. Equipment is not applied to the client.')
            if not self.probe.push_lists:
                print("V31 isolation: lists send is disabled; waiting for native list requests.")
        return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=LOGIN_PORT)
    parser.add_argument("--control-port", type=int, default=CONTROL_PORT)
    parser.add_argument("--gateway-port", type=int, default=GATEWAY_PORT)
    parser.add_argument("--no-zone-details", action="store_true",
                        help="Isolate gateway login; omit the Indar ZoneDetails candidate")
    parser.add_argument("--no-player-record", action="store_true",
                        help="Compare with the previous gateway/zone flow; omit SendSelfToClient")
    parser.add_argument("--no-world-confirmation", action="store_true",
                        help="Compare with V26; omit the two initialization completion messages")
    parser.add_argument("--log-dir", type=Path, default=Path(__file__).resolve().parent / "logs")
    parser.add_argument("--seconds", type=float, default=0, help="0 keeps running until quit or Ctrl+C")
    parser.add_argument("--no-console", action="store_true")
    parser.add_argument("--push-lists", action="store_true",
                        help="Send corrected character and existing server lists immediately after LoginReply")
    parser.add_argument('--class-delivery-probe', action='store_true',
                        help='Experimental identity-only class records with native constructor defaults; incomplete game data')
    parser.add_argument('--location-probe', action='store_true',
                        help='Enable one manually requested LocalVS UpdateLocation experiment')
    parser.add_argument('--vs-test-character', action='store_true',
                        help='Add separate LocalVSTest identity with persisted server starter references')
    parser.add_argument('--character-state-dir', type=Path,
                        help='Separate server directory for shared VS starter seeds')
    parser.add_argument('--starter-loadout-references', action='store_true',
                        help='Development only: serialize LocalVSTest saved/current starter references; owned inventory remains empty')
    parser.add_argument('--owned-inventory-probe', action='store_true',
                        help='Development only: two generic owned items with delayed one-shot delivery')
    parser.add_argument('--cosmetic-inventory-probe', action='store_true',
                        help='Development only: separate one-shot VS armor/helmet ownership experiment')
    parser.add_argument('--profile-activation-probe', action='store_true',
                        help='Development only: one active-profile19 message preserving observed model0; no item delivery')
    parser.add_argument('--profile-placement-probe', action='store_true',
                        help='Development only: one verified warpgate location after isolated profile activation')
    parser.add_argument("--no-availability-observation", action="store_true",
                        help="Leave the advertised UDP 60000 and TCP 9 destinations closed")
    args = parser.parse_args(argv)
    if (not all(1 <= port <= 65535 for port in (args.port, args.control_port, args.gateway_port))
            or len({args.port, args.control_port, args.gateway_port}) != 3):
        parser.error("Use distinct login, control and gateway ports in 1..65535")
    if not 0 <= args.seconds <= 86400:
        parser.error("Duration must be 0 (persistent) or at most 86400 seconds")
    if args.class_delivery_probe and (args.no_zone_details or args.no_player_record or args.no_world_confirmation):
        parser.error('The class delivery probe requires the normal V31.2 initialization flow')
    if args.location_probe and not args.class_delivery_probe:
        parser.error('The location probe requires --class-delivery-probe')
    if args.vs_test_character and (not args.class_delivery_probe or args.location_probe or args.character_state_dir is None):
        parser.error('Use --vs-test-character with --class-delivery-probe and --character-state-dir, in a separate run from --location-probe')
    if args.character_state_dir is not None and not args.vs_test_character:
        parser.error('--character-state-dir requires --vs-test-character')
    if args.starter_loadout_references and not args.vs_test_character:
        parser.error('--starter-loadout-references requires --vs-test-character')
    if args.cosmetic_inventory_probe and args.owned_inventory_probe:
        parser.error('Use a separate run for cosmetic and original ownership probes')
    if (args.owned_inventory_probe or args.cosmetic_inventory_probe) and not args.starter_loadout_references:
        parser.error('--owned-inventory-probe requires --starter-loadout-references')
    if args.profile_activation_probe and not (args.cosmetic_inventory_probe and args.starter_loadout_references):
        parser.error('--profile-activation-probe requires --cosmetic-inventory-probe and --starter-loadout-references')
    if args.profile_placement_probe and not args.profile_activation_probe:
        parser.error('--profile-placement-probe requires --profile-activation-probe')
    probe = control = observer = inputs = None
    try:
        identifier = secrets.token_hex(8)
        path = args.log_dir.resolve() / f"server-{timestamp()}-{identifier}.jsonl"
        print(f"{SERVER_NAME} — PS2 LOCAL SERVER V31.2 PRELOAD TIMING TEST\nLoading independent Indar static data before accepting clients.\nPlayable Indar and character saving remain unverified/pending.")
        if args.class_delivery_probe:
            print('EXPERIMENTAL CLASS DELIVERY PROBE: 24 identities, native defaults, incomplete class data.')
        print("Comparison: immediate list delivery." if args.push_lists else
              "LoginReply first; lists are sent only when requested.")
        probe = ServerProbe(path, args.port, identifier, push_lists=args.push_lists,
                            gateway_port=args.gateway_port, send_zone_details=not args.no_zone_details,
                            send_player_record=not args.no_player_record,
                            send_world_confirmation=not args.no_world_confirmation,
                            class_delivery_probe=args.class_delivery_probe,
                            location_delivery_probe=args.location_probe,
                            vs_test_character=args.vs_test_character,
                            character_state_dir=args.character_state_dir,
                            starter_loadout_references=args.starter_loadout_references,
                            owned_inventory_probe=args.owned_inventory_probe,
                            cosmetic_inventory_probe=args.cosmetic_inventory_probe,
                            profile_activation_probe=args.profile_activation_probe,
                            profile_placement_probe=args.profile_placement_probe)
        observer = None if args.no_availability_observation else AvailabilityObserver(probe.event)
        probe.availability = observer
        control = ServerControl(probe, args.control_port)
        probe.event("console_server_ready", instance_id=identifier, server_pid=os.getpid(),
                    login_port=args.port, control_port=args.control_port,
                    gateway_port=args.gateway_port, gateway_transport_ready=True,
                    profile_sha256=control.profile, zone_service_ready=False)
        probe.event("login_acceptance_test_mode", list_delivery="unsolicited_comparison" if args.push_lists else "requested_only",
                    local_identity="Moon_local", native_launch_session="dummy_zero",
                    reply_payloads_changed=True, character_payload_layout="captured_build_v17",
                    server_list_layout="captured_build_server_v18",
                    initial_authentication_acceptance="unverified")
        print(f"INDAR DATA LOADED: zone {probe.zone.zone_id}, {len(probe.zone.areas)} parsed areas; independent of the client.")
        if probe.zone.scene is not None:
            print(f'INDAR ZONE RECORDS LOADED: {len(probe.zone.scene.groups)} actor groups, {probe.zone.scene.placement_count} placements; geometry remains pending.')
        print("Terrain geometry/physics and playable world entry remain pending.")
        print("READY: local login + gateway listeners. Type zone status before starting the client.\nNow run start_local_client.cmd. Server keeps running when the game closes.")
        console = ServerConsole(probe)
        inputs = None if args.no_console else ConsoleInput()
        if inputs:
            console.execute("help")
        deadline = time.monotonic() + args.seconds if args.seconds else float("inf")
        while time.monotonic() < deadline:
            surfaces = [probe.sock, control.sock, probe.gateway.sock] + (observer.sockets() if observer else [])
            ready, _, _ = select.select(surfaces, [], [], 0.05)
            if probe.sock in ready:
                probe.poll()
            if control.sock in ready:
                control.poll()
            if probe.gateway.sock in ready:
                probe.gateway.poll()
            if observer and observer.sock in ready:
                observer.poll()
            if observer and observer.tcp_sock in ready:
                observer.poll_tcp()
            probe.tick()
            probe.gateway.tick()
            if inputs:
                if any(console.execute(line).get("stop") for line in inputs.poll()):
                    break
        probe.event("console_server_stopping")
        report = export_report(probe)
        print(f"Send this report after the test: {report}")
    except KeyboardInterrupt:
        print("Stopping the local server.")
        if probe is not None:
            try:
                export_report(probe)
            except OSError as exc:
                print(f"Could not create report: {exc}", file=sys.stderr)
    except (OSError, ValueError) as exc:
        print(f"Server could not run: {exc}", file=sys.stderr)
        print("Close any older local test service using these ports, then retry.", file=sys.stderr)
        return 1
    finally:
        if inputs is not None:
            inputs.close()
        if observer is not None:
            observer.close()
        if control is not None:
            control.close()
        if probe is not None:
            probe.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

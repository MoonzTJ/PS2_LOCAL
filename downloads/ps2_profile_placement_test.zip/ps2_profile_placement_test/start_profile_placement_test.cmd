@echo off
cd /d "%~dp0"
py -3 "%~dp0PS2_Tools\run_profile_placement_test.py" --mode start
pause

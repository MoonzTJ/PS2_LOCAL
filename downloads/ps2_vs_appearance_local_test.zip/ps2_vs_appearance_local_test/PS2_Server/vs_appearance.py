"""Opt-in VS Light Assault appearance candidate; never a default or recovered value.

Table-inferred, not live server data: Models.txt has exactly one PC-valid VS LA
base pair (165 male gender1, 166 female gender2). The Windows asset check
local-actor-assets-20261029-195412-729110 found both ADRs and _UI variants,
while V29's Body_*_Standard rows (1/25/26) are absent in that client.
"""
import hashlib
import json
from pathlib import Path

from zone_backend import table

VERSION = 'vs-la-menu-appearance-v2'
CLASS_MODELS_VERSION = 'vs-la-class-models-v1'
DATA = Path(__file__).resolve().parent / 'server_data' / 'appearance'
PROFILE_ID = 19
HEAD_ID = 1
GENDER = 1
MODEL_PAIR = (165, 166)  # Class record +28 male / +2C female; wire record offsets 42/46.
MODEL_FILES = {165: 'Armor_VS_Male_LightAssault_Base.adr', 166: 'Armor_VS_Female_LightAssault_Base.adr'}
ASSET_REPORT_SHA256 = '2830c8157452f9dcb0a7d710110e7d7a867e2c84e07b23a1b0c171458ab4f8aa'


def verified_rows():
    manifest = json.loads((DATA/'manifest.json').read_text())
    resources = {}
    for record in manifest['resources']:
        raw = (DATA/record['name']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != record['sha256']:
            raise ValueError('Appearance table checksum differs')
        resources[record['name']] = {int(row['ID']): row for row in table(raw)}
    models, heads = resources['Models.txt'], resources['HeadTypes.txt']
    for identifier, gender in zip(MODEL_PAIR, ('1', '2')):
        row = models[identifier]
        if (row['MODEL_FILE_NAME'] != MODEL_FILES[identifier] or row['GENDER'] != gender
                or row['IS_VALID_FOR_PC'] != '1'):
            raise ValueError('VS LA base model row differs')
    family = sorted(i for i, row in models.items() if row['IS_VALID_FOR_PC'] == '1'
                    and row['MODEL_FILE_NAME'].startswith('Armor_VS_') and 'LightAssault_Base' in row['MODEL_FILE_NAME'])
    if family != list(MODEL_PAIR):
        raise ValueError('VS LA base model pair is no longer unique')
    if heads[HEAD_ID]['GENDER'] != str(GENDER):
        raise ValueError('Candidate head does not match the male gender')
    return models, heads


verified_rows()


def class_model_pairs():
    # Windows v1 (2026-10-29): with these words in ProfileDefinitions, logging
    # into ANY character crashed the client after the class packet. Menu-only
    # v1 preview was correct. Keep this separate and off until traced natively.
    return {PROFILE_ID: MODEL_PAIR}


def class_models_description():
    return dict(version=CLASS_MODELS_VERSION, enabled=True, experimental=True, profile_id=PROFILE_ID,
                class_model_pair=list(MODEL_PAIR), windows_result='client crashed after class delivery for every character')


def preview(character_id):
    return {character_id: dict(head_id=HEAD_ID, model_id=MODEL_PAIR[0], gender=GENDER)}


def description():
    return dict(version=VERSION, enabled=True, experimental=True, table_inferred=True,
                live_server_values_recovered=False, menu_character='LocalVSTest',
                menu_head_id=HEAD_ID, menu_model_id=MODEL_PAIR[0], menu_gender=GENDER,
                other_characters_unchanged=True, class_definitions_unchanged=True,
                windows_v1_preview='VS LA body and head rendered at character select',
                activation_model_word_changed=False,
                asset_presence_evidence='local-actor-assets-20261029-195412-729110',
                asset_presence_report_sha256=ASSET_REPORT_SHA256, windows_appearance_verified=False)

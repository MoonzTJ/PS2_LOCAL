# Opus Local Test v12.1 — activation with armour/helmet attachments (Male names)

v10.2 and v11 built the VS LA arms after the placement, but the camera never
attached: the actor's arms ready bit stayed clear for the whole 90-second
watch. H1Z1's open-source server (same engine family, used only as a
reference) sends the profile activation with an attachment array of armour and
gear models; we have always sent it empty.

v12 filled that array with the VS starter armour (slot 10) and helmet
(slot 11) from the client's own tables. The client accepted the entries but
looked for files literally named `..._<gender>_...`, which do not exist. v12.1
sends the Male names instead (`Armor_VS_Male_LightAssault_Look001.adr`,
`Helmet_VS_Male_LightAssault_Look001.adr`): your character uses the male VS LA
body, and both files are in the game's packs. Everything else is as in v12.

1. Close the game and server. Extract into a fresh folder.
2. Run **Start Opus Local Test.cmd**, then **Start local session**.
3. Run **Watch Arms.cmd** and leave its window open.
4. Select **LocalVSTest** and press **Play**. You move to the warpgate after
   about 5 seconds; the body and attachments arrive about 8 seconds later.
   Look around and walk until Watch Arms gives three beeps.
5. Optionally run **Capture Camera.cmd** afterwards (hold W and turn between
   the beeps).
6. Note whether the armour or helmet looks different, whether arms appear and
   whether the view follows the mouse. Then upload the new `reports` files and
   the copied game's `Logs/FirstPersonArms.log` and `Logs/FailedLoadAssets.log`.
   If it crashes, include the newest Logs files.

No bootstrap button is needed; do not use Advanced → Existing bootstrap
diagnostic. Reports show what was sent and read, not that anything rendered;
that needs your view of the game plus the logs.

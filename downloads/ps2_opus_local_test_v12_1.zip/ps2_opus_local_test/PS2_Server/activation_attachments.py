"""Opt-in attachment-array candidates for the VS LA profile activation.

The activation's attachment array is read by native 986E20 (four strings, four
u32 words per 0x170-byte entry) and applied by BE8BC0, which keys the actor's
attachment map by the third word. H1Z1's server (same engine lineage, used only
as a reference) fills this array with armour/gear models keyed by slot. The
model names and slot IDs here are the pinned VS starter armour/helmet rows that
cosmetic_inventory validates against the client's own tables. Windows v12
showed the attachment path does not expand <gender> (the literal name failed
to load), so it is filled with Male: model 165 is the male VS LA body
(Armor_VS_Male_LightAssault_Base.adr) and both Male Look001 names are in the
game's pack indexes. Slot-ID-as-key, the other strings and words, and any
rendering effect are unverified.
"""
import cosmetic_inventory

VERSION = 'vs-activation-attachments-candidate-v2'
GENDER = 'Male'


def starter_attachments():
    cosmetic_inventory._state_bytes()  # raises unless the pinned catalog rows still match
    return tuple((cosmetic_inventory.MODELS[item].replace('<gender>', GENDER), slot)
                 for slot, item, _ in cosmetic_inventory.ITEMS)

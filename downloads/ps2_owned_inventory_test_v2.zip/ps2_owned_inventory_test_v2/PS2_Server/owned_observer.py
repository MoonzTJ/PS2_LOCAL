"""Bounded typed reads for the two-item local ownership experiment."""
import struct
import win_reader as win
from character_observer import StableFields
from starter_inventory import ITEMS

VERSION = 'local-owned-equipment-state-v2'


def owned_state(read, base, engine, database, player, guid):
    fields = StableFields(read, 4096)
    win.require(fields.u64(engine+0xA2E0) == database
                and fields.u64(database+0xD68) == player and fields.u64(player+0x18) == guid,
                'Ownership observer identity changed')
    win.require(read.exact(base+0xDAB300, 8) == bytes.fromhex('833d05822a03004c'),
                'Owned-slot lookup differs from matching build')
    selected = fields.u32(player+0x218)
    mode = fields.u32(base+0x405350C)
    count, head, tail = struct.unpack('<QQQ', fields.exact(player+0x7D838, 24))
    win.require(count <= 1, 'Equipment rows exceed this experiment')
    rows, node = [], head
    if count:
        win.require(node and node == tail and fields.u64(node+0xF8) == 0,
                    'Equipment row list is incomplete')
        key = fields.u32(node)
        record = node+8
        slot_count, slot_head, slot_tail = struct.unpack('<QQQ',fields.exact(record+0x80,24))
        win.require(slot_count <= 2,'Equipment slots exceed this experiment')
        slots, seen, last, slot = [], set(), 0, slot_head
        for _ in range(slot_count):
            win.require(slot and slot not in seen, 'Equipment slot list is incomplete or cyclic')
            seen.add(slot)
            slots.append(dict(slot_id=fields.u32(slot), owned_guid=fields.u64(slot+8+0x38)))
            last, slot = slot, fields.u64(slot+0xB8)
        win.require(not slot and last == slot_tail, 'Equipment slot count or tail changed')
        rows.append(dict(key=key, slots=slots))
    else:
        win.require(not head and not tail, 'Empty equipment list has nodes')
    owned_count = fields.u64(player+0x7CA80)
    win.require(owned_count <= 2, 'Owned count exceeds this experiment')
    buckets, capacity = struct.unpack('<QQ',fields.exact(player+0x7CAA0,16))
    win.require(capacity <= 64 and (not capacity or (buckets and not capacity & (capacity-1))),
                'Owned GUID buckets exceed this experiment')
    owned = []
    for slot_id, item_id, expected_guid in ITEMS:
        node = fields.u64(buckets+((expected_guid ^ (expected_guid >> 32)) & (capacity-1))*8) if capacity else 0
        seen, found = set(), None
        for _ in range(4):
            if not node:
                break
            win.require(node not in seen,'Owned GUID bucket is cyclic')
            seen.add(node)
            if fields.u64(node+0x88) == expected_guid:
                win.require(fields.u64(node) == base+0x33E8170, 'Owned item is not the expected generic type')
                found = dict(slot_id=slot_id, definition_id=fields.u32(node+8),
                    guid=fields.u64(node+0x10), indexed_guid=expected_guid)
                break
            node=fields.u64(node+0xA0)
        win.require(found is not None or not node, 'Owned GUID search is incomplete')
        owned.append(dict(slot_id=slot_id, expected_definition_id=item_id,
                          expected_guid=expected_guid, instance=found))
    # Factory uses this exact encoded manager. Verify it agrees with the loader.
    index = (~fields.u32(base+0x40401FC)) & 0xffffffff
    win.require(index < 64, 'Item factory manager index differs')
    manager = fields.u64(base+0x41735D0+index*8) ^ fields.u64(base+0x41735D0+((index-15)&63)*8)
    win.require(manager and fields.u64(engine+0xB148) == manager, 'Factory and loader metadata managers differ')
    root=fields.u64(manager+0x278)
    metadata=[]
    for _, item_id, _ in ITEMS:
        node, seen, kind = root, set(), None
        for _ in range(16):
            if not node:
                break
            win.require(node not in seen,'Item metadata tree is cyclic')
            seen.add(node)
            key=fields.u32(node)
            if key == item_id:
                kind=fields.u32(node+8+0xAC)
                break
            node=fields.u64(node+(0x240 if key > item_id else 0x248))
        metadata.append(dict(item_definition_id=item_id, record_present=kind is not None,
                             native_type=kind, matches_generic_prerequisite=kind == 36))
    fields.verify()
    # DAB300 uses the first row for a nonzero native lookup mode. Do not
    # overwrite the observed mode/selector or infer a profile ID mapping.
    active=(rows[:1] if mode else [row for row in rows if row['key']==selected])
    links={slot['slot_id']:slot['owned_guid'] for row in active for slot in row['slots']}
    return dict(available=True,version=VERSION,stable_reread=True,selected_key_raw=selected,
        lookup_mode_raw=mode,lookup_uses_first_row=bool(mode),
        effective_equipment_row_key=active[0]['key'] if active else None,
        equipment_rows=rows,owned_guid_count=owned_count,owned_items=owned,
        required_metadata=metadata,
        equipment_references_match=bool(len(rows)==1 and rows[0]['key']==0 and len(rows[0]['slots'])==2
            and all(links.get(slot)==guid for slot,_,guid in ITEMS)),
        both_owned_instances_match=all(row['instance'] and row['instance']['guid']==row['expected_guid']
            and row['instance']['definition_id']==row['expected_definition_id'] for row in owned),
        native_lookup_called=False,equipment_row_semantics_verified=False,playable_character_verified=False)

@echo off
cd /d "%~dp0"
py -3 capture_class_definitions.py
echo.
echo Reports are saved in the reports folder beside this helper.
pause

"""Bounded creator, class-definition and item-preload observations for one build."""
import math
import struct
import win_reader as win

CREATOR_SIGNATURES = {
    # CreateCharacter copies head, faction, gender and profile type from wrapper.
    0x116ED7B: bytes.fromhex('8b476c8945ab8b47688945a78b47748945b38b47708945af'),
    # Registered GetProfileType and GetPlayerfaction getters.
    0x116E4BA: bytes.fromhex('488b8268b200008b7870'),
    0x116E55A: bytes.fromhex('488b8268b200008b7868'),
}
PROFILE_SIGNATURES = {
    0x118D780: bytes.fromhex('4053555741554883ec38488b59704c8be9'),
    0x118D926: bytes.fromhex('418b45784c8b64243085c00f8590000000'),
    # Constructor stores argument six (engine+B148), not class manager B190.
    0x118C8D8: bytes.fromhex('488b85a801000049894730'),
    # Missing pending entries use the item-definition request path.
    0xEFB8AE: bytes.fromhex('488d15db6a5402'),
}
CLASS_SIGNATURES = {
    0xA59A78: bytes.fromhex('498b9690b10000488d4c2430e80a275cff'),
    0x1155900: bytes.fromhex('418b914ce20700'),
    0x1155924: bytes.fromhex('488b80c8000000'),
    0x1155943: bytes.fromhex('83790c05'),
    # Named source/target criteria query the record's +88 uint32 tree.
    0x347F890: b'TargetHasProfileClassification\0',
    0x347F8B8: b'SourceHasProfileClassification\0',
    0x17C6EB3: bytes.fromhex('8b433c488d5424304881c188000000'),
    0x96DA27: bytes.fromhex('443b007c04'),
    # Named cost/purchase consumers use the resource ID at +38 and base cost +3C.
    0x349C5F0: b'GetProfileCost\0',
    0x349C660: b'CanPurchaseProfile\0',
    0x1150D44: bytes.fromhex('8b533c85d27e34'),
    0x1152A2D: bytes.fromhex('8b5638'),
}
CLASSIFICATION_SNAPSHOT_LIMIT = 16
CLASS_MAP_SNAPSHOT_LIMIT = 8
VS_PROFILE_IDS = (17, 19, 20, 21, 22, 23)
VS_STARTER_ITEM_IDS = (44, 21, 802768, 19, 804621, 25, 44705, 6002573,
                      108, 7644, 7, 6003475, 6002619, 6015553)


def require_signatures(read, base, signatures):
    for rva, signature in signatures.items():
        win.require(read.exact(base+rva, len(signature)) == signature,
                    'Creator/profile diagnostic signature differs from the captured build')


def creator_state(read, base, wrapper):
    require_signatures(read, base, CREATOR_SIGNATURES)
    fields = read.exact(wrapper+0x68, 16)
    faction, head, profile_type, gender = struct.unpack('<4I', fields)
    server = read.u32(wrapper+0x58)
    win.require(faction <= 4 and profile_type <= 7 and gender <= 2,
                'Creator values exceed the captured selection domains')
    win.require(read.exact(wrapper+0x68, 16) == fields and read.u32(wrapper+0x58) == server,
                'Creator selection changed during snapshot; retry the capture')
    return dict(available=True, faction_id=faction, head_type_id=head,
                profile_type_id=profile_type, gender=gender, selected_server_id=server,
                head_model_id='unverified', active_profile_id='unverified',
                character_saved=False, selection_stable=True,
                interpretation='Creator selections; profile type is not an active profile ID. Head type is not assumed to be the menu HeadId.')


def _class_map_snapshot(read, count, first, last):
    """Export bounded numeric triples; the map's semantic namespace is unknown."""
    win.require(bool(first) == bool(last) == bool(count),
                'Class nested map endpoints/count differ')
    result = dict(nested_map_entries_available=count <= CLASS_MAP_SNAPSHOT_LIMIT,
                  nested_map_entries_truncated=count > CLASS_MAP_SNAPSHOT_LIMIT)
    if not result['nested_map_entries_available']:
        return result
    nodes, entries = {}, []
    address, previous = first, 0
    while address:
        win.require(address not in nodes and len(nodes) < count,
                    'Class nested map is cyclic or exceeds its count')
        raw = read.exact(address, 0x20)
        entry = struct.unpack_from('<3I', raw)
        following, prior = struct.unpack_from('<2Q', raw, 0x10)
        win.require(prior == previous, 'Class nested map links differ')
        nodes[address] = raw; entries.append(list(entry))
        previous, address = address, following
    win.require(len(nodes) == count and previous == last,
                'Class nested map count or last endpoint differs')
    win.require(all(read.exact(address, len(raw)) == raw for address, raw in nodes.items()),
                'Class nested map changed during snapshot; retry the capture')
    result['nested_map_u32_entries'] = entries
    return result


def _classification_snapshot(read, root, count):
    """Read a small stable native uint32 tree; numeric ID meanings stay unknown."""
    win.require(bool(root) == bool(count), 'Profile classification tree root/count differs')
    result = dict(profile_classification_ids_available=count <= CLASSIFICATION_SNAPSHOT_LIMIT,
                  profile_classification_ids_truncated=count > CLASSIFICATION_SNAPSHOT_LIMIT)
    if not result['profile_classification_ids_available']:
        return result
    pending, nodes, values = [(root, -(1 << 31), (1 << 31)-1)], {}, []
    while pending:
        address, lower, upper = pending.pop()
        if not address:
            continue
        win.require(address not in nodes and len(nodes) < count,
                    'Profile classification tree is cyclic or exceeds its count')
        raw = read.exact(address, 0x20)
        value = struct.unpack_from('<I', raw)[0]
        ordered_value = struct.unpack_from('<i', raw)[0]
        left, right = struct.unpack_from('<2Q', raw, 0x10)
        # Native insertion uses signed JL. Duplicate values are allowed;
        # balancing can place equal values on either side of a node.
        win.require(lower <= ordered_value <= upper, 'Profile classification tree ordering differs')
        nodes[address] = raw
        values.append(value)
        pending.extend(((left, lower, ordered_value), (right, ordered_value, upper)))
    win.require(len(nodes) == count, 'Profile classification tree count differs')
    win.require(all(read.exact(address, 0x20) == raw for address, raw in nodes.items()),
                'Profile classification tree changed during snapshot; retry the capture')
    result['profile_classification_ids'] = sorted(values)
    return result


def class_definition_state(read, base, engine):
    """Inspect the B190 class hash map used by native IsSelectedProfileEngineer.

    Only six known LocalVS class keys are queried. Pointer/allocator fields are
    never exported. Small collections are read exactly; their numeric
    meanings and the other nested map's semantics remain unverified.
    """
    require_signatures(read, base, CLASS_SIGNATURES)
    manager = read.u64(engine+0xB190)
    result = dict(available=True, definition_manager_present=bool(manager),
                  class_loadout_valid='unverified', applied_to_client=False,
                  profile_classification_collection_verified=True,
                  profile_classification_id_meanings='unverified',
                  nested_map_entry_meanings='unverified',
                  profile_purchase_cost_fields_verified=True,
                  interpretation='Class definitions use the B190 hash map. The item-preload tree is a different manager.')
    if not manager:
        return result
    descriptor = read.exact(manager+8, 40)
    count, first, last, buckets, capacity = struct.unpack('<5Q', descriptor)
    win.require(count <= 4096 and count <= capacity <= 8192,
                'Class definition map exceeds diagnostic bounds')
    win.require(not count or (buckets and capacity and not (capacity & (capacity-1))),
                'Class definition hash map layout is invalid')
    visited, bucket_reads, records = {}, {}, []
    for identifier in VS_PROFILE_IDS:
        node = 0
        if count:
            address = buckets + (identifier & (capacity-1))*8
            if address not in bucket_reads:
                bucket_reads[address] = read.u64(address)
            node = bucket_reads[address]
        seen, found = set(), False
        row = dict(profile_id=identifier, record_present=False)
        for _ in range(16):
            if not node or len(visited) >= 64 and node not in visited:
                break
            win.require(node not in seen, 'Class definition collision chain is cyclic')
            seen.add(node)
            if node not in visited:
                visited[node] = read.u32(node), read.u64(node+0xC8)
            key, link = visited[node]
            if key == identifier:
                scalar = read.exact(node+8, 0x50)
                floats = read.exact(node+8+0xA0, 8)
                nested_map = read.exact(node+8+0x58, 40)
                nested_tree = read.exact(node+8+0x90, 16)
                nested_count, nested_first, nested_last, nested_buckets, nested_capacity = struct.unpack('<5Q', nested_map)
                # Native 9A90C0/96D9D0 builds a uint32 tree at record+88:
                # root +90, uint64 count +98. This is not a vector/capacity pair.
                tree_root, tree_count = struct.unpack('<2Q', nested_tree)
                win.require(scalar[0x1C] in (0, 1) and scalar[0x1D] in (0, 1)
                            and all(math.isfinite(value) for value in struct.unpack('<2f', floats))
                            and nested_count <= nested_capacity <= 8192
                            and (not nested_count or (nested_buckets and not (nested_capacity & (nested_capacity-1))))
                            and tree_count <= 4096
                            and (not tree_count or tree_root),
                            'Class definition fields exceed diagnostic bounds')
                offsets = tuple(range(0, 0x1C, 4)) + tuple(range(0x20, 0x4C, 4))
                row.update(record_present=True,
                           raw_u32_by_offset={f'0x{offset:02X}':struct.unpack_from('<I', scalar, offset)[0]
                                              for offset in offsets},
                           raw_flags_by_offset={'0x1C':scalar[0x1C], '0x1D':scalar[0x1D]},
                           raw_float_by_offset=dict(zip(('0xA0', '0xA4'), struct.unpack('<2f', floats))),
                           native_profile_type_id=struct.unpack_from('<I', scalar, 0x0C)[0],
                           native_profile_resource_id=struct.unpack_from('<I', scalar, 0x38)[0],
                           native_profile_base_cost=struct.unpack_from('<i', scalar, 0x3C)[0],
                           nested_map_count=nested_count, nested_u32_tree_count=tree_count)
                row.update(_class_map_snapshot(read, nested_count, nested_first, nested_last))
                row.update(_classification_snapshot(read, tree_root, tree_count))
                row['complete_wire_record_available'] = (row['nested_map_entries_available']
                                                        and row['profile_classification_ids_available'])
                if row['complete_wire_record_available']:
                    # Actual 98AEB0 order; preserve all observed numeric values.
                    # Structural completeness does not establish class usability.
                    wire = (scalar[:0x1E] + scalar[0x20:0x28] + struct.pack('<I', nested_count)
                            + b''.join(struct.pack('<3I', *entry) for entry in row['nested_map_u32_entries'])
                            + scalar[0x28:0x34] + struct.pack('<I', tree_count)
                            + b''.join(struct.pack('<I', value) for value in row['profile_classification_ids'])
                            + scalar[0x34:0x4C] + floats)
                    row['wire_record_hex'] = wire.hex()
                win.require(read.exact(node+8, 0x50) == scalar
                            and read.exact(node+8+0xA0, 8) == floats
                            and read.exact(node+8+0x58, 40) == nested_map
                            and read.exact(node+8+0x90, 16) == nested_tree,
                            'Class definition changed during snapshot; retry the capture')
                found = True
                break
            node = link
        row['search_complete'] = found or not node
        records.append(row)
    win.require(read.u64(engine+0xB190) == manager
                and read.exact(manager+8, 40) == descriptor
                and all(read.u64(address) == pointer for address, pointer in bucket_reads.items())
                and all(read.u32(node) == key and read.u64(node+0xC8) == link
                        for node, (key, link) in visited.items()),
                'Class definition map changed during snapshot; retry the capture')
    result.update(definition_count=count, local_vs_definitions=records,
                  all_local_vs_definitions_present=all(row['record_present'] for row in records))
    return result


def profile_loader_state(read, base, engine):
    """Observe the native class asset loader and its item-definition queue."""
    require_signatures(read, base, PROFILE_SIGNATURES)
    loader = read.u64(engine+0xB1A0)
    definition_manager = read.u64(engine+0xB148)
    initial_manager = definition_manager
    result = dict(available=True, loader_present=bool(loader),
                  item_definition_manager_present=bool(definition_manager),
                  class_loadout_valid='unverified', map_load_complete='unverified')
    if loader:
        manager = read.u64(loader+0x30)
        descriptor = read.exact(loader+0x58, 16)
        pointer, count, capacity = struct.unpack('<Qii', descriptor)
        outstanding = read.u32(loader+0x78)
        win.require(0 <= count <= capacity <= 8192 and outstanding <= 65536,
                    'Profile loader counters exceed diagnostic bounds')
        rows = []
        samples = read.exact(pointer, min(count, 8)*12) if count else b''
        for offset in range(0, len(samples), 12):
            item, variant1, variant2 = struct.unpack_from('<3I', samples, offset)
            rows.append(dict(item_definition_id=item, variant_field_1=variant1,
                             variant_field_2=variant2))
        win.require(read.u64(loader+0x30) == manager
                    and read.exact(loader+0x58, 16) == descriptor
                    and read.u32(loader+0x78) == outstanding
                    and (not samples or read.exact(pointer, len(samples)) == samples),
                    'Profile loader changed during snapshot; retry the capture')
        result.update(pending_item_count=count, pending_items=rows,
                      pending_items_truncated=count>8,
                      outstanding_counter=outstanding,
                      loader_item_manager_matches=manager == definition_manager,
                      interpretation='Native pump returns false while +0x78 is nonzero. Queue IDs are item-definition IDs, not class-profile IDs; variants remain unnamed.')
        definition_manager = manager
    if definition_manager:
        root = read.u64(definition_manager+0x278)
        visited, observations = {}, []
        for item in dict.fromkeys(VS_STARTER_ITEM_IDS + tuple(
                row['item_definition_id'] for row in result.get('pending_items', ()) if row['item_definition_id'])):
            node, seen, found = root, set(), False
            for depth in range(16):
                if not node:
                    break
                win.require(node not in seen, 'Profile definition tree is cyclic')
                seen.add(node)
                if len(visited) >= 64 and node not in visited:
                    break
                if node not in visited:
                    key = read.u32(node)
                    links = read.exact(node+0x240, 16)
                    visited[node] = key, links
                key, links = visited[node]
                if key == item:
                    found = True
                    break
                node = struct.unpack_from('<Q', links, 0 if key > item else 8)[0]
            observations.append(dict(item_definition_id=item, record_present=found,
                                     search_complete=found or not node))
        win.require(read.u64(definition_manager+0x278) == root
                    and all(read.u32(node) == key and read.exact(node+0x240, 16) == links
                            for node, (key, links) in visited.items()),
                    'Profile definition tree changed during snapshot; retry the capture')
        result.update(item_definition_tree_present=bool(root), item_definitions=observations)
    win.require(read.u64(engine+0xB1A0) == loader,
                'Profile loader pointer changed during snapshot')
    win.require(read.u64(engine+0xB148) == initial_manager,
                'Item definition manager changed during snapshot')
    return result

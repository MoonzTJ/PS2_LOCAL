@echo off
cd /d "%~dp0"
py -3 collect_shared_data.py
echo.
pause

"""Capture the complete matching shared PACK2 from the copied local game.

Reads one fixed shipped asset pack and the executable from disk. No running
game, process access, network requests, game launches or game-file changes.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import shutil
import struct
import subprocess
import tempfile
import zipfile
import zlib

import collect_profile_resources as packs


PROVENANCE = json.loads(Path(__file__).with_name('shared_data_input.json').read_text())
EXPECTED_PACK = PROVENANCE['pack']
PACK_NAME = EXPECTED_PACK['name']
PACK_MEMBER = 'packs/' + PACK_NAME
MAX_EXECUTABLE_BYTES = 128 * 1024 * 1024
MAX_DECODED_BYTES = 256 * 1024 * 1024
MAX_ARCHIVE_BYTES = 16 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bounded_sha(path, limit):
    digest = hashlib.sha256()
    total = 0
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            total += len(block)
            if total > limit:
                raise ValueError('Source file exceeds the capture size limit')
            digest.update(block)
    return digest.hexdigest()


def choose_game_folder():
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        selected = input('Paste the copied PlanetSide 2 Local folder path: ').strip().strip('"')
    else:
        try:
            root = tk.Tk()
        except tk.TclError:
            selected = input('Paste the copied PlanetSide 2 Local folder path: ').strip().strip('"')
        else:
            root.withdraw()
            try:
                selected = filedialog.askdirectory(
                    title='Choose the copied PlanetSide 2 Local game folder',
                    initialdir=str(packs.DEFAULT_GAME) if packs.DEFAULT_GAME.is_dir() else None,
                    mustexist=True)
            finally:
                root.destroy()
    if not selected:
        raise ValueError('No copied local game folder was selected')
    return Path(selected)


def require_matching_index(record):
    if any(record[k] != EXPECTED_PACK[k] for k in ('name', 'bytes', 'entries', 'index_sha256')):
        raise ValueError('Shared pack size or index differs from the verified local asset set')


def verified_resource(path, key, entry):
    # The matching index includes seven empty uncompressed entries. Their
    # checksum is the CRC32C of the key alone; they must not be skipped.
    if entry[1] == 0:
        if entry[2] != 16 or entry[3] != packs.crc32c(struct.pack('<Q', key)):
            raise ValueError('Invalid empty shared-pack resource')
        return b''
    return packs.read_resource(path, key, entry)


def capture(game_dir, output_root):
    output_root = Path(output_root).resolve()
    report = dict(format='ps2-local-shared-data-v1',
        captured_at_utc=datetime.now(timezone.utc).isoformat(),
        expected_client_sha256=packs.EXPECTED_CLIENT,
        expected_pack=EXPECTED_PACK, client_sha256=None, capture_complete=False,
        matching_pack_index_verified=False, anchor_tables_verified=False,
        all_resource_crcs_verified=False, resource_streams_verified=False,
        stable_pack_copy_verified=False, resources=[],
        process_access_performed=False, network_access_performed=False,
        game_or_backend_files_modified=False, account_or_character_data_exported=False,
        complete_class_values_verified=False, complete_weapon_values_verified=False)
    stage = 'folder_selection'
    selection_error = None
    try:
        game_dir = (Path(game_dir) if game_dir is not None else choose_game_folder()).resolve()
    except (OSError, ValueError) as error:
        selection_error = error
    # Do this outside the report-producing catch: even a failure archive must
    # be written outside the copied game installation.
    if selection_error is None and output_root.is_relative_to(game_dir):
        raise ValueError('Extract this helper outside the game folder, such as on your Desktop')
    output_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='shared-data-', dir=output_root) as folder:
        staging = Path(folder)
        copied = staging / PACK_NAME
        data_zip = staging / 'capture.zip'
        try:
            if selection_error is not None:
                raise selection_error
            stage = 'executable_hash'
            client = game_dir / 'PlanetSide2_x64.exe'
            report['client_sha256'] = bounded_sha(client, MAX_EXECUTABLE_BYTES)
            if report['client_sha256'] != packs.EXPECTED_CLIENT:
                raise ValueError('Selected executable differs from the verified local build; no pack was read')
            source = game_dir / 'Resources' / 'Assets' / PACK_NAME
            stage = 'pack_index'
            _, record = packs.read_index(source)
            require_matching_index(record)
            stage = 'pack_copy'
            with source.open('rb') as stream:
                raw = stream.read(EXPECTED_PACK['bytes'] + 1)
            if len(raw) != EXPECTED_PACK['bytes']:
                raise ValueError('Shared pack size changed during capture')
            copied.write_bytes(raw)
            digest = sha(raw)
            del raw
            entries, copied_record = packs.read_index(copied)
            require_matching_index(copied_record)
            report.update(matching_pack_index_verified=True, pack_sha256=digest,
                          pack_bytes=EXPECTED_PACK['bytes'])
            stage = 'resource_integrity'
            anchors = {}
            anchor_keys = {packs.name_hash(name): name for name in packs.ANCHORS}
            decoded_total = 0
            for index, (key, entry) in enumerate(entries.items(), 1):
                if index == 1 or index % 250 == 0 or index == len(entries):
                    print(f'Verifying shared resource {index}/{len(entries)}', flush=True)
                data = verified_resource(copied, key, entry)
                decoded_total += len(data)
                if decoded_total > MAX_DECODED_BYTES:
                    raise ValueError('Combined decoded resources exceed the capture limit')
                resource_sha = sha(data)
                report['resources'].append(dict(asset_hash=f'{key:016x}',
                    stored_bytes=entry[1], flags=entry[2], decoded_bytes=len(data), sha256=resource_sha))
                if key in anchor_keys:
                    anchors[anchor_keys[key]] = resource_sha
            report.update(all_resource_crcs_verified=True, resource_streams_verified=True,
                          decoded_resource_bytes=decoded_total, resource_count=len(entries))
            stage = 'anchor_tables'
            if anchors != packs.ANCHORS:
                raise ValueError('Shared-pack anchor tables are missing or different')
            report.update(anchor_tables_verified=True, anchors=anchors)
            stage = 'final_pack_hash'
            if bounded_sha(source, EXPECTED_PACK['bytes']) != digest:
                raise ValueError('Shared pack changed during capture')
            report['stable_pack_copy_verified'] = True
            stage = 'final_executable_hash'
            if bounded_sha(client, MAX_EXECUTABLE_BYTES) != packs.EXPECTED_CLIENT:
                raise ValueError('Executable changed during capture')
            report['capture_complete'] = True
        except (OSError, ValueError, EOFError, zlib.error) as error:
            report.update(capture_complete=False, error_stage=stage,
                          error=str(error) if isinstance(error, ValueError) else type(error).__name__)
            code = getattr(error, 'winerror', None) or getattr(error, 'errno', None)
            if type(code) is int:
                report['os_error_code'] = code
            report['resources'] = []
        # Publish no partial pack on failure. Only the successful verified
        # copy, never an adjacent file or path, can become an archive member.
        payload = (json.dumps(report, indent=2) + '\n').encode()
        members = {'capture.json': dict(bytes=len(payload), sha256=sha(payload))}
        with zipfile.ZipFile(data_zip, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            if report['capture_complete']:
                archive.write(copied, PACK_MEMBER)
                members[PACK_MEMBER] = dict(bytes=report['pack_bytes'], sha256=report['pack_sha256'])
            archive.writestr('capture.json', payload)
            archive.writestr('manifest.json', json.dumps(dict(format=report['format'],
                capture_complete=report['capture_complete'], files=members), indent=2) + '\n')
        if data_zip.stat().st_size > MAX_ARCHIVE_BYTES:
            raise ValueError('Capture archive exceeds its upload limit')
        with zipfile.ZipFile(data_zip) as archive:
            if archive.testzip() is not None:
                raise ValueError('Capture ZIP failed its integrity check')
            for name, row in members.items():
                data = archive.read(name)
                if len(data) != row['bytes'] or sha(data) != row['sha256']:
                    raise ValueError('Capture ZIP contents differ from the verified copy')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        target = output_root / f'local-shared-data-{stamp}-{secrets.token_hex(4)}.zip'
        data_zip.rename(target)
    uploads = target.with_name(target.name + '.upload')
    uploads.mkdir()
    uploaded = uploads / target.name
    shutil.copyfile(target, uploaded)
    if bounded_sha(target, MAX_ARCHIVE_BYTES) != bounded_sha(uploaded, MAX_ARCHIVE_BYTES):
        raise ValueError('Upload copy checksum differs')
    return uploads, report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-dir', type=Path)
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent / 'reports')
    args = parser.parse_args(argv)
    print('Reading the copied local game from disk. Choose the PlanetSide 2 Local game folder.')
    try:
        uploads, report = capture(args.game_dir, args.output_dir)
    except (OSError, ValueError, zipfile.BadZipFile) as error:
        print('Capture stopped: ' + (str(error) if isinstance(error, ValueError) else type(error).__name__))
        return 1
    if report['capture_complete']:
        print(f'Captured the complete shared pack: {report["resource_count"]} verified resources.')
    else:
        print('Capture stopped at ' + report['error_stage'] + ': ' + report['error'])
    print('Upload the ZIP INSIDE this folder, including the small ZIP if capture failed:')
    print(uploads)
    try:
        subprocess.Popen(['explorer.exe', str(uploads)])
    except OSError:
        pass
    return 0 if report['capture_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

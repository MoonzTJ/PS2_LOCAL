@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys,ctypes,tkinter;sys.exit(sys.version_info<(3,10) or ctypes.sizeof(ctypes.c_void_p)!=8)" >nul 2>&1
if errorlevel 1 goto missing
where pyw >nul 2>&1
if errorlevel 1 goto missing
start "" pyw -3 "%~dp0PS2_Tools\run_local_test.py"
if errorlevel 1 goto missing
exit /b 0
:missing
echo Install 64-bit Python 3.10 or newer with Tkinter and the py/pyw launchers.
pause
exit /b 1

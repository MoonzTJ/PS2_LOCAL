"""Class19 placement/motion run with the opt-in, table-inferred VS LA appearance candidate.

Reuses the frozen placement flow unchanged except for the explicitly expected
candidate values: class19 model words 165/166 and LocalVSTest's menu row. The
report additionally keeps this server instance's header-only gateway log.
"""
import argparse,ctypes
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1];SERVER=ROOT/'PS2_Server'
if not SERVER.is_dir():SERVER=ROOT
sys.path.insert(0,str(SERVER))
try:
    from scripts import run_profile_placement_test as placement
except ModuleNotFoundError:
    import run_profile_placement_test as placement
activation=placement.baseline
import vs_appearance
import win_reader as win
from profile_probe import probe_description
from console_common import CONTROL_PORT,LOGIN_PORT,control_request,wait_ready

FORMAT='ps2-vs-appearance-test-v1'
SESSION=ROOT/'.vs-appearance-session.json'
MAX_GATEWAY_LOG=16*1024*1024
_frozen_before=activation.require_before
_frozen_verify_ready=placement.verify_ready


def candidate_probe_description():
    return probe_description(model_pairs=vs_appearance.class_model_pairs())


def description():
    return dict(version=FORMAT,placement_backend=placement.description(),appearance=vs_appearance.description(),
                class_delivery_probe=candidate_probe_description())


def verify_bundle(root=ROOT):
    manifest=json.loads((root/'helper-manifest.json').read_text())
    win.require(manifest.get('format')==FORMAT and manifest.get('test_description')==description(),
                'Extract the complete VS appearance test ZIP again.')
    for name,pin in manifest['files'].items():
        path=root/name
        win.require(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(root.resolve())
                    and path.stat().st_size==pin['bytes'] and win.file_sha(path)==pin['sha256'],
                    'VS appearance helper files differ; extract again.')


def require_before(snapshot):
    """The frozen guard with only class19's expected model words changed."""
    actor=snapshot.get('actor_initialization',{})
    rows=[dict(row) for row in actor.get('class_records',[])]
    candidate=[row for row in rows if row.get('profile_id')==19]
    win.require(len(candidate)==1 and candidate[0].get('record_present') is True
        and (candidate[0].get('model_ref_28'),candidate[0].get('model_ref_2c'))==vs_appearance.MODEL_PAIR,
        'Class19 did not receive the 165/166 candidate. No activation sent; upload this report.')
    candidate[0].update(model_ref_28=0,model_ref_2c=0)
    _frozen_before(dict(snapshot,actor_initialization=dict(actor,class_records=rows)))


def install_candidate_guards():
    # The frozen runners compare health against the default identity-only
    # probe and expect zero class19 model words. Only those two expectations
    # change; every other inherited guard runs unmodified.
    activation.launch.probe_description=candidate_probe_description
    activation.require_before=require_before
    placement.verify_ready=verify_ready


def verify_ready(ready,instance=None,*,fresh=False):
    _frozen_verify_ready(ready,instance,fresh=fresh)
    observed=ready.get('vs_la_appearance_candidate',{})
    win.require(all(observed.get(k)==v for k,v in vs_appearance.description().items())
                and isinstance(observed.get('character_list_sha256'),str),
                'Use start_vs_appearance_test.cmd with its separate server.')
    return ready


def attach_gateway_log(report,instance,logs):
    logs=sorted(Path(logs).glob(f'gateway-*-{instance}.jsonl'))
    win.require(len(logs)==1 and logs[0].stat().st_size<=MAX_GATEWAY_LOG,'Gateway log missing or too large')
    raw=logs[0].read_bytes()
    with zipfile.ZipFile(report,'a',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr(logs[0].name,raw)
        z.writestr('gateway-log-manifest.json',json.dumps(dict(name=logs[0].name,bytes=len(raw),
            sha256=hashlib.sha256(raw).hexdigest(),header_metadata_only=True),indent=2)+'\n')
    with zipfile.ZipFile(report) as z:win.require(z.testzip() is None,'Report CRC failed after adding gateway log')


def start(game):
    activation.launch.require_closed_server();reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    process=subprocess.Popen([sys.executable,str(SERVER/'local_server.py'),'--push-lists','--class-delivery-probe',
        '--vs-test-character','--starter-loadout-references','--cosmetic-inventory-probe','--profile-activation-probe',
        '--profile-placement-probe','--vs-la-appearance-candidate','--character-state-dir',str(SERVER/'state'),
        '--no-availability-observation','--log-dir',str(reports)],cwd=str(SERVER),creationflags=subprocess.CREATE_NEW_CONSOLE)
    try:ready=verify_ready(wait_ready(CONTROL_PORT,LOGIN_PORT,30),fresh=True)
    except BaseException:
        if process.poll() is None:process.terminate()
        raise
    SESSION.write_text(json.dumps(dict(game_dir=str(game),instance_id=ready['instance_id'])))
    for mode in ('client','controls'):
        subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--mode',mode],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_CONSOLE)
    print('Screenshot character select with LocalVSTest selected, then Play.')
    print('At the 3D view run appearance_place_and_capture.cmd once.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--mode',choices=('start','client','controls','capture'),default='start')
    args=parser.parse_args(argv)
    try:
        win.require(os.name=='nt' and ctypes.sizeof(ctypes.c_void_p)==8,'Use 64-bit Python on Windows.')
        verify_bundle();install_candidate_guards()
        if args.mode=='start':
            game=activation.launch.choose_game()
            if game:start(activation.launch.verify_game(game))
            return 0
        state=json.loads(SESSION.read_text());verify_ready(control_request(CONTROL_PORT,LOGIN_PORT),state['instance_id'])
        game=activation.launch.verify_game(state['game_dir'])
        if args.mode=='client':
            import local_client
            return local_client.main(['--game-dir',str(game),'--log-dir',str(ROOT/'reports')])
        if args.mode=='controls':
            import test_controls
            return test_controls.main(heading='VS LA appearance, placement and motion',instructions='At 3D view run appearance_place_and_capture.cmd once. TWO beeps hold W; ONE beep release; THREE finished.')
        target,ok=placement.collect_test(game,state['instance_id'])
        try:attach_gateway_log(target,state['instance_id'],ROOT/'reports')
        except (OSError,ValueError,zipfile.BadZipFile) as error:print('Gateway log was not attached:',error)
        try:subprocess.Popen(['explorer.exe',str(target.parent)])
        except OSError:pass
        return 0 if ok else 1
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('VS appearance test stopped:',str(error));return 1


if __name__=='__main__':raise SystemExit(main())
